self = {}

local theme =
{
	speed = 0.125,
	pause = 2,

	newLineOffset = { 32, -96 },

	baseLine = 360
}

local function GetTime()
	return #self.text * theme.speed + theme.pause
end

function Update(delta)
	self.currentTime = self.currentTime + delta

	return self.currentTime > GetTime()
end

local function GetWidth(s)
	local _, _, w = self.font:Measure(s)

	return w
end

function Draw()
	local width = GetWidth(self.text)
	local baseX = Math.Interpolate(Screen.Width, Screen.Width / 8, Math.SmoothStep(0, 1, Math.Min(self.currentTime / 0.5, 1)))
	local baseY = theme.baseLine
	local x = 0
	local spaces = 0

	for i = 1, #self.text do
		local c = self.text:sub(i, i)
		local alpha = Math.SmoothStep(0, 1, Math.Min((self.currentTime - ((i - spaces) * theme.speed)) / theme.speed, 1))
		self.foreground:SetAlpha(alpha)


		if c == '\n' then
			baseX = baseX + theme.newLineOffset[1]
			baseY = baseY + theme.newLineOffset[2]
			x = 0
		else
			self.font:DrawText(self.foreground, baseX + x, baseY, c)
			x = x + GetWidth(c)

			if c == ' ' then
				spaces = spaces + 1
			end
		end
	end

	self.background:SetAlpha(Math.SmoothStep(0, 1, Math.Clamp((self.currentTime - (#self.text * theme.speed)) / theme.pause, 0, 1)))
	self.background:Fill(0, 0, Screen.Width, Screen.Height)
end

local function Create(game, text)
	self.text = text

	self.currentTime = 0

	self.background = GraphicsUtility.CreatePaint(Color.Create(1, 1, 1, 1))
	self.foreground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 1))

	self.font = Font.Load("content/fonts/normal.ttf", 64, settings().quality)
end

Create(...)
