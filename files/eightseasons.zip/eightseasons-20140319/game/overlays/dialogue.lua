local resources = {}
local state = {}
local game
local conversation

local theme =
{
	speed = 1,
	
	dialogue =
	{
		position = { 60, 410 },
		size = { 520, 440 },
		lineHeight = -50,
		maxLines = 8
	},
	
	pages =
	{
		position = { 310, 10 }
	},
	
	buttons =
	{
		previous =
		{
			{ 400, 60 },
			{ 250, 60 },
			{ 40, 10 },
			
			width = 75,
			height = 40
		},
		
		next =
		{
			{ 840, 60 },
			{ 690, 60 },
			{ 490, 10 },
			
			width = 75,
			height = 40
		}
	}
}

local function Open(path)
	local success, ret = load({}, path)
	
	if not success then
		error(ret)
	end
	
	return ret
end

function StartConversation(path, callback)
	if conversation then
		EndConversation()
	end
	
	-- Load conversation
	local c = Open(path)
	conversation = {}
	conversation.callback = callback
	conversation.pages = 0
	
	for i = 1, #c do
		local d = {}
		
		if c[i][1] then
			d.image = LG.Compile(LG.Load(c[i][1]))
		end
		
		local m = Open(c[i][2])[language()]
		d.name = m.name
		d.message = m[c[i][3]]
		d.animation = Animation.Frame.Create(d.image)
		
		Table.Insert(conversation, d)
		
		conversation.pages = conversation.pages + #d.message
	end
	
	-- Initialize conversation
	state.currentTime = theme.speed / 2
	state.currentPage = 1
	
	state.activeButton = "none"
	
	state.activeDialogue = 0
	state.activeConversation = 0
	
	state.nextActiveDialogue = 1
	state.nextActiveConversation = 1
	state.nextMovementType = "forward"

	conversation[1].message[1].read = true
	
	if conversation[1].image == nil then
		resources.sceneView:ChangeAnimation("Start-Narrator")
		state.currentMode = "narrator"
	else
		resources.sceneView:ChangeAnimation("Start-Speaker")
		state.currentMode = "speaker"
	end
	
	state.isTransitioning = true
	state.isExiting = false
end

function EndConversation()
	for i = 1, #conversation do
		if conversation[i].image then
			LG.Destroy(conversation[i].image)
		end
	end
	
	conversation = nil
end

local function AnimateEmotion()
	if state.activeConversation ~= 0 and state.activeDialogue ~= 0 then
		local cur = conversation[state.activeConversation].message[state.activeDialogue]
		local next = conversation[state.nextActiveConversation].message[state.nextActiveDialogue]

		if cur[1] ~= next[1] and next[1] ~= "" and not next.read then
			resources.sceneView:ChangeAnimation(next[1], false)
		end
	end
end

function Update(delta)
	resources.sceneView:Update(delta)
	
	if state.isTransitioning then
		if resources.sceneView:IsAnimationFinished() then
			state.isTransitioning = false

			AnimateEmotion()

			state.activeDialogue = state.nextActiveDialogue
			state.activeConversation = state.nextActiveConversation
			conversation[state.activeConversation].message[state.activeDialogue].read = true
			
			if state.isExiting then
				game.ExitOverlay()

				if conversation.callback then
					conversation.callback()
				end
			end
		end
	end
end

local function DrawDialogue(dialogue, m, offset)
	local t = theme.speed / theme.dialogue.maxLines / 2
	local baseX = theme.dialogue.position[1] + dialogue.position[1]
	local baseY = theme.dialogue.position[2] + dialogue.position[2]
	local x = baseX
	local y = baseY
	
	for i = 2, #m do
		Graphics.SetBlenderTint(Color.Create(0, 0, 0, dialogue.alpha))
		
		resources.fonts.dialogue:DrawText(resources.colors.foreground, x, y, m[i])
		
		y = y + theme.dialogue.lineHeight
	end
end

function Draw()
	resources.sceneView:Draw()
	
	Graphics.PushBlenderMode()
	Graphics.SetBlenderMode(BlenderMode.TintAlpha)
	
	do
		local conversationIndex, dialogueIndex
		
		if state.currentTime > theme.speed / 2 then
			conversationIndex = state.nextActiveConversation
			dialogueIndex = state.nextActiveDialogue
		else
			conversationIndex = Math.Max(state.activeConversation, 1)
			dialogueIndex = Math.Max(state.activeDialogue, 1)
		end
		
		-- Draw head
		do
			local head = resources.sceneView:FindObject("HeadFrame")

			local emotion = conversation[conversationIndex].message[dialogueIndex][1]
			
			Graphics.SetBlenderTint(Color.Create(0, 0, 0, head.alpha))
			
			if conversation[conversationIndex].image and not head.isHidden then
				LG.Draw(conversation[conversationIndex].image, emotion, 1, head.position[1] + head.origin[1], head.position[2] + head.origin[2])
			end
		end
		
		-- Draw name
		do
			local name = resources.sceneView:FindObject("NameFrame")
			local fx, fh, fw = resources.fonts.name:Measure(conversation[conversationIndex].name)
			
			Graphics.SetBlenderTint(Color.Create(0, 0, 0, name.alpha))
			
			local x = name.position[1] + name.origin[1] - fw / 2
			local y = name.position[2] + name.origin[2] - fh / 2
			
			if conversation[conversationIndex].image and conversation[conversationIndex].name and not name.isHidden then
				resources.fonts.name:DrawText(resources.colors.foreground, x, y, conversation[conversationIndex].name)
			end
		end
	end
	
	do
		local dialogue = resources.sceneView:FindObject("DialogueFrame")
		
		-- Draw buttons
		do
			local alpha
			
			if (state.activeDialogue <= 1 and state.activeConversation <= 1)
				or (state.nextActiveDialogue <= 1 and state.nextActiveConversation <= 1)
			then
				if state.nextActiveDialogue > 1 or state.nextActiveConversation > 1 then
					-- Fade in.
					alpha = (state.currentTime / theme.speed) * 0.5
				elseif state.activeDialogue > 0 and state.activeConversation > 0
					and not state.isExiting
				then
					-- Fade out, since there's no going back.
					alpha = (1 - (state.currentTime / theme.speed)) * 0.5
				else
					alpha = 0
				end
			else
				if state.activeButton == "previous" then
					alpha = 1
				else
					alpha = 0.5
				end
			end
			
			Graphics.SetBlenderTint(Color.Create(0, 0, 0, alpha * dialogue.alpha))
			
			LG.Draw(resources.images.previousButton, "button", 1, dialogue.position[1] + theme.buttons.previous[3][1], dialogue.position[2] + theme.buttons.previous[3][2])
		end
		
		-- Always draw the "Next" button
		do
			local alpha
			
			if state.activeButton == "next" and not state.isTransitioning then
				alpha = 1
			else
				alpha = 0.5
			end
			
			Graphics.SetBlenderTint(Color.Create(0, 0, 0, alpha * dialogue.alpha))
			
			LG.Draw(resources.images.nextButton, "button", 1, dialogue.position[1] + theme.buttons.next[3][1], dialogue.position[2] + theme.buttons.next[3][2])
		end
		
		-- Draw page numbers
		do
			local s = format("%d of %d", state.currentPage, conversation.pages)
			local fx, fh, fw = resources.fonts.name:Measure(s)
			local x = theme.pages.position[1] + dialogue.position[1] - fw / 2
			local y = theme.pages.position[2] + dialogue.position[2]
			
			Graphics.SetBlenderTint(Color.Create(0, 0, 0, dialogue.alpha))
			
			resources.fonts.dialogue:DrawText(resources.colors.foreground, x, y, s)
		end
	
		-- Draw text
		do
			if state.isTransitioning then
				local m1 = {}
				local m2 = {}

				if state.activeConversation > 0 and state.activeDialogue > 0 then
					m1 = conversation[state.activeConversation].message[state.activeDialogue]
				end

				m2 = conversation[state.nextActiveConversation].message[state.nextActiveDialogue]

				local a1, a2, b1, b2

				if state.nextMovementType == "forward" then
					a1 = 0
					b1 = theme.dialogue.size[1]
					a2 = -theme.dialogue.size[1]
					b2 = 0
				else
					a1 = 0
					b1 = -theme.dialogue.size[1]
					a2 = theme.dialogue.size[1]
					b2 = 0
				end
			
				if state.currentTime < theme.speed / 2 then
					DrawDialogue(dialogue, m1, Math.Interpolate(a1, b1, Math.SmoothStep(0, 1, (state.currentTime) / (theme.speed / 2))))
				end
				
				if state.currentTime > theme.speed / 2 then
					DrawDialogue(dialogue, m2, Math.Interpolate(a2, b2, Math.SmoothStep(0, 1, (state.currentTime - theme.speed / 2) / (theme.speed / 2))))
				end
			else
				local m = conversation[state.activeConversation].message[state.activeDialogue]

				DrawDialogue(dialogue, m, 0)
			end
		end
	end
	
	Graphics.PopBlenderMode()
end

function Hover(x, y)
	local index
	
	if state.currentMode == "narrator" then
		index = 2
	else
		index = 1
	end
	
	if x > theme.buttons.previous[index][1]
		and x < theme.buttons.previous[index][1] + theme.buttons.previous.width
		and y > theme.buttons.previous[index][2]
		and y < theme.buttons.previous[index][2] + theme.buttons.previous.height
	then
		state.activeButton = "previous"
	elseif x > theme.buttons.next[index][1]
		and x < theme.buttons.next[index][1] + theme.buttons.next.width
		and y > theme.buttons.next[index][2]
		and y < theme.buttons.next[index][2] + theme.buttons.next.height
	then
		state.activeButton = "next"
	else
		state.activeButton = "none"
	end
end

function Click(x, y)
	if not state.isTransitioning then
		Hover(x, y)
		
		if state.activeButton == "previous" then
			Previous()
		elseif state.activeButton == "next" then
			Next()
		end
	end
end

function Previous()
	if state.activeDialogue > 1 then
		state.nextActiveDialogue = state.activeDialogue - 1
		
		state.isTransitioning = true
		state.currentTime = 0
		
		state.currentPage = state.currentPage - 1
	elseif state.activeConversation > 1 then
		local cur = state.activeConversation
		local next = state.activeConversation - 1
		
		if conversation[cur].image == nil and conversation[next].image ~= nil then
			-- Transition from narrator to speaker
			resources.sceneView:ChangeAnimation("In-Speaker", false)
			state.currentMode = "speaker"
		elseif conversation[cur].image ~= nil and conversation[next].image == nil then
			resources.sceneView:ChangeAnimation("In-Narrator", false)
			state.currentMode = "narrator"
		end
		
		state.nextActiveConversation = next
		state.nextActiveDialogue = #conversation[next].message
		
		state.isTransitioning = true
		state.currentTime = 0
		
		state.currentPage = state.currentPage - 1
	end

	state.nextMovementType = "backward"
end

function Next()
	if state.activeDialogue < #conversation[state.activeConversation].message then
		state.nextActiveDialogue = state.activeDialogue + 1
		
		state.isTransitioning = true
		state.currentTime = 0
		
		state.currentPage = state.currentPage + 1
	elseif state.activeConversation < #conversation then
		local cur = state.activeConversation
		local next = state.activeConversation + 1
		
		if conversation[cur].image == nil and conversation[next].image ~= nil then
			-- Transition from narrator to speaker
			resources.sceneView:ChangeAnimation("In-Speaker", false)
			state.currentMode = "speaker"
		elseif conversation[cur].image ~= nil and conversation[next].image == nil then
			resources.sceneView:ChangeAnimation("In-Narrator", false)
			state.currentMode = "narrator"
		end
		
		state.nextActiveConversation = next
		state.nextActiveDialogue = 1
		
		state.isTransitioning = true
		state.currentTime = 0
		
		state.currentPage = state.currentPage + 1
	else
		state.isExiting = true
		state.isTransitioning = true
		state.currentTime = 0
		
		if state.currentMode == "narrator" then
			resources.sceneView:ChangeAnimation("Out-Narrator", false)
		else
			resources.sceneView:ChangeAnimation("Out-Speaker", false)
		end
	end
	
	state.nextMovementType = "forward"
end

local function Create(gameState)
	game = gameState
	
	resources.colors = {}
	resources.colors.foreground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 1))
	
	resources.fonts = {}
	resources.fonts.dialogue = Font.Load("content/fonts/normal.ttf", 22, settings().quality)
	resources.fonts.name = Font.Load("content/fonts/normal.ttf", 42, settings().quality)
	
	resources.images = {}
	resources.images.nextButton = LG.Compile(LG.Load("content/overlays/dialogue/next.lg"))
	resources.images.previousButton = LG.Compile(LG.Load("content/overlays/dialogue/previous.lg"))
	
	resources.scene = Story.Scene.Load("content/overlays/dialogue/scene.lua")
	resources.sceneView = Story.Scene.Viewer.Create(resources.scene)
	
	state.currentMode = "none"
	state.currentTime = 0
	state.isTransitioning = false
	state.isExiting = false
	
	state.activeButton = "none"
	state.activeConversation = 1
	state.activeDialogue = 1
	
	state.nextActiveConversation = 1
	state.nextActiveDialogue = 1
end

Create(...)
