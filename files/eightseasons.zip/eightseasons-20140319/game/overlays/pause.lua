local resources = {}
local state = {}
local game

local theme =
{
	speed = 1,
	
	buttons =
	{
		fontSize = 50,
		
		{ "Continue", 400, 250 },
		{ "Record", 400, 150 },
		{ "Exit", 400, 50 }
	},
	
	title =
	{
		fontSize = 70,
		
		{ "Pause menu", 400, 400 }
	}
}

function Pause()
	state.currentTime = 0
	
	state.isTransitioning = true
	state.isExiting = false
	state.quitStage = false
	
	state.activeButton = 0
	
	resources.sceneView:ChangeAnimation("In")
end

function Update(delta)
	resources.sceneView:Update(delta)
	
	if state.isTransitioning then
		state.currentTime = state.currentTime + delta
		
		if state.currentTime > theme.speed and resources.sceneView:IsAnimationFinished() then
			state.isTransitioning = false
			
			if state.isExiting then
				game.ExitOverlay()
				
				if state.quitStage then
					game.ReturnToTitle()
				end
			end
		end
	else
		-- Find button
		--Hover(game.input.current.mouse.x, game.input.current.mouse.y)
	end
end

function Draw()
	resources.sceneView:Draw()
	
	Graphics.PushBlenderMode()
	Graphics.SetBlenderMode(BlenderMode.TintAlpha)
	
	-- Fade in options halfway through animation
	if (state.currentTime > theme.speed / 2 and not state.isExiting) or
		(state.currentTime < theme.speed / 2 and state.isExiting)
	then
		local alpha
		
		if state.isExiting then
			alpha = 1 - (state.currentTime / (theme.speed / 2))
		else
			alpha = (state.currentTime - theme.speed / 2) / (theme.speed / 2)
		end
		
		-- Draw title
		do
			Graphics.SetBlenderTint(Color.Create(0, 0, 0, alpha))
			
			resources.fonts.title:DrawText(resources.colors.foreground, theme.title[1][2], theme.title[1][3], theme.title[1][1])
		end
		
		-- Draw buttons
		do
			for i = 1, #theme.buttons do
				if i == state.activeButton then
					Graphics.SetBlenderTint(Color.Create(0, 0, 0, alpha))
				else
					Graphics.SetBlenderTint(Color.Create(0, 0, 0, alpha * 0.5))
				end
				
				resources.fonts.buttons:DrawText(resources.colors.foreground, theme.buttons[i][2], theme.buttons[i][3], theme.buttons[i][1])
			end
		end
	end
	
	Graphics.PopBlenderMode()
end

function Hover(x, y)
	state.activeButton = 0
	
	for i = 1, #theme.buttons do
		local fx, fh, fw = resources.fonts.buttons:Measure(theme.buttons[i][1])
		
		if MathUtil.Primitives.PointInRectangle(theme.buttons[i][2], theme.buttons[i][3], fw, fh, x, y) then
			state.activeButton = i
			break
		end
	end
end

function Click(x, y)
	Hover(x, y)
	
	if state.activeButton == 1 then
		-- Continue
		state.currentTime = 0
		
		state.isTransitioning = true
		state.isExiting = true
	elseif state.activeButton == 2 then
		-- Record data (and continue)
		game.Record()
	elseif state.activeButton == 3 then
		state.quitStage = true
	end
		
	if state.activeButton ~= 0 then
		state.currentTime = 0
	
		state.isTransitioning = true
		state.isExiting = true
		
		resources.sceneView:ChangeAnimation("Out", false)
	end
end

local function Create(gameState)
	game = gameState
	
	resources.colors = {}
	resources.colors.foreground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 1))
	
	resources.fonts = {}
	resources.fonts.title = Font.Load("content/fonts/italic.ttf", theme.title.fontSize, settings().quality)
	resources.fonts.buttons = Font.Load("content/fonts/normal.ttf", theme.buttons.fontSize, settings().quality)
	
	resources.scene = Story.Scene.Load("content/overlays/pause/scene.lua")
	resources.sceneView = Story.Scene.Viewer.Create(resources.scene)
	
	state.currentTime = 0
	
	state.isTransitioning = false
	state.isExiting = false
	state.quitStage = false
	
	state.activeButton = 0
end

Create(...)
