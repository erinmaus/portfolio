-- Since the demo overlay is a wrapper over a lightweight "game state", there
-- is only need to reference the game state...
local state

-- ...And the game, of course.
local game, done

function Enter(demo, args, callback)
	state = sandbox()

	local success, ret = load(state, demo, game, args)

	if not success then
		error(ret)
	end

	done = callback
end

function Update(delta)
	if state.Update then
		local ret = state.Update(delta)

		if ret then
			game.ExitOverlay()

			if done then
				done()
			end
		end
	end
end

function Draw()
	if state.Draw then
		state.Draw()
	end
end

function Hover(x, y)
end

function Click(x, y)
end

local function Create(gameState)
	game = gameState
end

Create(...)
