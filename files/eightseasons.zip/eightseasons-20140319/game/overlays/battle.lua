local resources = {}
local state = {}
local theme
local game

theme =
{
	speed = 4,
	skip = 1.5,

	message =
	{
		fontSize = 20,
		position = { 280, 20 },

		bounce = 5,
		bounces = 2,
		bounceSpeed = 1.25
	},

	speedButton =
	{
		fontSize = 20,
		text =
		{
			[true] = "speed: [fast]",
			[false] = "speed: [slow]"
		},

		tooltip = "Increases or decreases the pace of combat." ,

		position = { 820, 510 },
		size = { 100, 20 },

		active = function(x, y)
			return MathUtil.Primitives.PointInRectangle(theme.speedButton.position[1], theme.speedButton.position[2], theme.speedButton.size[1], theme.speedButton.size[2], x, y)
		end
	},

	showStats =
	{
		fontSize = 24,
		text = "[stats]",

		position = { 610, 370 },
		size = { 60, 22 },

		active = function(x, y)
			return MathUtil.Primitives.PointInRectangle(theme.showStats.position[1], theme.showStats.position[2], theme.showStats.size[1], theme.showStats.size[2], x, y)
		end
	},

	stats =
	{
		size = { 170, 220 },
		border = 2,
		padding = 4,
		lineHeight = 30,
		statOffset = 100,

		enemyPosition = { 290, 160 },
		playerPosition = { 480, 60 },

		{ "accuracy", "Accuracy" },
		{ "evasion", "Evasion" },
		{ "attack", "Attack" },
		{ "defense", "Defense" },
		{ "speed", "Speed" }
	},

	currentScrollIcon =
	{
		position = { 820, 16 }
	},

	messages =
	{
		attack = { hit = "Haiku attacks!", miss = "Haiku misses..." },
		parry = "Haiku is defending herself!",
		enchant = "Haiku prepares an enchantment...",
		escape = { hit = "Haiku escapes...", miss = "Haiku fails to flee!" }
	},

	tooltip = 
	{
		fontSize = 20,
		padding = 2,
		border = 2
	},

	energies =
	{
		position = { 720, 32 },

		{ "Left foot", 780, 60, 25 },
		{ "Right foot", 880, 60, 25 },
		{ "Sacrum", 835, 155, 25 },
		{ "Heart", 850, 265, 25 },
		{ "Left hand", 755, 380, 25 },
		{ "Right hand", 875, 380, 25 },
		{ "Head", 850, 460, 25 },
		{ "Soul", 760, 200, 37.5 },

		["Left foot"] = "leftFoot",
		["Right foot"] = "rightFoot",
		["Sacrum"] = "sacrum",
		["Heart"] = "heart",
		["Left hand"] = "leftHand",
		["Right hand"] = "rightHand",
		["Head"] = "head"
	},

	elements =
	{
		radius = 28,
		baseLine = 500,

		{ "Winter", 336 },
		{ "Spring", 432 },
		{ "Summer", 528 },
		{ "Autumn", 624 }
	},

	scrolls =
	{
		radius = 16,
		spacing = 48,
		padding = { 48, 48 },

		-- First column
		{ "Blizzard", 1, 1, "content/overlays/battle/scrolls/blizzard.lg" },
		{ "Regenerate", 1, 2, "content/overlays/battle/scrolls/regenerate.lg" },
		{ "Escape", 1, 3, "content/overlays/battle/scrolls/escape.lg" },
		{ "Defend", 1, 4, "content/overlays/battle/scrolls/defend.lg" },
		{ "Not yet named", 1, 5 },
		{ "Not yet named", 1, 6 },
		{ "Not yet named", 1, 7 },
		{ "Not yet named", 1, 8 },

		-- Second column
		{ "Not yet named", 2, 1 },
		{ "Not yet named", 2, 2 },
		{ "Not yet named", 2, 3 },
		{ "Not yet named", 2, 4 },
		{ "Not yet named", 2, 5 },
		{ "Not yet named", 2, 6 },
		{ "Not yet named", 2, 7 },
		{ "Not yet named", 2, 8 },

		-- Third column
		{ "Not yet named", 3, 1 },
		{ "Not yet named", 3, 2 },
		{ "Not yet named", 3, 3 },
		{ "Not yet named", 3, 4 },
		{ "Not yet named", 3, 5 },
		{ "Not yet named", 3, 6 },
		{ "Not yet named", 3, 7 },
		{ "Not yet named", 3, 8 },

		-- Fourth column
		{ "Not yet named", 4, 1 },
		{ "Not yet named", 4, 2 },
		{ "Not yet named", 4, 3 },
		{ "Not yet named", 4, 4 },
		{ "Not yet named", 4, 5 },
		{ "Not yet named", 4, 6 },
		{ "Not yet named", 4, 7 },
		{ "Not yet named", 4, 8 }
	}
}

local rules =
{
	energies =
	{
		leftFoot = 1,
		rightFoot = 2,
		sacrum = 3,
		heart = 4,
		leftHand = 5,
		rightHand = 6,
		head = 7,
		soul = 8
	},

	scrolls =
	{
		-- First column
		{ 
			elements = { "Winter", "Winter", "Winter", "Winter", "Winter", "Winter", "Winter", "Winter" },
			tag = { hit = "Haiku summons a blizzard!", miss = "The blizzard Haiku summoned missed..." },

			boost = function(m)
				m.accuracy = m.accuracy * 1.25
				m.attack = m.attack * 1.25
			end
		},

		{
			elements = { "Spring", "Spring", "Spring", "Spring", "Spring", "Spring", "Spring", "Spring" },
			tag = { hit = "Haiku channels energy into her wounds...", miss = "ERROR" },

			boost = function(m)
				m.evasion = m.evasion * 1.125
			end,
		},

		{ 
			elements = { "Summer", "Summer", "Summer", "Summer", "Summer", "Summer", "Summer", "Summer" },
			tag = { hit = "Haiku flees the battle!", miss = "Haiku fails to flee..." },

			boost = function(m)
				m.speed = m.speed * 2
			end
		},

		{
			elements = { "Autumn", "Autumn", "Autumn", "Autumn", "Autumn", "Autumn", "Autumn", "Autumn" },
			tag = { hit = "Haiku prepares to defend herself...", miss = "ERROR" },

			boost = function(m)
				m.evasion = m.evasion * 1.25
				m.defense = m.defense * 1.25
			end
		},

		{},
		{},
		{},
		{},

		-- Second column
		{},
		{},
		{},
		{},
		{},
		{},
		{},
		{},

		-- Third column
		{},
		{},
		{},
		{},
		{},
		{},
		{},
		{},

		-- Fourth column
		{},
		{},
		{},
		{},
		{},
		{},
		{},
		{}
	}
}

local function SelectElement(element)
	state.currentElement = element
end

local function PlaceElement(energyIndex, element)
	if game.state.player.energies[energyIndex] then
		state.player.energies[energyIndex] = element or state.currentElement
	end
end

local function ApplyScroll(index)
	for i = 1, #game.state.player.energies do
		PlaceElement(i, rules.scrolls[index].elements[i])
	end
end

local function IsAttackReady()
	for i = 1, #state.player.energies do
		if state.player.energies[i] == "" then
			if game.state.player.energies[i] then
				return false
			end
		end
	end

	return true
end

local function IsReady()
	if state.currentState == "selectMove" then
		return IsAttackReady()
	else
		if state.currentTime > theme.skip then
			return true
		end
	end

	return false
end

local function BounceMessage()
	if state.currentTime < theme.message.bounceSpeed then
		state.messageOffset = Math.Sin((state.currentTime / theme.message.bounceSpeed) * Math.Pi * 2 * theme.message.bounces) * theme.message.bounce
	else
		state.messageOffset = 0
	end
end

local function Continue(ignoreTime)
	local isSpacePressed = game.input.current.keyboard[Keycode.Space]

	if ignoreTime then
		if isSpacePressed or game.state.player.speedyBattleMode then
			return true
		end
	else
		if (isSpacePressed and (state.currentTime > theme.skip or state.currentTime > theme.speed)) or state.forceTransition or (game.state.player.speedyBattleMode and state.currentTime > theme.skip) then
			return true
		end
	end

	return false
end

local function MaxMultiplier()
	local energies = 0

	for i = 1, #game.state.player.energies do
		if game.state.player.energies[i] then
			energies = energies + 1
		end
	end

	-- Eight energy channels = 3x max multiplier...
	-- Two energy channels = 1.5x max multiplier...
	return energies / 4 + 1
end

local stateMachine = {}

local function OverButton(bx, by, br, x, y)
	local dx = bx - x
	local dy = by - y

	return (dx * dx + dy * dy) < (br * br)
end

local function Transition(to, ...)
	if state.currentState and stateMachine[state.currentState].Finish then
		stateMachine[state.currentState].Finish()
	end

	state.currentState = to
	stateMachine[to].Transition(...)

	state.forceTransition = false
end

-- Transition in state
stateMachine.transitionIn = {}
function stateMachine.transitionIn.Transition()
	resources.scenes.foregroundView:ChangeAnimation("Begin")

	local h = resources.scenes.foregroundView:FindObject("HaikuTotem")
	h.resource = {}
	h.resource.Draw = function()
		LG.Draw(resources.images.haiku, "haiku")
	end

	local e = resources.scenes.foregroundView:FindObject("OpponentTotem")
	e.resource = {}
	e.resource.Draw = function()
		LG.Draw(state.enemy.image, "enemy")
	end
end

function stateMachine.transitionIn.Finish()
	resources.scenes.foregroundView:FindObject("HaikuTotem").resource = nil
	resources.scenes.foregroundView:FindObject("OpponentTotem").resource = nil
end

function stateMachine.transitionIn.Update(delta)
	if resources.scenes.foregroundView:IsAnimationFinished() then
		if resources.scenes.foregroundView.currentAnimation == "Begin" then
			resources.scenes.foregroundView:ChangeAnimation("End", false)

			game.DisableStage()

			-- Show totems
			state.enemy.sceneView:ChangeAnimation("Intro")
			state.player.sceneView:ChangeAnimation("Intro")

			-- Play song
			if state.enemy.music then
				local _, s = game.audio:PlaySong(state.enemy.music.filename, true)

				if state.enemy.music.loopStart and state.enemy.music.loopEnd then
					s:Loop(state.enemy.music.loopStart, state.enemy.music.loopEnd)
				end
			end
		else
			Transition("beginTurn")
		end
	end
end

-- Begin turn (displays the opponent's action)
stateMachine.beginTurn = {}
stateMachine.beginTurn.isSkippable = true

function stateMachine.beginTurn.Transition()
	state.currentTime = 0
	state.messageOffset = 0
	state.currentElement = ""

	state.opponentMove = state.enemy.logic.Think(state.enemy)

	state.currentMessage = state.opponentMove.callbacks.onDisplay.message or ""

	state.enemy.sceneView:ChangeAnimation("Idle", false)
	state.player.sceneView:ChangeAnimation("Idle", false)
end

function stateMachine.beginTurn.Update(delta)
	state.currentTime = state.currentTime + delta

	BounceMessage()

	if state.currentTime >= theme.speed or Continue() then
		Transition("selectMove")
	end
end

-- Select move (lets the player select a special scroll or channel energy)
stateMachine.selectMove = {}
stateMachine.selectMove.isSkippable = true

function stateMachine.selectMove.Transition()
	stateMachine.selectMove.Hover(game.input.current.mouse.axes.x, game.input.current.mouse.axes.y)

	state.currentTime = 0
	state.isReady = true
end

function stateMachine.selectMove.Finish()
	state.currentTooltipMessage = nil
	state.currentElement = ""
end

function stateMachine.selectMove.Update(delta)
	if Continue(true) and IsAttackReady()  then
		Transition("calculateMove", state.currentScroll)
		state.currentScroll = nil
	end
end

function stateMachine.selectMove.Hover(x, y)
	state.currentTooltipPosition = { x, y }
	state.currentTooltipMessage = nil
	state.currentButtonCallback = nil

	-- First iterate through the scrolls
	for i = 1, #theme.scrolls do
		-- If there is a collision and the scroll is unlocked, apply it.
		if OverButton(theme.scrolls[i][2] * theme.scrolls.spacing, theme.scrolls[i][3] * theme.scrolls.spacing, theme.scrolls.radius, x, y) then
			if game.state.player.scrolls[i] then
				state.currentTooltipMessage = theme.scrolls[i][1]
				state.currentButtonCallback = function()
					state.currentScroll = i
					ApplyScroll(i)
				end
			else
				state.currentTooltipMessage = "???"
			end

			return true
		end
	end

	-- Then through the element buttons
	for i = 1, #theme.elements do
		if OverButton(theme.elements[i][2], theme.elements.baseLine, theme.elements.radius, x, y) then
			state.currentTooltipMessage = theme.elements[i][1]
			state.currentButtonCallback = function()
				SelectElement(theme.elements[i][1])
			end

			return true
		end
	end

	-- Lastly, through the tree
	for i  = 1, #theme.energies do
		if OverButton(theme.energies[i][2], theme.energies[i][3], theme.energies[i][4], x, y) then
			if game.state.player.energies[i] then
				state.currentTooltipMessage = theme.energies[i][1]
				state.currentButtonCallback = function()
					state.currentScroll = nil
					PlaceElement(i)
				end
			else
				state.currentTooltipMessage = "???"
			end

			return true
		end
	end

	return false
end

function stateMachine.selectMove.Click(x, y)
	local r = stateMachine.selectMove.Hover(x, y)

	if r and state.currentButtonCallback then
		state.currentButtonCallback()
	else
		state.currentElement = ""
	end

	return r
end

-- Calculate move (determines if a move misses as well as the damage and enchantments of a move)
stateMachine.calculateMove = {}

function stateMachine.calculateMove.Transition(scroll)
	-- Get the primary type of the move.
	local primary = state.player.energies[rules.energies.head]
	local moveType

	local multipliers =
	{
		accuracy = 1,
		evasion = 1,
		attack = 1,
		defense = 1,
		speed = 1
	}

	-- Every use of an element decreases the effectiveness of the next of the same
	-- type...
	local winter, spring, summer, autumn = 0.25, 0.25, 0.25, 0.25

	local healthBoost = 0

	if primary == "Winter" then -- Offense
		moveType = "attack"

		for i = 1, #state.player.energies do
			if game.state.player.energies[i] then
				local energy = state.player.energies[i]

				if energy == "Winter" then
					multipliers.attack = multipliers.attack + winter
					winter = winter / 2
				elseif energy == "Spring" then
					multipliers.accuracy = multipliers.accuracy + spring
					spring = spring / 2
				elseif energy == "Summer" then
					multipliers.speed = multipliers.speed + summer
					sumemr = summer / 2
				elseif energy == "Autumn" then
					multipliers.evasion = multipliers.evasion + autumn
					autumn = autumn / 2
				end
			end
		end
	elseif primary == "Spring" then -- Enchantment
		moveType = "enchant"

		for i = 1, #state.player.energies do
			if game.state.player.energies[i] then
				local energy = state.player.energies[i]

				if energy == "Winter" then
					multipliers.attack = multipliers.attack + winter
					winter = winter / 2
				elseif energy == "Spring" then
					healthBoost = healthBoost + game.state.player.baseStats.health * (spring / 4)
					spring = spring / 2
				elseif energy == "Summer" then
					multipliers.speed = multipliers.speed + summer
					summer = summer / 2
				elseif energy == "Autumn" then
					multipliers.defense = multipliers.defense + autumn
					autumn = autumn / 2
				end
			end
		end
	elseif primary == "Summer" then -- Speed
		moveType = "escape"

		for i = 1, #state.player.energies do
			if game.state.player.energies[i] then
				local energy = state.player.energies[i]

				if energy == "Winter" then
					multipliers.accuracy = multipliers.accuracy + winter
					winter = winter / 2

					moveType = "enchant"
				elseif energy == "Spring" then
					multipliers.evasion = multipliers.evasion + spring
					spring = spring / 2

					moveType = "enchant"
				elseif energy == "Autumn" then
					multipliers.defense = multipliers.defense + autumn
					autumn = autumn / 2

					moveType = "enchant"
				elseif energy == "Summer" then
					multipliers.speed = multipliers.speed + summer
					sumemr = summer / 2
				end
			end
		end
	elseif primary == "Autumn" then -- Defense
		moveType = "parry"

		for i = 1, #state.player.energies do
			if game.state.player.energies[i] then
				local energy = state.player.energies[i]

				if energy == "Winter" then
					multipliers.evasion = multipliers.evasion + winter
					winter = winter / 2
				elseif energy == "Spring" then
					healthBoost = healthBoost + game.state.player.baseStats.health * (spring / 8)
					spring = spring / 2
				elseif energy == "Summer" then
					multipliers.speed = multipliers.speed + summer
					sumemr = summer / 2
				elseif energy == "Autumn" then
					multipliers.defense = multipliers.defense + autumn
					autumn = autumn / 2
				end
			end
		end
	end

	if scroll then
		rules.scrolls[scroll].boost(multipliers)

		state.scrollMessage = rules.scrolls[scroll].tag
	end

	Transition("showMove", moveType, multipliers, healthBoost)
end

local function ApplyPlayerDamage(damage)
	state.player.currentStats.health = Math.Clamp(state.player.currentStats.health - damage, 0, game.state.player.baseStats.health)
end

local function ApplyEnemyDamage(damage)
	state.enemy.currentStats.health = Math.Clamp(state.enemy.currentStats.health - damage, 0, state.enemy.baseStats.health)
end

local function ApplyPlayerEnchantment(multipliers, healthBoost, callback)
	ApplyPlayerDamage(-healthBoost)
	local maxMultiplier = MaxMultiplier()

	for i = 1, #theme.stats do
		local stat = theme.stats[i][1]
		local max = game.state.player.currentStats[stat] * maxMultiplier
		state.player.currentStats[stat] = Math.Min(multipliers[stat] * state.player.currentStats[stat], max)
	end

	if state.scrollMessage then
		state.currentMessage = state.scrollMessage.hit
		state.scrollMessage = nil
	else
		state.currentMessage = theme.messages.enchant
	end

	Transition("playerTurn", "Enchantment", callback or function()
		Transition("endTurn")
	end)
end

local function ApplyPlayerEscape(success, callback)
	if success then
		if state.scrollMessage then
			state.currentMessage = state.scrollMessage.hit
			state.scrollMessage = nil
		else
			state.currentMessage = theme.messages.escape.hit
		end

		Transition("playerTurn", "Escape", function()
			Transition("endBattle", "escape")
		end)
	else
		if state.scrollMessage then
			state.currentMessage = state.scrollMessage.miss
			state.scrollMessage = nil
		else
			state.currentMessage = theme.messages.escape.miss
		end

		Transition("playerTurn", "Escape", callback)
	end
end

local function ApplyPlayerParry(multipliers, healthBoost, callback)
	ApplyPlayerDamage(-healthBoost)
	state.player.moveMultipliers = multipliers

	if state.scrollMessage then
		state.currentMessage = state.scrollMessage.hit
		state.scrollMessage = nil
	else
		state.currentMessage = theme.messages.parry
	end

	Transition("playerTurn", "Parry", callback or function()
		Transition("endTurn")
	end)
end

local function ApplyPlayerAttack(multipliers, first, callback)
	state.player.moveMultipliers = multipliers

	local rawAccuracy = state.player.moveMultipliers.accuracy * state.player.currentStats.accuracy
	local rawDamage = state.player.moveMultipliers.attack * state.player.currentStats.attack
	local accuracy, damage

	if first then
		accuracy = rawAccuracy - state.enemy.currentStats.evasion
		damage = rawDamage - state.enemy.currentStats.defense
	else
		accuracy = rawAccuracy - state.enemy.currentStats.evasion * state.opponentMove.stats.evasion
		damage = rawDamage - state.enemy.currentStats.defense * state.opponentMove.stats.defense
	end

	local attack = {}
	attack.rawDamage = rawDamage
	attack.damage = damage
	attack.rawAccuracy = rawAccuracy
	attack.accuracy = accuracy

	state.player.landedBlow = true
	local enemyResult
	local playerResult

	if accuracy <= 0 then
		state.player.landedBlow = false
		enemyResult = "Dodge"
		playerResult = "Tumble"
	elseif damage <= 0 then
		state.player.landedBlow = false
		enemyResult = "Dodge"
		playerResult = "Tumble"
	else
		ApplyEnemyDamage(damage)

		enemyResult = "Hit"
		playerResult = "Attack"

		state.player.lastAttack = attack
	end

	if state.scrollMessage then
		if not state.player.landedBlow then
			state.currentMessage = state.scrollMessage.miss
		else
			state.currentMessage = state.scrollMessage.hit
		end

		state.scrollMessage = nil
	else
		if not state.player.landedBlow then
			state.currentMessage = theme.messages.attack.miss
		else
			state.currentMessage = theme.messages.attack.hit
		end
	end

	state.enemy.sceneView:ChangeAnimation(enemyResult, false)
	state.player.sceneView:ChangeAnimation(playerResult, false)

	Transition("playerTurn", "Attack", callback or function()
		Transition("endTurn")
	end)
end

local function ApplyOpponentAttack(callback)
	local damage = state.opponentMove.stats.attack * state.enemy.currentStats.attack - state.player.currentStats.defense * state.player.moveMultipliers.defense
	local accuracy = state.opponentMove.stats.accuracy * state.enemy.currentStats.accuracy - state.player.currentStats.evasion * state.player.moveMultipliers.evasion

	local attack = {}
	attack.rawDamage = state.opponentMove.stats.attack * state.enemy.currentStats.attack
	attack.damage = Math.Max(damage, 0)
	attack.rawAccuracy = state.opponentMove.stats.accuracy * state.enemy.currentStats.accuracy
	attack.accuracy = Math.Max(accuracy, 0)

	local enemyResult
	local playerResult

	if accuracy <= 0 then
		-- Play missed attack
		if state.opponentMove.callbacks.onMiss.callback then
			state.opponentMove.callbacks.onMiss.callback(state.enemy, attack)
		end

		enemyResult = "Tumble"
		playerResult = "Dodge"
		state.currentMessage = state.opponentMove.callbacks.onMiss.message
	elseif damage <= 0 then
		-- Play futile attack
		if state.opponentMove.callbacks.onMiss.callback then
			state.opponentMove.callbacks.onMiss.callback(state.enemy, attack)
		end

		enemyResult = "Tumble"
		playerResult = "Dodge"
		state.currentMessage = state.opponentMove.callbacks.onMiss.message
	else
		-- Play successful attack
		ApplyPlayerDamage(damage)

		if state.opponentMove.callbacks.onHit.callback then
			state.opponentMove.callbacks.onHit.callback(state.enemy, attack)
		end

		enemyResult = "Attack"
		playerResult = "Hit"
		state.currentMessage = state.opponentMove.callbacks.onHit.message
	end

	state.enemy.sceneView:ChangeAnimation(enemyResult, false)
	state.player.sceneView:ChangeAnimation(playerResult, false)
	Transition("enemyTurn", callback or function()
		Transition("endTurn")
	end)
end

local function ApplyOpponentParry(callback)
	if state.opponentMove.type == "enchantment" then
		if state.opponentMove.callbacks.onHit.callback then
			state.opponentMove.callbacks.onHit.callback(state.enemy)
		end

		state.currentMessage = state.opponentMove.callbacks.onHit.message
	else
		if state.player.landedBlow then
			if state.opponentMove.callbacks.onHit.callback and state.opponentMove.type == "parry" then
				state.opponentMove.callbacks.onHit.callback(state.enemy, state.player.lastAttack)
			end

			state.currentMessage = state.opponentMove.callbacks.onHit.message
		else
			if state.opponentMove.callbacks.onMiss.callback and state.opponentMove.type == "parry" then
				state.opponentMove.callbacks.onMiss.callback(state.enemy, attack)
			end

			state.currentMessage = state.opponentMove.callbacks.onMiss.message
		end
	end

	Transition("enemyTurn", callback or function()
		Transition("endTurn")
	end)
end

-- Figures out who goes first
stateMachine.showMove = {}

function stateMachine.showMove.Transition(moveType, multipliers, healthBoost)
	state.player.moveMultipliers =
	{
		accuracy = 1,
		evasion = 1,
		attack = 1,
		defense = 1,
		speed = 1
	}

	local enemySpeed = state.enemy.currentStats.speed * state.opponentMove.stats.speed

	if moveType == "attack" then
		local playerSpeed = state.player.currentStats.speed * multipliers.speed

		if state.opponentMove.type == "parry" or enemySpeed < playerSpeed then
			ApplyPlayerAttack(multipliers, state.opponentMove.type == "parry", function()
				if state.opponentMove.type == "attack" then
					ApplyOpponentAttack()
				else
					ApplyOpponentParry()
				end
			end)
		else
			if state.opponentMove.type == "enchantment" then
				ApplyOpponentParry(function()
					ApplyPlayerAttack(multipliers, false)
				end)
			else
				ApplyOpponentAttack(function()
					if state.player.currentStats.health == 0 then
						Transition("endBattle", "defeat")
					else
						ApplyPlayerAttack(multipliers, false)
					end
				end)
			end
		end
	elseif moveType == "enchant" then
		if state.opponentMove.type == "parry" or enemySpeed < state.player.currentStats.speed then
			ApplyPlayerEnchantment(multipliers, healthBoost, function()
				if state.opponentMove.type == "attack" then
					ApplyOpponentAttack()
				else
					ApplyOpponentParry()
				end
			end)
		else
			if state.opponentMove.type == "attack" then
				ApplyOpponentAttack(function()
					if state.player.currentStats.health == 0 then
						Transition("endBattle", "defeat")
					else
						ApplyPlayerEnchantment(multipliers, healthBoost, speed)
					end
				end)
			else
				ApplyOpponentParry(function()
					ApplyPlayerEnchantment(multipliers, healthBoost, speed)
				end)
			end
		end
	elseif moveType == "parry" then
		local playerSpeed = state.player.currentStats.speed * multipliers.speed

		if state.opponentMove.type == "parry" or state.opponentMove.type == "enchantment" then
			if playerSpeed < enemySpeed then
				ApplyOpponentParry(function()
					if state.player.currentStats.health == 0 then
						Transition("endBattle", "defeat")
					else
						ApplyPlayerParry(multipliers, healthBoost)
					end
				end)
			else
				ApplyPlayerParry(multipliers, healthBoost, function()
					ApplyOpponentParry()
				end)
			end
		else
			ApplyPlayerParry(multipliers, healthBoost, function()
				ApplyOpponentAttack()
			end)
		end
	elseif moveType == "escape" then
		local playerSpeed = state.player.currentStats.speed * multipliers.speed

		ApplyPlayerEscape(playerSpeed > enemySpeed, function()
			if state.opponentMove.type == "attack" then
				ApplyOpponentAttack()
			else
				ApplyOpponentParry()
			end
		end)
	end
end

-- Shows the player's turn
-- TODO: Allow animations
stateMachine.playerTurn = {}
stateMachine.playerTurn.isSkippable = true

function stateMachine.playerTurn.Transition(type, callback)
	state.continueCallback = callback
	state.currentTime = 0
end

function stateMachine.playerTurn.Update(delta)
	state.currentTime = state.currentTime + delta

	BounceMessage()

	if Continue() and state.enemy.sceneView:IsAnimationFinished() and state.player.sceneView:IsAnimationFinished() then
		state.continueCallback()
	end
end

-- Show's the enemy's turn
-- TODO: Implement animations
stateMachine.enemyTurn = {}
stateMachine.enemyTurn.isSkippable = true

function stateMachine.enemyTurn.Transition(callback)
	state.continueCallback = callback
	state.currentTime = 0

	if state.enemy.currentStats.health == 0 then
		Transition("endBattle", "victory")
	end
end

function stateMachine.enemyTurn.Update(delta)
	state.currentTime = state.currentTime + delta

	BounceMessage()

	if Continue() and state.enemy.sceneView:IsAnimationFinished() and state.player.sceneView:IsAnimationFinished() then
		state.continueCallback()
	end
end

-- Ends the turn.
stateMachine.endTurn = {}
stateMachine.endTurn.isSkippable = true

function stateMachine.endTurn.Transition()
	state.currentMessage = "The turn has ended..."

	for i = 1, #state.player.energies do
		state.player.energies[i] = ""
	end

	state.currentTime = 0
	state.player.landedBlow = false

	local maxMultiplier = MaxMultiplier()

	-- Restore base player stats slowly...
	-- Should take 16 turns to reduce stat from max to base.
	for i = 1, #theme.stats do
		local stat = theme.stats[i][1]
		local base = game.state.player.baseStats[stat]
		local adjustment = (base * maxMultiplier) / 16

		state.player.currentStats[stat] = Math.Max(state.player.currentStats[stat] - adjustment, base)
	end
end

function stateMachine.endTurn.Update(delta)
	state.currentTime = state.currentTime + delta

	BounceMessage()

	if Continue() then
		if state.enemy.currentStats.health == 0 then
			Transition("endBattle", "victory")
		elseif state.player.currentStats.health == 0 then
			Transition("endBattle", "defeat")
		else
			Transition("beginTurn")
		end
	end
end

-- End of a battle.
stateMachine.endBattle = {}

function stateMachine.endBattle.Transition(type)
	if type == "escape" then
		state.currentMessage = "Escaped!"
	elseif type == "victory" then
		state.currentMessage = "Victory!"
	elseif type == "defeat" then
		state.currentMessage = "Defeated!"
	end

	state.currentTime = 0
	state.successValue = type
	state.messageBounceDone = false
end

function stateMachine.endBattle.Update(delta)
	if state.messageBounceDone then
		if resources.scenes.foregroundView:IsAnimationFinished() then
			if state.currentTime - theme.message.bounceSpeed > theme.skip then
				EndBattle()
			else
				state.currentTime = state.currentTime + delta

				if state.currentTime - theme.message.bounceSpeed > theme.skip then
					game.EnableStage()

					if state.preCallback then
						state.preCallback()
					end
					
					resources.scenes.foregroundView:ChangeAnimation("End")
					resources.scenes.foregroundView:Update(0)
				end
			end
		end
	else
		state.currentTime = state.currentTime + delta
		BounceMessage()

		if state.currentTime > theme.message.bounceSpeed then
			state.messageBounceDone = true

			resources.scenes.foregroundView:ChangeAnimation("Close")
			resources.scenes.foregroundView:Update(0)
		end
	end
end

local function LoadEnemyDescription(path)
	local success, ret = load({}, path)
	
	if not success then
		error(ret)
	end
	
	return ret
end

local Move = {}

function Move:AddMessage(name, message)
	if self.callbacks[name] ~= nil then
		self.callbacks[name].message = message
	end
end

function Move:AddCallback(name, func)
	if self.callbacks[name] ~= nil then
		self.callbacks[name].callback = func
	end
end

local function CreateMove(name, type)
	local m =
	{
		name = name,
		type = type,

		callbacks =
		{
			onDisplay = { message = "" },
			onHit = { message = "" },
			onMiss = { message = "" },
		},

		stats =
		{
			accuracy = 1,
			evasion = 1,
			attack = 1,
			defense = 1,
			speed = 1
		}
	}

	m.AddMessage = Move.AddMessage
	m.AddCallback = Move.AddCallback

	return m
end

local function CreateAttack(name)
	return CreateMove(name, "attack")
end

local function CreateParry(name)
	return CreateMove(name, "parry")
end

local function CreateEnchantment(name)
	return CreateMove(name, "enchantment")
end

local function LoadEnemyLogic(path, e)
	local enemy = sandbox()
	enemy.Attack = CreateAttack
	enemy.Parry = CreateParry
	enemy.Enchantment = CreateEnchantment

	local success, ret = load(enemy, path, e)

	if not success then
		error(ret)
	end

	return enemy
end

local function CreateEnemy(description)
	local enemy = {}

	enemy.currentStats =
	{
		health = description.stats.health,
		accuracy = description.stats.accuracy,
		evasion = description.stats.evasion,
		attack = description.stats.attack,
		defense = description.stats.defense,
		speed = description.stats.speed
	}

	enemy.baseStats =
	{
		health = description.stats.health,
		accuracy = description.stats.accuracy,
		evasion = description.stats.evasion,
		attack = description.stats.attack,
		defense = description.stats.defense,
		speed = description.stats.speed
	}

	enemy.state = description.state

	return enemy
end

local function LoadEnemy(path)
	local desc = LoadEnemyDescription(path)
	local enemy = CreateEnemy(desc)
	enemy.logic = LoadEnemyLogic(desc.logic, enemy)
	enemy.image = LG.Compile(LG.Load(desc.image), settings().quality)
	enemy.music = desc.music
	enemy.scene = Story.Scene.Load(desc.scene)
	enemy.sceneView = Story.Scene.Viewer.Create(enemy.scene)
	enemy.name = desc.name or "Opponent"

	return enemy
end

function Battle(enemy, callback, preCallback)
	state.enemy = LoadEnemy(enemy)
	state.callback = callback
	state.preCallback = preCallback

	Transition("transitionIn")
	state.currentTime = 0

	state.messageOffset = 0

	-- Tooltip stuff; set during hover/click events
	state.currentTooltipMessage = nil
	state.currentTooltipPosition = { 0, 0 }
	state.currentButtonCallback = nil

	resources.scenes.backgroundView:ChangeAnimation("Default")

	state.player.currentStats =
	{
		health = game.state.player.currentStats.health,
		accuracy = game.state.player.currentStats.accuracy,
		evasion = game.state.player.currentStats.evasion,
		attack = game.state.player.currentStats.attack,
		defense = game.state.player.currentStats.defense,
		speed = game.state.player.currentStats.speed
	}

	state.player.energies =
	{
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		""
	}

	state.currentElement = ""
	state.currentMessage = ""
end

function EndBattle()
	game.ExitOverlay()

	state.callback(state.successValue)
end

function Update(delta)
	resources.scenes.backgroundView:Update(delta)
	resources.scenes.foregroundView:Update(delta)

	state.enemy.sceneView:Update(delta)
	state.player.sceneView:Update(delta)

	if stateMachine[state.currentState].Update then
		stateMachine[state.currentState].Update(delta)
	end

	if theme.speedButton.active(game.input.current.mouse.axes.x, game.input.current.mouse.axes.y) then
		state.currentTooltipMessage = theme.speedButton.tooltip
		state.currentTooltipPosition = { game.input.current.mouse.axes.x, game.input.current.mouse.axes.y }
	end
end

local function DrawStats(x, y, name, currentStats, baseStats)
	local margin = theme.stats.padding + theme.stats.border

	-- Border
	do
		local totalMargin = margin * 2
		resources.colors.foreground:Fill(x, y, theme.stats.size[1] + totalMargin, theme.stats.size[2] + totalMargin)
		resources.colors.background:Fill(x + theme.stats.border, y + theme.stats.border, theme.stats.size[1] + theme.stats.padding * 2, theme.stats.size[2] + theme.stats.padding * 2)
	end

	-- Name
	do
		-- Adjust position
		local ax = x + margin
		local ay = y + theme.stats.size[2] - theme.stats.lineHeight

		resources.fonts.stats:DrawText(resources.colors.foreground, ax, ay, name)
	end

	-- Stats
	do
		local ax = x + margin
		local ay = y + theme.stats.size[2] - theme.stats.lineHeight * 2

		for i = 1, #theme.stats do
			resources.fonts.stats:DrawText(resources.colors.foreground, ax, ay, theme.stats[i][2] .. ":")
			resources.fonts.stats:DrawText(resources.colors.foreground, ax + theme.stats.statOffset, ay, format("%d", currentStats[theme.stats[i][1]]))

			ay = ay - theme.stats.lineHeight
		end
	end

	-- Health
	do
		local ax = x + margin
		local ay = y + margin

		resources.fonts.stats:DrawText(resources.colors.foreground, ax, ay, "Health:")
		resources.fonts.stats:DrawText(resources.colors.foreground, ax + theme.stats.statOffset, ay, format("%d%%", Math.Ceil(currentStats.health / baseStats.health * 100)))
	end
end

function Draw()
	if not game.IsStageVisible() then
		resources.colors.background:Fill(0, 0, Screen.Width, Screen.Height)
		resources.scenes.backgroundView:Draw()

		-- Enemy and player
		do
			state.enemy.sceneView:Draw()
			state.player.sceneView:Draw()
		end

		-- Scrolls
		do
			for i = 1, #theme.scrolls do
				local x = theme.scrolls[i][2] * theme.scrolls.padding[1]
				local y = theme.scrolls[i][3] * theme.scrolls.padding[2]

				LG.Draw(resources.images.buttons, "button1", 1, x, y)

				if game.state.player.scrolls[i] and resources.images.scrolls[i] then
					LG.Draw(resources.images.scrolls[i], "icon", 1, x, y)
				end
			end
		end

		-- Element buttons
		do
			for i = 1, #theme.elements do
				LG.Draw(resources.images.elements, theme.elements[i][1]:lower(), 1, theme.elements[i][2], theme.elements.baseLine)
			end
		end

		-- Tree motifs
		do
			for i = 1, #theme.energies do
				local part = theme.energies[theme.energies[i][1]]

				if part and game.state.player.energies[i] and state.player.energies[i] ~= "" then
					LG.Draw(resources.images.tree[state.player.energies[i]:lower()], part, 1, theme.energies.position[1], theme.energies.position[2])
				end
			end
		end

		-- Current scroll
		if state.currentScroll and resources.images.scrolls[state.currentScroll] then
			LG.Draw(resources.images.scrolls[state.currentScroll], "icon", 1, theme.currentScrollIcon.position[1], theme.currentScrollIcon.position[2])
		end

		-- Energies
		do
			Graphics.PushView()

			for i = 1, #theme.energies do
				local pos = Matrix.Translate(theme.energies[i][2], theme.energies[i][3], 0)
				local s = theme.energies[i][4] / theme.elements.radius
				local scale = Matrix.Scale(s, s, 1)

				Graphics.SetView(pos * scale)

				if game.state.player.energies[i] then
					if state.player.energies[i] ~= "" then
						LG.Draw(resources.images.elements, state.player.energies[i]:lower())
					else
						LG.Draw(resources.images.elements, "empty")
					end
				else
					LG.Draw(resources.images.elements, "blocked")
				end
			end

			Graphics.PopView()
		end

		-- Helpful message
		do
			resources.fonts.message:DrawText(resources.colors.foreground, theme.message.position[1], theme.message.position[2] + state.messageOffset, state.currentMessage or "")
		end

		-- Current element
		do
			if state.currentElement ~= "" then
				LG.Draw(resources.images.elements, state.currentElement:lower(), 1, game.input.current.mouse.axes.x, game.input.current.mouse.axes.y)
			end
		end

		-- Ready button
		do
			if IsReady() and not game.state.player.speedyBattleMode then
				local _, _, width = resources.fonts.message:Measure(state.currentMessage or "")

				LG.Draw(resources.images.buttons, "button2", 1, theme.message.position[1] + width, theme.message.position[2])
			end
		end

		-- Speed mode button
		do
			if not theme.speedButton.active(game.input.current.mouse.axes.x, game.input.current.mouse.axes.y) then
				resources.colors.foreground:SetAlpha(0.5)
			end

			resources.fonts.speedButton:DrawText(resources.colors.foreground, theme.speedButton.position[1], theme.speedButton.position[2], theme.speedButton.text[game.state.player.speedyBattleMode or false])

			resources.colors.foreground:SetAlpha(1.0)
		end

		-- Stats
		do
			if not theme.showStats.active(game.input.current.mouse.axes.x, game.input.current.mouse.axes.y) then
				resources.colors.foreground:SetAlpha(0.5)
			else
				DrawStats(theme.stats.enemyPosition[1], theme.stats.enemyPosition[2], state.enemy.name, state.enemy.currentStats, state.enemy.baseStats)
				DrawStats(theme.stats.playerPosition[1], theme.stats.playerPosition[2], "Haiku", state.player.currentStats, game.state.player.baseStats)
			end

			resources.fonts.stats:DrawText(resources.colors.foreground, theme.showStats.position[1], theme.showStats.position[2], theme.showStats.text)

			resources.colors.foreground:SetAlpha(1)
		end

		if state.currentTooltipMessage then
			local fx, fh, fw = resources.fonts.tooltip:Measure(state.currentTooltipMessage)
			local x = state.currentTooltipPosition[1]
			local y = state.currentTooltipPosition[2]
			local width = fw + theme.tooltip.border * 2 + theme.tooltip.padding * 2
			local height = fh + theme.tooltip.border * 2 + theme.tooltip.padding * 2

			if x + width > Screen.Width then
				x = x - width
			end

			resources.colors.foreground:Fill(x, y, width, height)
			resources.colors.background:Fill(x + theme.tooltip.border, y + theme.tooltip.border, width - theme.tooltip.border * 2, height - theme.tooltip.border * 2)
			resources.fonts.tooltip:DrawText(resources.colors.foreground, x + theme.tooltip.border + theme.tooltip.padding, y + theme.tooltip.border + theme.tooltip.padding, state.currentTooltipMessage)
		end
	end

	resources.scenes.foregroundView:Draw()
end

function Hover(x, y)
	state.currentTooltipMessage = nil

	if stateMachine[state.currentState].Hover then
		stateMachine[state.currentState].Hover(x, y)
	end
end

function Click(x, y)
	if stateMachine[state.currentState].Click then
		stateMachine[state.currentState].Click(x, y)
	end

	if theme.speedButton.active(x, y) then
		game.state.player.speedyBattleMode = not game.state.player.speedyBattleMode
	end
end

local function Create(gameState)
	game = gameState

	resources.scenes = {}
	resources.scenes.background = Story.Scene.Load("content/overlays/battle/backgroundScene.lua")
	resources.scenes.backgroundView = Story.Scene.Viewer.Create(resources.scenes.background)

	resources.scenes.foreground = Story.Scene.Load("content/overlays/battle/foregroundScene.lua")
	resources.scenes.foregroundView = Story.Scene.Viewer.Create(resources.scenes.foreground)

	resources.fonts = {}
	resources.fonts.tooltip = Font.Load("content/fonts/normal.ttf", theme.tooltip.fontSize, settings().quality)
	resources.fonts.message = Font.Load("content/fonts/normal.ttf", theme.message.fontSize, settings().quality)
	resources.fonts.speedButton = Font.Load("content/fonts/normal.ttf", theme.speedButton.fontSize, settings().quality)
	resources.fonts.stats = Font.Load("content/fonts/normal.ttf", theme.showStats.fontSize, settings().quality)

	resources.colors = {}
	resources.colors.background = GraphicsUtility.CreatePaint(Color.Create(1, 1, 1, 1))
	resources.colors.foreground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 1))

	resources.images = {}
	resources.images.buttons = LG.Compile(LG.Load("content/overlays/battle/background.lg"), settings().quality)
	resources.images.elements = LG.Compile(LG.Load("content/overlays/battle/elements.lg"), settings().quality)
	resources.images.haiku = LG.Compile(LG.Load("content/overlays/battle/haiku.lg"), settings().quality)

	resources.images.tree = {}
	resources.images.tree.winter = LG.Compile(LG.Load("content/overlays/battle/tree/winter.lg"), settings().quality)
	resources.images.tree.spring = LG.Compile(LG.Load("content/overlays/battle/tree/spring.lg"), settings().quality)
	resources.images.tree.summer = LG.Compile(LG.Load("content/overlays/battle/tree/summer.lg"), settings().quality)
	resources.images.tree.autumn = LG.Compile(LG.Load("content/overlays/battle/tree/autumn.lg"), settings().quality)

	resources.images.scrolls = {}
	for i = 1, #theme.scrolls do
		if theme.scrolls[i][4] then
			resources.images.scrolls[i] = LG.Compile(LG.Load(theme.scrolls[i][4]), settings().quality)
		end
	end

	state.player = {}
	state.player.scene = Story.Scene.Load("content/battle/haiku/haiku1.scene")
	state.player.sceneView = Story.Scene.Viewer.Create(state.player.scene)
end

Create(...)
