local resources = {}
local state = {}
local game

local theme =
{
	speed = 1,

	closeButton =
	{
		fontSize = 40,
		text = "[close inventory]",

		bounds = { 32, 480, 250, 40 }
	},

	leftSpot =
	{
		start = 0,
		width = 60
	},

	rightSpot =
	{
		start = 900,
		width = 60
	},

	itemName =
	{
		fontSize = 32,
		position = { 120, 100 }
	},

	itemDescription =
	{
		fontSize = 22,
		position = { 120, 70 }
	},
	
	newItem =
	{
		fontSize = 24,
		text = "Obtained new item!",
		
		position = { 650, 20 }
	}
}

local function LoadItem()
	if resources.currentItem then
		LG.Destroy(resources.currentItem)
	end

	local success, value = load({}, game.state.player.inventory[state.currentItem])

	if not success then
		error(value)
	end

	resources.currentItem = LG.Compile(LG.Load(value.image), settings().quality)
	state.currentItemName = value.name
	state.currentItemDescription = value.description
end

function ShowInventory(index, newItem)
	state.currentTime = 0
	state.isExiting = false
	state.showNewItem = newItem or false

	state.transition = Transition.Create(theme.speed, theme.speed)

	state.currentItem = index or 1
	LoadItem()
end

function HideInventory()
	state.transition:Switch(Transition.Type.Out)
	state.isExiting = true
end

function Update(delta)
	state.transition:Update(delta)

	if state.isExiting and state.transition.isDone then
		game.ExitOverlay()
	end
end

function Draw()
	-- Background
	do
		resources.colors.background:SetAlpha(state.transition.normal)
		resources.colors.background:Fill(0, 0, Screen.Width, Screen.Height)
	end

	-- Current item
	do
		Graphics.PushBlenderMode()
		Graphics.SetBlenderMode(BlenderMode.TintAlpha)
		Graphics.SetBlenderTint(Color.Create(0, 0, 0, state.transition.normal))

		LG.Draw(resources.currentItem, "item", 1, Screen.Width / 2, Screen.Height / 2)

		resources.fonts.itemName:DrawText(resources.colors.foreground, theme.itemName.position[1], theme.itemName.position[2], state.currentItemName)
		resources.fonts.itemDescription:DrawText(resources.colors.foreground, theme.itemDescription.position[1], theme.itemDescription.position[2], state.currentItemDescription)

		Graphics.PopBlenderMode()
	end

	-- Left button
	do
		local x = (1 - state.transition.normal) * -450

		LG.Draw(resources.buttons, "left", 1, x, 0)
	end

	-- Right button
	do
		local x = (1 - state.transition.normal) * 450

		LG.Draw(resources.buttons, "right", 1, x, 0)
	end

	-- Close button
	do
		local x = (1 - state.transition.normal) * -450 + theme.closeButton.bounds[1]

		if MathUtil.Primitives.PointInRectangle(theme.closeButton.bounds[1], theme.closeButton.bounds[2], theme.closeButton.bounds[3], theme.closeButton.bounds[4], game.input.current.mouse.axes.x, game.input.current.mouse.axes.y) and not state.isExiting then
			resources.colors.foreground:SetAlpha(1)
		else
			resources.colors.foreground:SetAlpha(0.5)
		end

		resources.fonts.close:DrawText(resources.colors.foreground, x, theme.closeButton.bounds[2], theme.closeButton.text)
		
		resources.colors.foreground:SetAlpha(1)
	end
	
	-- New item text
	if state.showNewItem then
		local x = (1 - state.transition.normal) * 450 + theme.newItem.position[1]
		
		resources.fonts.newItem:DrawText(resources.colors.foreground, x, theme.newItem.position[2], theme.newItem.text)
	end
end

local function Next()
	if state.currentItem < #game.state.player.inventory then
		state.currentItem = state.currentItem + 1
	else
		state.currentItem = 1
	end
	
	state.showNewItem = false

	LoadItem()
end

local function Previous()
	if state.currentItem > 1 then
		state.currentItem = state.currentItem - 1
	else
		state.currentItem = #game.state.player.inventory
	end
	
	state.showNewItem = false

	LoadItem()
end

function Hover(x, y)
end

function Click(x, y)
	if MathUtil.Primitives.PointInRectangle(theme.closeButton.bounds[1], theme.closeButton.bounds[2], theme.closeButton.bounds[3], theme.closeButton.bounds[4], x, y) then
		HideInventory()
	else
		if x >= theme.leftSpot.start and x <= theme.leftSpot.start + theme.leftSpot.width then
			Next()
		elseif x >= theme.rightSpot.start and x <= theme.rightSpot.start + theme.rightSpot.width then
			Previous()
		end
	end
end

local function Create(gameState)
	game = gameState

	resources.colors = {}
	resources.colors.foreground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 1))
	resources.colors.background = GraphicsUtility.CreatePaint(Color.Create(1, 1, 1, 1))

	resources.fonts = {}
	resources.fonts.close = Font.Load("content/fonts/normal.ttf", theme.closeButton.fontSize, settings().quality)
	resources.fonts.newItem = Font.Load("content/fonts/normal.ttf", theme.newItem.fontSize, settings().quality)
	resources.fonts.itemName = Font.Load("content/fonts/normal.ttf", theme.itemName.fontSize, settings().quality)
	resources.fonts.itemDescription = Font.Load("content/fonts/normal.ttf", theme.itemDescription.fontSize, settings().quality)

	resources.buttons = LG.Compile(LG.Load("content/overlays/inventory/buttons.lg"), settings().quality)
end

Create(...)
