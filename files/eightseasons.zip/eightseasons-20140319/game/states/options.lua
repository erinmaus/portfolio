local onOff =
{
	[true] = "On",
	[false] = "Off"
}

local function MouseMove(e)
	for _, widget in pairs(self.widgets) do
		widget:Hover(e)
	end
end

local function MouseClick(e)
	for _, widget in pairs(self.widgets) do
		widget:Click(e)
	end
end

function Destroy()
	self.viewer:Destroy()
	
	self.font:Destroy()
	self.fontForeground:Destroy()
	self.fontBackground:Destroy()
	
	self.background:Destroy()
	self.foreground:Destroy()
	
	self.game.queue["MouseAxis"] = self.game.queue["MouseAxis"] - MouseMove
	self.game.queue["MouseButtonDown"] = self.game.queue["MouseButtonDown"] - MouseClick
end

function Done()
	self.game.EnterMenu("game/states/mainMenu.lua")
end

function Update(time)
	self.viewer:Update(time)
	
	for _, widget in pairs(self.widgets) do
		widget:Update(time)
	end
end

function Draw()
	self.viewer:Draw()
	
	for _, widget in pairs(self.widgets) do
		widget:Draw()
	end
	
	local offset
	do
		local fx, fh, fw = self.font:Measure("*")
		
		offset = -fw
	end
	
	self.font:DrawText(self.foreground, 96, 360, "Letterboxing:")
	self.font:DrawText(self.foreground, 96 + offset, 312, "*Fullscreen:")
	self.font:DrawText(self.foreground, 96, 264, "Sound effects:")
	self.font:DrawText(self.foreground, 96, 216, "Music volume:")
	self.font:DrawText(self.foreground, 96 + offset, 168, "*Image quality:")
	
	do
		local s = format("%d", self.settings.musicVolume * 10)
		local fx, fh, fw = self.font:Measure(s)
		
		self.font:DrawText(self.foreground, 512 + (64 - fw) / 2, 216, s)
	end
	
	do
		local s = format("%d", self.settings.quality - 3)
		
		local fx, fh, fw = self.font:Measure(s)
		
		self.font:DrawText(self.foreground, 512 + (64 - fw) / 2, 168, s)
	end
	
	self.font:DrawText(self.foreground, 96 + offset, 32, "*Note: these settings may not take effect until restart.")
	
	self.background:SetAlpha(1 - parent.state.transition.normal)
	self.background:Fill(0, 0, Screen.Width, Screen.Height)
end

local function Create(game)
	self = {}
	self.settings = settings()
	
	self.game = game
	self.game.queue["MouseAxis"] = self.game.queue["MouseAxis"] + MouseMove
	self.game.queue["MouseButtonDown"] = self.game.queue["MouseButtonDown"] + MouseClick
	
	self.scene = Story.Scene.Load("content/scenes/menus/options.scene")
	self.viewer = Story.Scene.Viewer.Create(self.scene)
	self.viewer:ChangeAnimation("Options-In")
	
	self.background = GraphicsUtility.CreatePaint(Color.Create(1, 1, 1))
	self.foreground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0))
	
	self.font = Font.Load("content/fonts/normal.ttf", 32, settings().quality)
	self.fontForeground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 0.5))
	self.fontBackground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 1))
	
	self.widgets = {}
	
	self.widgets.letterBoxing = Widget.Button.Create()
	self.widgets.letterBoxing.x = 480
	self.widgets.letterBoxing.y = 360
	self.widgets.letterBoxing.width = 128
	self.widgets.letterBoxing.height = 32
	self.widgets.letterBoxing.data.text = onOff[self.settings.letterBoxing]
	self.widgets.letterBoxing.data.font = self.font
	self.widgets.letterBoxing.data.foreground = self.fontForeground
	self.widgets.letterBoxing.data.background = self.fontBackground
	self.widgets.letterBoxing:OnClick(function()
		self.settings.letterBoxing = not self.settings.letterBoxing
		
		self.widgets.letterBoxing.data.text = onOff[self.settings.letterBoxing]
	end)
	
	self.widgets.fullscreen = Widget.Button.Create()
	self.widgets.fullscreen.x = 480
	self.widgets.fullscreen.y = 312
	self.widgets.fullscreen.width = 128
	self.widgets.fullscreen.height = 32
	self.widgets.fullscreen.data.text = onOff[self.settings.isFullscreen]
	self.widgets.fullscreen.data.font = self.font
	self.widgets.fullscreen.data.foreground = self.fontForeground
	self.widgets.fullscreen.data.background = self.fontBackground
	self.widgets.fullscreen:OnClick(function()
		self.settings.isFullscreen = not self.settings.isFullscreen
		
		self.widgets.fullscreen.data.text = onOff[self.settings.isFullscreen]
	end)
	
	self.widgets.soundEffects = Widget.Button.Create()
	self.widgets.soundEffects.x = 480
	self.widgets.soundEffects.y = 264
	self.widgets.soundEffects.width = 128
	self.widgets.soundEffects.height = 32
	self.widgets.soundEffects.data.text = onOff[self.settings.soundEffects]
	self.widgets.soundEffects.data.font = self.font
	self.widgets.soundEffects.data.foreground = self.fontForeground
	self.widgets.soundEffects.data.background = self.fontBackground
	self.widgets.soundEffects:OnClick(function()
		self.settings.soundEffects = not self.settings.soundEffects
		
		self.widgets.soundEffects.data.text = onOff[self.settings.soundEffects]
	end)
	
	self.widgets.musicVolumeDown = Widget.Button.Create()
	self.widgets.musicVolumeDown.x = 480
	self.widgets.musicVolumeDown.y = 216
	self.widgets.musicVolumeDown.width = 32
	self.widgets.musicVolumeDown.height = 32
	self.widgets.musicVolumeDown.data.text = "<-"
	self.widgets.musicVolumeDown.data.font = self.font
	self.widgets.musicVolumeDown.data.foreground = self.fontForeground
	self.widgets.musicVolumeDown.data.background = self.fontBackground
	self.widgets.musicVolumeDown:OnClick(function()
		local volume = (Math.Floor(self.settings.musicVolume * 10) - 1) / 10
		
		if volume < 0 then
			volume = 0
		end
		
		self.settings.musicVolume = volume
		settings({ musicVolume = volume })
	end)
	
	self.widgets.musicVolumeUp = Widget.Button.Create()
	self.widgets.musicVolumeUp.x = 576
	self.widgets.musicVolumeUp.y = 216
	self.widgets.musicVolumeUp.width = 32
	self.widgets.musicVolumeUp.height = 32
	self.widgets.musicVolumeUp.data.text = "->"
	self.widgets.musicVolumeUp.data.font = self.font
	self.widgets.musicVolumeUp.data.foreground = self.fontForeground
	self.widgets.musicVolumeUp.data.background = self.fontBackground
	self.widgets.musicVolumeUp:OnClick(function()
		local volume = (Math.Floor(self.settings.musicVolume * 10) + 1) / 10
		
		if volume > 1 then
			volume = 1
		end
		
		self.settings.musicVolume = volume
		settings({ musicVolume = volume })
	end)
	
	self.widgets.qualityDown = Widget.Button.Create()
	self.widgets.qualityDown.x = 480
	self.widgets.qualityDown.y = 168
	self.widgets.qualityDown.width = 32
	self.widgets.qualityDown.height = 32
	self.widgets.qualityDown.data.text = "<-"
	self.widgets.qualityDown.data.font = self.font
	self.widgets.qualityDown.data.foreground = self.fontForeground
	self.widgets.qualityDown.data.background = self.fontBackground
	self.widgets.qualityDown:OnClick(function()
		if not self.settings.useShader then
			local quality = Math.Max(self.settings.quality - 1, 4)
		
			self.settings.quality = quality
		end
	end)
	
	self.widgets.qualityUp = Widget.Button.Create()
	self.widgets.qualityUp.x = 576
	self.widgets.qualityUp.y = 168
	self.widgets.qualityUp.width = 32
	self.widgets.qualityUp.height = 32
	self.widgets.qualityUp.data.text = "->"
	self.widgets.qualityUp.data.font = self.font
	self.widgets.qualityUp.data.foreground = self.fontForeground
	self.widgets.qualityUp.data.background = self.fontBackground
	self.widgets.qualityUp:OnClick(function()
		if not self.settings.useShader then
			local quality = Math.Min(self.settings.quality + 1, 8)
			
			self.settings.quality = quality
		end
	end)
	
	self.widgets.returnButton = Widget.Button.Create()
	self.widgets.returnButton.x = 96
	self.widgets.returnButton.y = 72
	self.widgets.returnButton.width = 128
	self.widgets.returnButton.height = 32
	self.widgets.returnButton.data.text = "Return"
	self.widgets.returnButton.data.font = self.font
	self.widgets.returnButton.data.foreground = self.fontForeground
	self.widgets.returnButton.data.background = self.fontBackground
	self.widgets.returnButton:OnClick(function()
		if self.settings.useShader then
			self.settings.quality = -1
		end
		
		settings(self.settings)
		
		parent:Exit()
	end)
	
	parent.state.transition = Transition.Create(0.5, 0.5, Transition.Type.In)
end

Create(...)
