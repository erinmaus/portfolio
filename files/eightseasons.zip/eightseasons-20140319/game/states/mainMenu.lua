local function Option(option)
	return function()
		self.option = option
		parent:Exit()
	end
end

local function MouseMove(e)
	for _, widget in pairs(self.widgets) do
		widget:Hover(e)
	end
end

local function MouseClick(e)
	for _, widget in pairs(self.widgets) do
		widget:Click(e)
	end
end

function Destroy()
	self.viewer:Destroy()
	
	self.font:Destroy()
	self.fontForeground:Destroy()
	self.fontBackground:Destroy()
	
	self.background:Destroy()
	
	self.game.queue["MouseAxis"] = self.game.queue["MouseAxis"] - MouseMove
	self.game.queue["MouseButtonDown"] = self.game.queue["MouseButtonDown"] - MouseClick
end

function Done()
	if self.option == "new" then
		self.game.NewGame()
		self.game.ExitMenu()
	elseif self.option == "continue" then
		self.game.Continue()
		self.game.ExitMenu()
	elseif self.option == "credits" then
		-- TODO: Show credits
		-- Exit game for now.
		self.game.Exit()
		self.game.ExitMenu()
	elseif self.option == "configure" then
		self.game.EnterMenu("game/states/options.lua")
	elseif self.option == "quit" then
		self.game.Exit()
	else
		error("unexpected option: " .. tostring(self.option))
	end
end

function Update(time)
	self.viewer:Update(time)
	
	for _, widget in pairs(self.widgets) do
		widget:Update(time)
	end
end

function Draw()	
	self.viewer:Draw()
	
	for _, widget in pairs(self.widgets) do
		widget:Draw()
	end
	
	self.background:SetAlpha(1 - parent.state.transition.normal)
	self.background:Fill(0, 0, Screen.Width, Screen.Height)
end

function Create(game)
	self = {}
	
	self.game = game
	self.game.queue["MouseAxis"] = self.game.queue["MouseAxis"] + MouseMove
	self.game.queue["MouseButtonDown"] = self.game.queue["MouseButtonDown"] + MouseClick

	self.game.audio:PlaySong("content/title.ogg", true)
	
	self.scene = Story.Scene.Load("content/scenes/menus/main.scene")
	self.viewer = Story.Scene.Viewer.Create(self.scene)
	self.viewer:ChangeAnimation("Main-In")
	
	self.background = GraphicsUtility.CreatePaint(Color.Create(1, 1, 1))
	
	self.font = Font.Load("content/fonts/normal.ttf", 32, settings().quality)
	self.fontForeground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 0.5))
	self.fontBackground = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 1))
	
	self.widgets = {}
	
	self.widgets.newStory = Widget.Button.Create()
	self.widgets.newStory.x = 96
	self.widgets.newStory.y = 360
	self.widgets.newStory.width = 128
	self.widgets.newStory.height = 32
	self.widgets.newStory.data.text = "New story"
	self.widgets.newStory.data.font = self.font
	self.widgets.newStory.data.foreground = self.fontForeground
	self.widgets.newStory.data.background = self.fontBackground
	self.widgets.newStory:OnClick(Option("new"))
	
	self.widgets.continueStory = Widget.Button.Create()
	self.widgets.continueStory.x = 96
	self.widgets.continueStory.y = 312
	self.widgets.continueStory.width = 128
	self.widgets.continueStory.height = 32
	self.widgets.continueStory.data.text = "Continue story"
	self.widgets.continueStory.data.font = self.font
	self.widgets.continueStory.data.foreground = self.fontForeground
	self.widgets.continueStory.data.background = self.fontBackground
	self.widgets.continueStory:OnClick(function()
		if game.CanContinue() then
			self.option = "continue"
			parent:Exit()
		else
			self.viewer:ChangeAnimation("Main-StoryNotLoaded", false)
		end
	end)
	
	self.widgets.viewCredits = Widget.Button.Create()
	self.widgets.viewCredits.x = 96
	self.widgets.viewCredits.y = 264
	self.widgets.viewCredits.width = 128
	self.widgets.viewCredits.height = 32
	self.widgets.viewCredits.data.text = "View credits"
	self.widgets.viewCredits.data.font = self.font
	self.widgets.viewCredits.data.foreground = self.fontForeground
	self.widgets.viewCredits.data.background = self.fontBackground
	self.widgets.viewCredits:OnClick(Option("credits"))
	
	self.widgets.configureOptions = Widget.Button.Create()
	self.widgets.configureOptions.x = 96
	self.widgets.configureOptions.y = 216
	self.widgets.configureOptions.width = 128
	self.widgets.configureOptions.height = 32
	self.widgets.configureOptions.data.text = "Configure options"
	self.widgets.configureOptions.data.font = self.font
	self.widgets.configureOptions.data.foreground = self.fontForeground
	self.widgets.configureOptions.data.background = self.fontBackground
	self.widgets.configureOptions:OnClick(Option("configure"))
	
	self.widgets.quitStory = Widget.Button.Create()
	self.widgets.quitStory.x = 96
	self.widgets.quitStory.y = 168
	self.widgets.quitStory.width = 128
	self.widgets.quitStory.height = 32
	self.widgets.quitStory.data.text = "Quit story"
	self.widgets.quitStory.data.font = self.font
	self.widgets.quitStory.data.foreground = self.fontForeground
	self.widgets.quitStory.data.background = self.fontBackground
	self.widgets.quitStory:OnClick(Option("quit"))
	
	parent.state.transition = Transition.Create(0.5, 0.5, Transition.Type.In)
end

Create(...)
