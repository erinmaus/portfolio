function Destroy()
	self.viewer:Destroy()
end

function Done()
	self.game.EnterMenu("game/states/mainMenu.lua")
end

function Update(time)
	self.viewer:Update(time)
	
	if parent.state.transition.type == Transition.Type.None and not parent.state.isExiting then
		parent:Exit()
	end
end

function Draw()
	self.viewer:Draw()
end

function Create(game)
	self = {}
	
	self.game = game
	
	self.scene = Story.Scene.Load("content/scenes/title/title.scene")
	self.viewer = Story.Scene.Viewer.Create(self.scene)
	self.viewer:ChangeAnimation("Play")
	self.viewer:Update(0)
	
	game.audio:PlaySong("content/jingle.ogg", false, true)
	
	parent.state.transition = Transition.Create(2, 0.5, Transition.Type.In)
end

Create(...)
