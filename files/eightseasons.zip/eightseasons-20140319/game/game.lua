local states
local queue
local audio
local stage
local isRunning = true
local frame = {}
local gameState = {}
local private = {}
local demo = false

function gameState.DropEvents()
	private.loadData.updateThreshold = Main.CurrentTime()
end

function gameState.PlayScene(path, showStage, callback)
	private.isShowingScene = true
	private.isUpdatingScene = true
	
	if not showStage then
		private.isShowingStage = false
	end
	
	-- Stages shouldn't update during a cutscene.
	-- Could ruin it!
	private.isUpdatingStage = false
	
	private.scene = Story.Scene.Load(path)
	private.sceneView = Story.Scene.Viewer.Create(private.scene)
	private.sceneView:ChangeAnimation("Play")
	private.sceneView:Update(0)
	private.sceneCallback = callback
	
	gameState.DropEvents()
end

function gameState.PauseGameplay()
	private.isPaused = true
end

function gameState.ResumeGameplay()
	private.isPaused = false
end

function gameState.EnableStage()
	private.isShowingStage = true
	private.isUpdatingStage = true
end

function gameState.DisableStage()
	private.isShowingStage = false
	private.isUpdatingStage = false
end

function gameState.IsStageVisible()
	return private.isShowingStage
end

function gameState.EnableScene()
	private.isShowingScene = true
	private.isUpdatingScene = true
end

function gameState.DisableScene()
	private.isShowingScene = false
	private.isUpdatingScene = false
end

function gameState.ShowHud()
	if not private.isShowingHud then
		private.hud.transition:Switch(Transition.Type.In)
	end

	private.isShowingHud = true
end

function gameState.HideHud()
	if private.isShowingHud then
		private.hud.transition:Switch(Transition.Type.Out)
	end

	private.isShowingHud = false
end

function gameState.IsHudVisible()
	return private.isShowingHud
end

function gameState.FinishScene()
	private.sceneView:Destroy()
	
	private.scene = nil
	private.sceneView = nil
	
	private.sceneCallback = nil
	
	gameState.DisableScene()
end

function gameState.EnterMenu(path, ...)
	states:Add(State.Load(path, gameState, ...))
	private.isInMenu = true
	gameState.DropEvents()
end

function gameState.ExitMenu()
	private.isInMenu = false
end

function gameState.LoadStage(path, entrance)
	Main.StartLoading()
	private.isLoading = true
	private.loadData.thread = Coroutine.Create(Stage.Load)
	
	local success, value = Coroutine.Resume(private.loadData.thread, path, gameState, entrance, true)
	
	if not success then
		error(value)
	end
	
	private.loadData.sceneView:ChangeAnimation("Loading")
	
	gameState.DisableStage()
end

function gameState.ExitStage()
	gameState.DisableStage()
	
	if stage then
		stage:Destroy()
		
		stage = nil
	end
end

local function EnterOverlay(overlay)
	if private.activeOverlay ~= "none" then
		error("cannot enter another overlay (in " .. tostring(private.activeOverlay) .. ")")
	end
	
	private.activeOverlay = overlay
	
	gameState.PauseGameplay()
end

function gameState.ExitOverlay()
	private.activeOverlay = "none"
	
	gameState.ResumeGameplay()
end

function gameState.Battle(enemy, callback, preCallback)
	private.overlays.battle.Battle(enemy, callback, preCallback)

	EnterOverlay("battle")

	private.overlays.battle.Update(0)
end

function gameState.Converse(path, callback)
	local success, err = call(private.overlays.dialogue.StartConversation, path, callback)
	
	if not success then
		error(err)
	end
	
	EnterOverlay("dialogue")
	private.overlays.dialogue.Update(0)
end

function gameState.Pause()
	private.overlays.pause.Pause()
	
	EnterOverlay("pause")
	private.overlays.pause.Update(0)
end

function gameState.ShowDemo(demo, arg, callback)
	private.overlays.demo.Enter(demo, arg, callback)

	EnterOverlay("demo")
	private.overlays.demo.Update(0)
end

function gameState.ShowInventory()
	if #gameState.state.player.inventory == 0 then
		gameState.Converse("content/conversations/misc/noItems.lua")
	else
		private.overlays.inventory.ShowInventory()

		EnterOverlay("inventory")
		private.overlays.inventory.Update(0)
	end
end

function gameState.GiveInventoryItem(item)
	Table.Insert(gameState.state.player.inventory, item)
	
	private.overlays.inventory.ShowInventory(#gameState.state.player.inventory, true)
	
	EnterOverlay("inventory")
	private.overlays.inventory.Update(0)
end

function gameState.HasInventoryItem(item)
	for i = 1, #gameState.state.player.inventory do
		if gameState.state.player.inventory[i] == item then
			return true, i
		end
	end
	
	return false
end

function gameState.RemoveInventoryItem(item)
	local hasItem, index = gameState.HasInventoryItem(item)
	
	if hasItem then
		Table.Remove(gameState.state.player.inventory, index)
	end
end

function gameState.Playlist(location, callback)
	local success, playlist = load({}, location or "content/scenes/intro/playlist.lua")
	local currentIndex = 0
	
	if not success then
		error(playlist)
	end
	
	local continue
	
	continue = function()
		currentIndex = currentIndex + 1
		
		if currentIndex <= #playlist then
			local p = playlist[currentIndex]
			
			if p[1] == "scene" then
				gameState.PlayScene(p[2], false, continue)
			elseif p[1] == "dialogue" then
				gameState.Converse(p[2], continue)
			elseif p[1] == "demo" then
				gameState.ShowDemo(p[2], p[3], continue)
			else
				error("unknown playlist type: " .. p[1])
			end
			
			gameState.DropEvents()
		else
			callback()
		end
	end
	
	continue()
end

function gameState.NewGame()
	gameState.state = {}
	
	-- Reserved for stage-local data.
	gameState.state.stage = {}
	
	-- Quest is for progress in the main storyline, as well as any sub plots
	-- Basically, this is global stuff.
	gameState.state.quest = {}
	gameState.state.quest.main = {}
	
	-- Player stuff (last location, etc)
	-- Used for resuming the game.
	gameState.state.player = {}
	gameState.state.player.lastStage = "content/stages/loft/entrance/left/stage.lst"
	gameState.state.player.lastEntrance = "left"
	
	-- Inventory.
	gameState.state.player.inventory = {}

	-- Battle stuff.
	gameState.state.player.scrolls =
	{
		-- Give first four scrolls.
		true, true, true, true
	}

	gameState.state.player.baseStats =
	{
		health = 8000,
		accuracy = 400,
		evasion = 400,
		attack = 800,
		defense = 400,
		speed = 800
	}

	gameState.state.player.currentStats =
	{
		health = 8000,
		accuracy = 400,
		evasion = 400,
		attack = 800,
		defense = 400,
		speed = 800
	}

	gameState.state.player.energies =
	{
		false,
		false,
		false,
		true,
		false,
		false,
		true,
		false
	}

	gameState.Playlist(nil, function()
		gameState.Continue()
	end)

	gameState.audio:PlaySong("content/introduction.ogg", true)
end

function gameState.Exit()
	isRunning = false
end

function gameState.ReturnToTitle()
	if private.scene then
		gameState.FinishScene()
	end
	
	gameState.ExitStage()
	gameState.EnterMenu("game/states/mainMenu.lua")
end

local function LoadSaveData()
	local state = {}
	local success, ret = load(state, "save.lua")
	
	if success then
		gameState.state = state.save
	end
end

function gameState.CanContinue()
	LoadSaveData()
	
	return gameState.state ~= nil and gameState.state.player.lastStage
end

function gameState.Record()
	File.WriteAllData("save.lua", serialize("save", gameState.state))
end

function gameState.Continue()
	gameState.PlayScene("content/scenes/common/page.scene", false, function()
		gameState.LoadStage(gameState.state.player.lastStage, gameState.state.player.lastEntrance)
	end)
end

function gameState.MovePaper(x, y)
	frame.offsetX = frame.offsetX + x
	frame.offsetY = frame.offsetY + y
end

Game = {}

local function LoadOverlay(path)
	local g = sandbox()
	local success, err = load(g, path, gameState)
	
	if not success then
		error(err)
	end
	
	return g
end

local function BuildBounds(font, string, y)
	local rect = {}
	local x, h, w = font:Measure(string)

	rect.x = x
	rect.y = y
	rect.width = w
	rect.height = h

	return rect
end

local function HudOffset()
	return private.hud.verticalOffset * Math.SmoothStep(0, 1, 1 - private.hud.transition.normal)
end

local function HudActive(button, offset, x, y)
	local v = HudOffset()
	
	return MathUtil.Primitives.PointInRectangle(button.rectangle.x + offset, button.rectangle.y + v, button.rectangle.width, button.rectangle.height, x, y)
end

local function HudClick(x, y)
	local offset = private.hud.spacing

	for i = 1, #private.hud.buttons do
		local button = private.hud.buttons[i]

		if HudActive(button, offset, x, y) then
			button.callback()

			break
		end

		offset = offset + button.rectangle.width + private.hud.spacing
	end
end

local function InitializeHud()
	private.hud.baseLine = 500
	private.hud.baseLinePadding = 16
	private.hud.spacing = 32
	private.hud.verticalOffset = 80
	private.hud.transition = Transition.Create(0.25, 0.5)
	private.hud.transition:Switch(Transition.Type.None)

	private.hud.Click = HudClick

	private.hud.resources = {}
	private.hud.resources.font = Font.Load("content/fonts/normal.ttf", 32, settings().quality)
	private.hud.resources.background = LG.Compile(LG.Load("content/misc/hud.lg"), settings().quality)
	private.hud.resources.active = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 1))
	private.hud.resources.inactive = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 0.5))

	private.hud.buttons = {}

	-- Pause button
	private.hud.buttons[1] = {}
	private.hud.buttons[1].rectangle = BuildBounds(private.hud.resources.font, "[pause]", private.hud.baseLine + private.hud.baseLinePadding)
	private.hud.buttons[1].text = "[pause]"
	private.hud.buttons[1].callback = function()
		gameState.Pause()
	end

	-- Inventory
	private.hud.buttons[2] = {}
	private.hud.buttons[2].rectangle = BuildBounds(private.hud.resources.font, "[inventory]", private.hud.baseLine + private.hud.baseLinePadding)
	private.hud.buttons[2].text = "[inventory]"
	private.hud.buttons[2].callback = function()
		gameState.ShowInventory()
	end
end

local function InitializePrivateData()
	-- For menus and generally paired with isPaused
	private.isInMenu = false
	
	-- Overrides the individual isUpdating toggles.
	private.isPaused = false
	
	private.isShowingScene = false
	private.isShowingStage = false
	private.isUpdatingScene = false
	private.isUpdatingStage = false
	private.isShowingHud = false
	private.enableStage = false
	
	-- Loading screen.
	private.isLoading = true
	Main.StartLoading()
	
	private.loadData = {}
	private.loadData.updateThreshold = 0
	private.loadData.scene = Story.Scene.Load("content/scenes/load/scene.lua")
	private.loadData.sceneView = Story.Scene.Viewer.Create(private.loadData.scene)
	
	private.hud = {}
	private.overlays = {}
	private.activeOverlay = "none"
	
	private.loadData.thread = Coroutine.Create(function()
		private.overlays.dialogue = LoadOverlay("game/overlays/dialogue.lua")
		private.overlays.pause = LoadOverlay("game/overlays/pause.lua")
		private.overlays.inventory = LoadOverlay("game/overlays/inventory.lua")
		private.overlays.battle = LoadOverlay("game/overlays/battle.lua")
		private.overlays.demo = LoadOverlay("game/overlays/demo.lua")

		InitializeHud()
	
		if demo then
			gameState.Playlist("content/misc/demo.lua", function()
				gameState.Continue()
			end)
		else
			gameState.EnterMenu("game/states/logoSplash.lua")
		end
	end)
	
	private.loadData.sceneView:ChangeAnimation("Loading")
end

local function LoadFrameImage(path, color)
	local image = Paint.Create(PaintMode.TexturedTinted)
	image:AddColor(color or Color.Create(1, 1, 1, 1))
	image:Finish()
	
	image:SetTexture(path)
	
	return image
end

local function LoadFrame()
	frame.image = LoadFrameImage("content/misc/frames/standard.png")
	frame.delta = 0
	
	frame.paper = {}
	frame.paper.topLeft = LoadFrameImage("content/misc/frames/paper1.jpg")
	frame.paper.bottomLeft = LoadFrameImage("content/misc/frames/paper2.jpg")
	frame.paper.topRight = LoadFrameImage("content/misc/frames/paper3.jpg")
	frame.paper.bottomRight = LoadFrameImage("content/misc/frames/paper4.jpg")
	
	frame.offsetX = 0
	frame.offsetY = 0
	frame.width = 1024
	frame.height = 1024
end

local function UpdateAudio(delta)
	audio.core.musicMixer.gain = settings().musicVolume
	
	if settings().soundEffects then
		audio.core.soundEffectMixer.gain = 1
	else
		audio.core.soundEffectMixer.gain = 0
	end
	
	audio:Update(delta)
end

function Game.Load()
	queue = EventQueue.Create()
	queue:AddEventHandlers(
		"JoystickAxis", "JoystickButtonDown", "JoystickButtonUp",
		"MouseAxis", "MouseButtonDown", "MouseButtonUp",
		"KeyDown", "KeyUp", "KeyPress",
		"SwitchIn", "SwitchOut")
		
	audio = AudioManager.Create()
	states = State.Manager.Create(queue)
	
	gameState.audio = audio
	UpdateAudio(1)
	
	gameState.states = states
	gameState.queue = queue
	gameState.input = EventQueue.Input.Create(queue)
	LoadSaveData()
	
	InitializePrivateData()
	LoadFrame()
end

function Game.Update(fps, t)
	if t < private.loadData.updateThreshold then
		return { isRunning, false }
	end

	if private.enableStage then
		gameState.EnableStage()
		
		private.enableStage = false
	end
	
	if not private.isInMenu then
		if private.activeOverlay ~= "none" then
			private.overlays[private.activeOverlay].Update(fps)
		end
	end
	
	states:Update(fps)
	
	if not private.isPaused then
		if private.isUpdatingStage then
			stage:Update(fps)
		end
		
		if private.isUpdatingScene then
			private.sceneView:Update(fps)
			
			if private.sceneView:IsAnimationFinished() then
				local callback = private.sceneCallback
				
				gameState.FinishScene()
				
				if callback then
					callback()
				end
			end
		end
	end

	-- Show/hide HUD
	if not private.isPaused and private.isUpdatingStage and gameState.input.current.mouse.axes.y >= private.hud.baseLine then
		gameState.ShowHud()
	else
		gameState.HideHud()
	end
	
	if private.isLoading then
		private.loadData.sceneView:Update(fps)
		
		if Coroutine.Status(private.loadData.thread) ~= "dead" then
			local time = Main.CurrentTime()
			local elapsed = 0
			
			while elapsed < 1 / Main.loadingFps * 0.5 do
				local success, value = Coroutine.Resume(private.loadData.thread)
				
				if not success then
					error(value)
				end
				
				elapsed = elapsed + (Main.CurrentTime() - time)
				
				if Coroutine.Status(private.loadData.thread) == "dead" then
					private.loadData.sceneView:ChangeAnimation("Done", false)
					
					if stage ~= nil then
						stage:Destroy()
					end
					
					stage = value
					
					break
				elseif private.loadData.sceneView:IsAnimationFinished() then
					private.loadData.sceneView:ChangeAnimation("Loading", false)
				end
			end
		else
			if private.loadData.sceneView:IsAnimationFinished() then
				private.isLoading = false
				Main.StopLoading()
				gameState.DropEvents()
				
				if stage ~= nil then
					private.enableStage = true
				end
			end
		end
	else
		private.hud.transition:Update(fps)
	end
	
	UpdateAudio(fps)
	
	gameState.input:Update()
	
	return { isRunning, false }
end

local function DrawPaperImage(x, y, paper)
	paper.topLeft:Fill(x, y, frame.width, frame.height)
	paper.bottomLeft:Fill(x, y - frame.height, frame.width, frame.height)
	paper.topRight:Fill(x - frame.width, y, frame.width, frame.height)
	paper.bottomRight:Fill(x - frame.width, y - frame.height, frame.width, frame.height)
end

local function DrawPaper(paper)
	local x = (frame.offsetX / 10) % frame.width
	local y = (frame.offsetY / 10) % frame.height
	local w = frame.width / 2
	local h = frame.height / 2
	
	DrawPaperImage(x, y, paper)
end

function Game.Draw()
	Graphics.Start2D()
	
	if private.isShowingStage then
		stage:Draw(Matrix.Identity())
	end
	
	if private.isShowingScene then
		private.sceneView:Draw()
	end
	
	if private.isInMenu then
		states:Draw()
	else
		if private.activeOverlay ~= "none" then
			private.overlays[private.activeOverlay].Draw()
		end
	end
	
	if private.isLoading and not demo then
		private.loadData.sceneView:Draw()
	end

	-- HUD
	if not private.isLoading and not private.hud.transition.isDone or private.isShowingHud then
		local offset = private.hud.spacing
		local currentMousePosition = gameState.input.current.mouse.axes
		local v = HudOffset()

		LG.Draw(private.hud.resources.background, "background", 1, 0, v)

		for i = 1, #private.hud.buttons do
			local button = private.hud.buttons[i]
			local paint

			if HudActive(button, offset, currentMousePosition.x, currentMousePosition.y) then
				paint = private.hud.resources.active
			else
				paint = private.hud.resources.inactive
			end

			private.hud.resources.font:DrawText(paint, offset, private.hud.baseLine + private.hud.baseLinePadding + v, button.text)

			offset = offset + button.rectangle.width + private.hud.spacing
		end
	end
	
	Graphics.PushBlenderMode()
	
	-- Draw the paper texture.
	Graphics.SetBlenderMode(BlenderMode.InverseMultiply)
	DrawPaper(frame.paper)
	
	Graphics.SetBlenderMode(BlenderMode.Multiply)
	DrawPaper(frame.paper)
	
	-- Draw the noir border.
	
	Graphics.SetBlenderMode(BlenderMode.Alpha)
	frame.image:SetAlpha(Math.Abs(Math.Sin(frame.delta) * 0.05 + 0.1))
	frame.image:Fill(0, 0, Screen.Width, Screen.Height)
	
	Graphics.PopBlenderMode()
	
	Graphics.Stop2D()
end

function Game.Close()
	isRunning = false
end

function Game.Destroy()
	audio:Destroy()
	states:Destroy()
	
	if story.view then
		story.view:Destroy()
	end
end

Game.Joystick = {}

function Game.Joystick.Axis(e)
	queue.JoystickAxis(e)
end

function Game.Joystick.ButtonDown(e)
	queue.JoystickButtonDown(e)
end

function Game.Joystick.ButtonUp(e)
	queue.JoystickButtonUp(e)
end

Game.Mouse = {}

function Game.Mouse.Axis(e)
	queue.MouseAxis(e)
	
	if private.activeOverlay ~= "none" and not private.isInMenu then
		private.overlays[private.activeOverlay].Hover(e.x, e.y)
	end
end

function Game.Mouse.ButtonDown(e)
	queue.MouseButtonDown(e)
	
	if private.activeOverlay ~= "none" and not private.isInMenu then
		private.overlays[private.activeOverlay].Click(e.x, e.y)
	elseif private.activeOverlay == "none" and not private.isPaused and private.isShowingHud then
		private.hud.Click(e.x, e.y)
	end
end

function Game.Mouse.ButtonUp(e)
	queue.MouseButtonUp(e)
end

Game.Keyboard = {}

function Game.Keyboard.KeyDown(e)
	queue.KeyDown(e)
	
	if e.keycode == Keycode.Escape then
		if stage or private.sceneView then
			if private.activeOverlay == "none" and not private.isLoading then
				gameState.Pause()
			end
		elseif private.isInMenu or demo then
			gameState.Exit()
		end
	end
end

function Game.Keyboard.KeyUp(e)
	queue.KeyUp(e)
end

function Game.Keyboard.KeyPress(e)
	queue.KeyPress(e)
end

Game.Display = {}

function Game.Display.In(e)
end

function Game.Display.Out(e)
end
