State.Manager = {}

local function IsClean(self)
	for i = 1, #self.states do
		if self.states[i].state.hasExited then
			return false, i
		end
	end
	
	return true, nil
end

local function Update(self, fps)
	local index = #self.states
	local isCovered = false
	
	while index > 0 do
		self.states[index]:Update(fps, isCovered)
		
		if not self.states[index].isExiting then
			isCovered = true
		end
		
		index = index - 1
	end
	
	-- Clear exited states
	local isClean, dirty = IsClean(self)
	
	while not isClean do
		if self.states[dirty].child and self.states[dirty].child.Destroy then
			self.states[dirty].child:Destroy()
		end
		
		Table.Remove(self.states, dirty)
		
		isClean, dirty = IsClean(self)
	end
end

local function Draw(self)
	for i = 1, #self.states do
		self.states[i]:Draw()
	end
end

local function Add(self, state)
	Table.Insert(self.states, state)
	state.manager = self
end

local function Destroy(self)
	for i = 1, #self.states do
		if self.states[i].child and self.states[i].child.Destroy then
			self.states[i].child:Destroy()
		end
	end
end

function State.Manager.Create(queue)
	local s =
	{
		states = {},
		queue = queue
	}
	
	s.Update = Update
	s.Draw = Draw
	s.Add = Add
	s.Destroy = Destroy
	
	return s
end

readonly(State.Manager)
