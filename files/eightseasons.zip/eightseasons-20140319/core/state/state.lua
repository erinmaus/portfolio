State = {}

State.Mode =
{
	Active = 1,
	Hidden = 2,
	Transitioning = 3
}

readonly(State.Mode)

local function UpdateActivity(self)
	self.state.isActive = self.state.hasFocus and 
		(self.state.mode == State.Mode.Active or 
		(self.state.mode == State.Mode.Transitioning and 
		self.state.transition.type == Transition.Type.In))
end

function State:TransitionTo(type)
	if type == Transition.Type.None then
		self.state.mode = State.Mode.Active
	else
		self.state.mode = State.Mode.Transitioning
	
		self.state.transition:Switch(type)
	end
end

function State:Update(fps, isCovered)
	self.state.hasFocus = not isCovered
	
	if self.state.transition:Update(fps) then
		self:TransitionTo(Transition.Type.None)
	end
	
	UpdateActivity(self)
	
	if self.state.isExiting then
		if self.state.transition.isDone then
			self.state.hasExited = true
			
			if self.child and self.child.Done then
				self.child.Done()
			end
		end
	elseif self.state.transition.type == Transition.Type.In then
		if self.state.isActive then
			if self.state.transition.isDone then
				self:TransitionTo(Transition.Type.None)
			end
		else
			self:TransitionTo(Transition.Type.Out)
		end
	elseif self.state.transition.type == Transition.Type.Out then
		if self.state.hasFocus then
			self:TransitionTo(Transition.Type.In)
		else
			self.state.mode = State.Mode.Hidden
		end
	else
		if not self.state.isActive then
			self:TransitionTo(Transition.Type.Out)
		end
	end
	
	if self.child then
		self.child.Update(fps, isCovered)
	end
end

function State:Draw()
	self.child.Draw()
end

function State:Exit()
	if not self.state.isExiting then
		self.state.isExiting = true
		
		self:TransitionTo(Transition.Type.Out)
	end
end

function State.Create(child)
	local s =
	{
		data = {},
		
		state =
		{
			transition = Transition.Create(0, 0, Transition.Type.In),
			mode = State.Mode.Transitioning,
			
			isActive = false,
			isExiting = false,
			isHidden = false,
			hasExited = false,
			hasFocus = false
		},
		
		child = child
	}
	
	s.TransitionTo = State.TransitionTo
	s.Update = State.Update
	s.Draw = State.Draw
	s.Exit = State.Exit
	
	return s
end

function State.Load(filename, ...)
	local g = sandbox()
	g.parent = State.Create(g)
	
	local s, r = load(g, filename, ...)
	
	if not s then
		error(r)
	end
	
	return g.parent
end

require(_G, "core/state/manager.lua")

readonly(State)
