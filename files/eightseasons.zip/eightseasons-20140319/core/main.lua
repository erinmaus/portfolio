require "debug"
local jit = require("jit")

_B = {} -- '_B' stands for Brightside globals.
local _M = {} -- '_M' is a metatable that makes something read only.

_M.__newindex = function()
	error("table is read-only")
end

local function readonly(t)
	setmetatable(t, _M)
end

local screen =
{
	width = 960,
	height = 540
}

-- Clones a table and optionally executes function `f' on every new table
local function clone(table, f, exceptions)
	local e = exceptions or {}
	local new = {}
	
	for key, value in pairs(table) do
		if type(table[key]) ~= "table" then
			new[key] = value
		elseif not e[value] then
			e[value] = true
			
			new[key] = clone(value, f, e)
		end
	end
	
	if f then
		f(new, table)
	end
	
	return new
end

function _B.load(t, filename, ...)
	local success, ret = pcall(File.ReadAllData, filename)
	
	if not success then
		return false, ret
	end
	
	local chunk, message = loadin(t, ret, filename)
	
	if message then
		return false, message
	end
	
	success, ret = pcall(chunk, ...)
	
	return success, ret
end

function _B.require(t, filename, ...)
	local success, ret = _B.load(t, filename, ...)
	
	if not success then
		_B.error(ret)
	end
	
	return ret
end

_B.error = error
_B.pairs = pairs
_B.call = pcall
_B.equal = rawequal
_B.rawlog = print
_B.select = select
_B.tonumber = tonumber
_B.tostring = tostring
_B.rawtype = type
_B.ecall = xpcall
_B.readonly = readonly
_B.format = string.format
_B.split = function(s, delimiter)
	local l = {}
	local p = 1
	local empty = ""
	
	if empty:find(delimiter, 1) then
		return s
	end
	
	while true do
		local first, last = s:find(delimiter, p)
		
		if first then
			table.insert(l, s:sub(p, first - 1))
			
			p = last + 1
		else
			table.insert(l, s:sub(p))
			
			break
		end
	end
	
	return unpack(l)
end
_B.tochar = string.char
_B.isvalidchar = function(c)
	return c >= 32 and c <= 126
end
_B.luatype = type
_B.deepclone = clone

-- Bit library
--[[_B.band = bit.band
_B.bnot = bit.bnot
_B.bor = bit.bor
_B.bxor = bit.bxor
_B.blshift = bit.blshift
_B.brshift = bit.brshift
_B.brol = bit.rol
_B.bror = bit.ror]]

_B.Coroutine =
{
	Create = coroutine.create,
	Resume = coroutine.resume,
	Current = coroutine.running,
	Status = coroutine.status,
	Wrap = coroutine.wrap,
	Yield = coroutine.yield
}

_B.Math =
{
	Abs = math.abs,
	Acos = math.acos,
	Asin = math.asin,
	Atan = math.atan,
	Atan2 = math.atan2,
	Ceil = math.ceil,
	Cos = math.cos,
	Cosh = math.cosh,
	Floor = math.floor,
	HugeValue = math.huge,
	Infinity = math.infinity,
	Log = math.log,
	Max = math.max,
	Min = math.min,
	Mod = math.fmod,
	Pi = math.pi,
	Sin = math.sin,
	Sinh = math.sinh,
	Sqrt = math.sqrt,
	Tan = math.tan,
	Tanh = math.tanh,
	ToDeg = math.deg,
	ToRad = math.rad,
	Clamp = function(val, min, max)
		if val < min then
			return min
		elseif val > max then
			return max
		else
			return val
		end
	end,
	Interpolate = function(a, b, t)
		return a + (b - a) * t
	end,
	SmoothStep = function(a, b, t)
		local x = _B.Math.Clamp((t - a) / (b - a), 0, 1)
		
		--return x * x * x * (x * (x * 6 - 16) + 10)
		return x * x * (3 - 2 * x)
	end,
	Pow = function(a, b)
		return a^b
	end
}

function pack(...)
	return { n = select("#", ...), ... }
end

_B.Table =
{
	Concat = table.concat,
	Insert = table.insert,
	Pack = pack,
	Remove = table.remove,
	Sort = table.sort,
	Unpack = unpack,
	SetMetatable = setmetatable,
	GetMetatable = getmetatable
}

_B.Screen =
{
	Width = screen.width,
	Height = screen.height
}

_B.settings = function(s)
	if s then
		conf.isFullscreen = s.isFullscreen or false
		conf.letterBoxing = s.letterBoxing or false
		conf.soundEffects = s.soundEffects or false
		conf.musicVolume = s.musicVolume or 1
		conf.quality = s.quality or 4
		
		local c = _B.serialize("conf", conf)
		
		File.WriteAllData("conf.lua", c)
	else
		return clone(conf)
	end
end

_B.language = function()
	return "en"
end

-- Finally, insert Brightside stuff!
for key, value in pairs(_G) do
	if type(value) == "table" and value.__brightside then
		_B[key] = value
	end
end

local printd = function() end
do
	local success, ret = _B.load(_B, "core/print.lua") -- Draw printed stuff!
	
	if not success then
		error(ret)
	end
	
	printd = ret
end

do
	local success, ret = _B.load(_G, "core/serializer.lua")
	
	if not success then
		error(ret)
	end
	
	_B.serialize = serialize
end

Brightside =
{
	Joystick = {},
	Keyboard = {},
	Mouse = {},
	Display = {}
}

local game = clone(_B, readonly)
setmetatable(game, {}) -- Get rid of the last readonly callback
game._G = game
do
	local filename = "game/game.lua"
	
	if not File.Exists(filename) then
		filename = "core/dgame.lua"
	end
	
	local success, err = _B.load(game, filename)
	
	if not success then
		error(err)
		_B.print("could not load game: " .. filename)
		_B.print(err)
	end
end

local init = function() end
do
	game.import = require
	local success, ret = _B.load(game, "core/init.lua")
	
	if success then
		init = ret
	else
		_B.printl(_B.printp(Color.Create(1, 0, 0, 1), ret))
	end
end

local abort = false
local shouldClose = false
local firstRun = true

local eventErrors = {}
local encounteredMajorError = false

local function event(t, type, event, e)
	if t.Game[type] and t.Game[type][event] and not firstRun and not encounteredMajorError then
		local args = pack(e)
		local success, err = xpcall(function() return t.Game[type][event](unpack(args)) end, debug.traceback, e)
		
		if not success then
			local s = string.format("%s.%s", type, event)
			
			if not eventErrors[s] then
				_B.print(_B.printp(Color.Create(1, 0, 0, 1), string.format("error in '%s':", s)))
				_B.printl(err or "unknown error", Color.Create(1, 0, 0, 1))
				eventErrors[s] = true
			end
		end
	end
end

-- Calls a method and returns one result, if any, along with a status
local function call(t, func, req, ...)
	if t.Game[func] then
		local args = pack(...)
		local success, ret = xpcall(function() return t.Game[func](unpack(args)) end, debug.traceback, ...)
		
		if success then
			return true, ret
		else
			if not abort then
				abort = true
				_B.printl(ret or "unknown error", Color.Create(1, 0, 0, 1))
				encounteredMajorError = true
			end
		end
	else
		if req and not abort then
			abort = true
			_B.print("no method " .. func ..	
				" found; press ESC or close window")
		end
	end
	
	return false
end

local ScalePoint, SetBounds, GetBounds, IsInBounds

-- Calculate the push/scale factors
do
	local pushX, pushY
	local scaleFactor, inverseScaleFactor
	
	scaleFactor = math.min(Display.height / screen.height,
		Display.width / screen.width)
	
	inverseScaleFactor = 1.0 / scaleFactor
	
	pushX = (Display.width - screen.width * scaleFactor) / 2
	pushY = (Display.height - screen.height * scaleFactor) / 2
	
	ScalePoint = function (x, y)
		return (x - pushX) * inverseScaleFactor,
			(Display.height - y - pushY) * inverseScaleFactor
	end
	
	SetBounds = function()
		Graphics.SetViewport(pushX, pushY, screen.width * scaleFactor,
			screen.height * scaleFactor)
	end
	
	GetBounds = function()
		local b = {}
		
		b.x = pushX
		b.y = pushY
		b.width = screen.width * scaleFactor
		b.height = screen.height * scaleFactor
		
		return b
	end
	
	IsInBounds = function(x, y)
		return not (x > screen.width or x < 0 or y > screen.height or y < 0)
	end
end

local function ResetBounds()
	Graphics.SetViewport(0, 0, conf.width, conf.height)
end

local measurements =
{
	shouldDisplay = false,
	currentFps = 0,
	frameAccum = 0,
	lastUpdate = 0
}

function Brightside.Update(fps, timestamp)
	local flush = false
	
	if firstRun then
		do
			local success, ret = pcall(init)
			game.import = nil
			
			if not success then
				_B.printl(ret)
			end
		end
		
		call(game, "Load", false)
		
		measurements.font = Font.Load("default/font.ttf", 10)
		measurements.color = Paint.Create(PaintMode.Solid)
		measurements.color:AddColor(Color.Create(0, 0, 0, 1))
		measurements.color:Finish()
		
		firstRun = false
		flush = true
	end
	
	local t = Main.CurrentTime()
	
	if t > measurements.lastUpdate + 1 then
		measurements.currentFps = measurements.frameAccum / 
			(t - measurements.lastUpdate)
		measurements.frameAccum = 0
		measurements.lastUpdate = t
	end
	
	local success, ret
	if not encounteredMajorError then
		success, ret = call(game, "Update", true, fps, timestamp)
	end
	
	if success and not abort then
		if ret[2] or flush then
			return ret[1], true
		else
			return ret[1], false
		end
	end
	
	return not shouldClose, flush
end

local letterBoxColor, backgroundColor

if conf.inverted then
	letterBoxColor = Color.Create(0, 0, 0, 0)
	backgroundColor = Color.Create(0, 0, 0, 0)
else
	letterBoxColor = Color.Create(0, 0, 0, 0)
	backgroundColor = Color.Create(1, 1, 1, 0)
end

function Brightside.Draw()
	ResetBounds()
	
	if conf.letterBoxing then
		Graphics.Clear(letterBoxColor, 0)
	else
		Graphics.Clear(backgroundColor, 0)
	end
	
	SetBounds()
	Graphics.Clear(backgroundColor, 0)
	Graphics.SetProjection(Matrix.Ortho(0, screen.width, 0, screen.height, -1, 1))
	Graphics.SetBlenderMode(BlenderMode.Alpha)
	
	if not firstRun and not encounteredMajorError then
		call(game, "Draw", false)
	end
	
	Graphics.Start2D()
	
	Graphics.SetView(Matrix.Identity())
	printd(screen.height)
	
	if measurements.shouldDisplay then
		local s =
		{
			string.format("FPS: %f", measurements.currentFps),
			string.format("Mem: %dkb [lua], %dkb [bs]", collectgarbage("count"),
				Debug.QueryMemoryUsage() / 1024) 
		}
		
		local y = screen.height
		
		for i = 1, #s do
			local fx, fy, fw = measurements.font:Measure(s[i])
			
			y = y - fy
			
			measurements.font:DrawText(measurements.color, screen.width - fw, 
				y, s[i])
		end
	end
	
	Graphics.Stop2D()
	
	measurements.frameAccum = measurements.frameAccum + 1
end

function Brightside.Close()
	if abort then
		shouldClose = true
	else
		call(game, "Close", true)
	end
end

function Brightside.Joystick.Axis(e)
	event(game, "Joystick", "Axis", e)
end

function Brightside.Joystick.ButtonDown(e)
	event(game, "Joystick", "ButtonDown", e)
end

function Brightside.Joystick.ButtonUp(e)
	event(game, "Joystick", "ButtonUp", e)
end

function Brightside.Mouse.Axis(e)
	e.x, e.y = ScalePoint(e.x, e.y)
	
	if IsInBounds(e.x, e.y) then
		event(game, "Mouse", "Axis", e)
	end
end

function Brightside.Mouse.ButtonDown(e)
	e.x, e.y = ScalePoint(e.x, e.y)
	
	if IsInBounds(e.x, e.y) then
		event(game, "Mouse", "ButtonDown", e)
	end
end

function Brightside.Mouse.ButtonUp(e)
	e.x, e.y = ScalePoint(e.x, e.y)
	
	if IsInBounds(e.x, e.y) then
		event(game, "Mouse", "ButtonUp", e)
	end
end

function Brightside.Keyboard.KeyDown(e)
	if e.keycode == Keycode.F1 then
		if Debug.isDebug == true then
			game.print("debug mode on")
			game.print("-- F1: help :)")
			game.print("-- F2: mem usage")
			game.print("-- F3: dump mem allocations")
			game.print("-- F4: collect garbage")
			game.print("-- F5: toggle various measurement displays")
		else
			game.print("debug mode off")
			game.print("-- F1: help :)")
			game.print("-- F4: collect garbage")
			game.print("-- F5: toggle various measurement displays")
		end
	elseif e.keycode == Keycode.F2 and Debug.isDebug == true then
		game.log("gc enabled", collectgarbage("isrunning"))
		game.log("lua mem usage (kb)", collectgarbage("count"))
		game.log("global mem usage (kb)", Debug.QueryMemoryUsage() / 1024)
	elseif e.keycode == Keycode.F3 and Debug.isDebug == true then
		Debug.DumpMemoryAllocations()
		game.print("dumped memory")
	elseif e.keycode == Keycode.F4 then
		collectgarbage("collect")
		game.print("collected garbage")
	elseif e.keycode == Keycode.F5 then
		measurements.shouldDisplay = not measurements.shouldDisplay
	end
	
	event(game, "Keyboard", "KeyDown", e)
end

function Brightside.Keyboard.KeyUp(e)
	event(game, "Keyboard", "KeyUp", e)
end

function Brightside.Keyboard.KeyPress(e)
	event(game, "Keyboard", "KeyPress", e)
end

function Brightside.Display.In(e)
	event(game, "Display", "In", e)
end

function Brightside.Display.Out(e)
	event(game, "Display", "Out", e)
end
