-- This is a special exception to the capitalization rules.
conf =
{
	width = 960,
	height = 540,
	samples = 4,
	isFullscreen = false,
	letterBoxing = true,
	soundEffects = true,
	musicVolume = 1,
	quality = 4
}
