Transition = {}

Transition.Type =
{
	None = 0,
	In = 1,
	Out = 2
}
readonly(Transition.Type)

local function CheckDone(self)
	if self.type == Transition.Type.None or
		self.position > self.time[self.type]
	then
		self.isDone = true
		self.type = Transition.Type.None
	else
		self.isDone = false
	end
end

local function NormalizePosition(self)
	if self.type == Transition.Type.None or self.time[self.type] == 0 then
		self.rawNormal = 1
	else
		self.rawNormal = self.position / self.time[self.type]
	end
		
	if self.type == Transition.Type.Out then
		self.normal = 1 - self.rawNormal
	else
		self.normal = self.rawNormal
	end
end

local function Update(self, elapsed)
	if not self.isDone then
		self.position = self.position + elapsed
		
		CheckDone(self)
		NormalizePosition(self)
	end
	
	return self.isDone
end

local function Switch(self, new)	
	if new ~= self.type and new ~= Transition.Type.None then
		self.position = self.time[new] * (1 - self.normal)
		self.isDone = false
	end
	
	self.type = new
	
	self:Update(0)
end

function Transition.Create(inTime, outTime, initial)
	local t =
	{
		position = 0,
		rawNormal = 0,
		normal = 0,
		
		isDone = false,
		type = initial or Transition.Type.In,
		
		time =
		{
			inTime or 0,
			outTime or 0
		}
	}
	
	t.Update = Update
	t.Switch = Switch
	
	if initial == Transition.Type.None then
		t.isDone = true
	end
	
	return t
end

readonly(Transition)
