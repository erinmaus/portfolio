EventQueue = {}
local _C = {}

function _C.__add(callbacks, func)
	Table.Insert(callbacks, func)
	
	return callbacks
end

function _C.__sub(callbacks, func)
	for i = 1, #callbacks do
		if callbacks[i] == func then
			Table.Remove(callbacks, i)
			
			break
		end
	end
	
	return callbacks
end

function _C.__call(callbacks, ...)
	for i = 1, #callbacks do
		callbacks[i](...)
	end
end

local function AddEventHandler(queue, name)
	if luatype(name) ~= "string" then
		error("expected string for name")
	end
	
	local e = {}
	
	Table.SetMetatable(e, _C)
	
	queue[name] = e
	
	return queue
end

local function AddEventHandlers(queue, ...)
	local names = { ... }
	
	for i = 1, #names do
		AddEventHandler(queue, names[i])
	end
end

function EventQueue.Create()
	local q = {}
	
	q.AddEventHandler = AddEventHandler
	q.AddEventHandlers = AddEventHandlers
	
	return q
end

require(_G, "core/events/input.lua")
require(_G, "core/events/action.lua")

readonly(EventQueue)
