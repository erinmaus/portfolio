EventQueue.Action = {}

EventQueue.Action.Type =
{
	Joystick = 1,
	Keyboard = 2,
	Mouse = 3
}
readonly(EventQueue.Action.Type)

local function CheckMovement(self, input)
	if self.type == EventQueue.Action.Type.Joystick then
		if input.current.joysticks[1] ~= nil
			and input.current.joysticks[1].sticks[self.stick] ~= nil
			and input.current.joysticks[1].sticks[self.stick].axes[self.axis] ~= nil
		then
			return input.current.joysticks[1].sticks[self.stick].axes[self.axis]
		else
			return 0
		end
	elseif self.type == EventQueue.Action.Type.Keyboard then
		local pos = 0
		
		if input.current.keyboard[self.up] then
			pos = pos + 1
		end
		
		if input.current.keyboard[self.down] then
			pos = pos - 1
		end
		
		return pos
	end
	
	return 0
end

local function CheckButton(self, input)
	if self.type == EventQueue.Action.Type.Joystick then
		return input.current.joysticks[1].buttons[self.button] or false
	elseif self.type == EventQueue.Action.Type.Keyboard then
		return input.current.keyboard[self.button] or false
	end
	
	return false
end

local function CheckAgainst(self, input)
	if self.type == EventQueue.Action.Type.Joystick then
		return input.joysticks[1].buttons[self.button] or false
	elseif self.type == EventQueue.Action.Type.Keyboard then
		return input.keyboard[self.button] or false
	end
	
	return false
end

-- Can only be keyboard and joystick
function EventQueue.Action.CreateMovement(type, arg1, arg2)
	local action = {}
	
	action.type = type
	
	if type == EventQueue.Action.Type.Joystick then
		action.stick = arg1
		action.axis = arg2
	elseif type == EventQueue.Action.Type.Keyboard then
		action.up = arg1
		action.down = arg2
	end
	
	action.Check = CheckMovement
	
	return action
end

function EventQueue.Action.CreateButton(type, arg)
	local action = {}
	
	action.type = type
	action.button = arg
	
	action.Check = CheckButton
	action.CheckAgainst = CheckAgainst
	
	return action
end

readonly(EventQueue.Action)
