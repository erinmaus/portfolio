EventQueue.Input = {}

EventQueue.Input.CallbackType =
{
	JoystickAxis = 1,
	JoystickButtonDown = 2,
	JoystickButtonUp = 3,
	KeyDown = 4,
	KeyUp = 5
}
readonly(EventQueue.Input.CallbackType)

local function GetJoystick(joysticks, index)
	local joystick
	
	if joysticks[index] == nil then
		joystick =
		{
			sticks = {},
			buttons = {}
		}
		
		joysticks[index] = joystick
	else
		joystick = joysticks[index]
	end
	
	return joystick
end

local function Destroy(self)
	local queue = self.callbacks.queue
	local callbacks = self.callbacks
	
	queue.JoystickAxis = queue.JoystickAxis - callbacks.onJoystickAxis
	queue.JoystickButtonDown = queue.JoystickButtonDown - callbacks.onJoystickButtonDown
	queue.JoystickButtonUp = queue.JoystickButtonUp - callbacks.onJoystickButtonUp
	queue.MouseAxis = queue.MouseAxis - callbacks.onMouseAxis
	queue.MouseButtonDown = queue.MouseButtonDown - callbacks.onMouseButtonDown
	queue.MouseButtonUp = queue.MouseButtonUp - callbacks.onMouseButtonUp
	queue.KeyDown = queue.KeyDown - callbacks.onKeyDown
	queue.KeyUp = queue.KeyUp - callbacks.onKeyUp
end

local function Update(self)
	self.previous = deepclone(self.current)
end

function EventQueue.Input.Create(queue)
	local self =
	{
		callbacks = {},
		
		previous = 
		{
			joysticks = {},
			keyboard = {},
			mouse =
			{
				axes = { x = 0, y = 0, z = 0, w = 0 },
				buttons = {}
			}
		},
		
		current =
		{
			joysticks = {},
			keyboard = {},
			mouse =
			{
				axes = { x = 0, y = 0, z = 0, w = 0 },
				buttons = {}
			}
		}
	}
	
	function self.callbacks.onNewInput(e)
		-- Dummy. Override.
	end
	
	function self.callbacks.onJoystickAxis(e)
		local cur = GetJoystick(self.current.joysticks, 1)
		
		if cur.sticks[e.stick] == nil then
			cur.sticks[e.stick] = { axes = {} }
		end
		
		cur.sticks[e.stick].axes[e.axis] = e.position
		
		self.callbacks.onNewInput(EventQueue.Input.CallbackType.JoystickAxis, e)
	end
	queue.JoystickAxis = queue.JoystickAxis + self.callbacks.onJoystickAxis
	
	function self.callbacks.onJoystickButtonDown(e)
		local cur = GetJoystick(self.current.joysticks, 1)
		
		cur.buttons[e.button] = true
		
		self.callbacks.onNewInput(EventQueue.Input.CallbackType.JoystickButtonDown, e)
	end
	queue.JoystickButtonDown = queue.JoystickButtonDown + self.callbacks.onJoystickButtonDown
	
	function self.callbacks.onJoystickButtonUp(e)
		local cur = GetJoystick(self.current.joysticks, 1)
		
		cur.buttons[e.button] = false
		
		self.callbacks.onNewInput(EventQueue.Input.CallbackType.JoystickButtonUp, e)
	end
	queue.JoystickButtonUp = queue.JoystickButtonUp + self.callbacks.onJoystickButtonDown
	
	function self.callbacks.onMouseAxis(e)
		self.current.mouse.axes.x = e.x
		self.current.mouse.axes.y = e.y
		self.current.mouse.axes.z = e.z
		self.current.mouse.axes.w = e.w
	end
	queue.MouseAxis = queue.MouseAxis + self.callbacks.onMouseAxis
	
	function self.callbacks.onMouseButtonDown(e)
		self.current.mouse.buttons[e.button] = true
	end
	queue.MouseButtonDown = queue.MouseButtonDown + self.callbacks.onMouseButtonDown
	
	function self.callbacks.onMouseButtonUp(e)
		self.current.mouse.buttons[e.button] = false
	end
	queue.MouseButtonUp = queue.MouseButtonUp + self.callbacks.onMouseButtonUp
	
	function self.callbacks.onKeyDown(e)
		self.current.keyboard[e.keycode] = true
		
		self.callbacks.onNewInput(EventQueue.Input.CallbackType.KeyDown, e)
	end
	queue.KeyDown = queue.KeyDown + self.callbacks.onKeyDown
	
	function self.callbacks.onKeyUp(e)
		self.current.keyboard[e.keycode] = false
		
		self.callbacks.onNewInput(EventQueue.Input.CallbackType.KeyUp, e)
	end
	queue.KeyUp = queue.KeyUp + self.callbacks.onKeyUp
	
	self.callbacks.queue = queue
	
	self.Destroy = Destroy
	self.Update = Update
	
	return self
end

readonly(EventQueue.Input)
