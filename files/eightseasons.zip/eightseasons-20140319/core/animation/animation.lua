Animation = {}

require(_G, "core/animation/frame.lua")
require(_G, "core/animation/skeletal.lua")
require(_G, "core/animation/skin.lua")

readonly(Animation)
