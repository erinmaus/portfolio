Animation.Skin = {}

local function Update(self, time, ...)
	local images = Table.Pack(...)
	
	for i = 1, #images do
		
	end
end

function Animation.Skin.Create(lg)
	local s = 
	{
		data =
		{
			skin = lg,
			interval = 1
		},
		
		cache = {}
	}
	
	s.Update = Update
	s.GetImage = GetImage
	
	return s
end

readonly(Animation.Skin)
