Animation.Frame = {}

local function Update(self, delta)
	self.currentTime = self.currentTime + delta
	
	if self.currentTime > self.fps then
		self.currentFrame = self.currentFrame + 1
		
		if self.currentFrame > #self.image[self.animation] then
			self.currentFrame = 1
		end
		
		self.currentTime = 0
	end
end

local function Reset(self, animation)
	self.currentFrame = 1
	self.currentTime = 0
	
	self.animation = animation or self.animation
end

function Animation.Frame.Create(image, animation, fps)
	local a =
	{
		image = image,
		animation = animation,
		currentFrame = 1,
		currentTime = 0,
		
		fps = fps or 0.125,
	}
	
	a.Update = Update
	a.Reset = Reset
	
	return a
end

readonly(Animation.Frame)
