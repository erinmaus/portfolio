Animation.Skeletal = {}

local function LoadSkeleton(filename)
	local success, ret = load({}, filename)
	
	if not success then
		error(ret)
	end
	
	return ret
end

local function CreateAnimationState(name, frame, t)
	local a =
	{
		name = name,
		frame = frame,
		time = t -- Time is in the range of 0..1
	}
	
	return a
end

local function FindNextFrame(cur, total)
	if cur + 1 <= total then
		return cur + 1
	else
		return 1
	end
end

local function PlaySingle(self, name)
	if name == "none" then
		for i = 1, #self.playInfo.bones do
			self.playInfo.bones[i].current = CreateAnimationState("none", 0, 0)
			self.playInfo.bones[i].next = CreateAnimationState("none", 0, 0)
		end
	else
		local anim = self.data.skeleton.animations[name]
		
		-- This helps show that the animation is non-existant
		if not anim then
			PlaySingle(self, "none")
			
			return false
		end
		
		for i = 1, #anim.requires do
			local bone = self.playInfo.bones[anim.requires[i]]
			
			if bone.current.name == "none" then
				bone.current = CreateAnimationState(name, 1, 0)
				bone.next = CreateAnimationState(name, FindNextFrame(1, #anim), 0)
			else
				--bone.previous = CreateAnimationState(name, 1, 0)
				bone.current = CreateAnimationState(name, 1, 0)
				bone.next = CreateAnimationState(name, FindNextFrame(1, #anim), 0)
			end
		end
	end
	
	return true
end

local function Play(self, ...)
	local r = {}
	local args = Table.Pack(...)
	
	for i = 1, #args do
		local success = PlaySingle(self, args[i])
		
		Table.Insert(r, success)
	end
	
	return Table.Unpack(r)
end

local function CreateMatrix(x, y, r, tx, ty)
	if tx and ty then
		return Matrix.Translate(x, y, 0) * Matrix.Translate(tx, ty, 0) * 
			Matrix.Rotate(r) * Matrix.Translate(-tx, -ty, 0)
	else
		return Matrix.Translate(x, y, 0) * Matrix.Rotate(r)
	end
end

local function GetTranslation(bone)
	if bone.anchor then
		return bone.anchor.x, bone.anchor.y
	else
		return 0, 0
	end
end

local function GetTranslationCenter(bone)
	if bone.offset then
		return bone.offset.x, bone.offset.y
	else
		return 0, 0
	end
end

local function GetBounds(bone, skin, matrix)
	local points -- Points are in the order top left, top right, bottom left, bottom right
	
	if bone.image ~= "none" then
		local bounds = skin:GetImage(bone.image):GetBounds()
		points =
		{
			Vector2.Create(bounds.x, bounds.y),
			Vector2.Create(bounds.x + bounds.width, bounds.y),
			Vector2.Create(bounds.x, bounds.y + bounds.height),
			Vector2.Create(bounds.x + bounds.width, bounds.y + bounds.height)
		}
	else
		return nil
	end
	
	for i = 1, #points do
		points[i] = matrix:Transform(points[i])
	end
	
	local min =
	{
		x = Math.Min(points[1].x, points[2].x, points[3].x, points[4].x),
		y = Math.Min(points[1].y, points[2].y, points[3].y, points[4].y)
	}
	
	local max =
	{
		x = Math.Max(points[1].x, points[2].x, points[3].x, points[4].x),
		y = Math.Max(points[1].y, points[2].y, points[3].y, points[4].y)
	}
	
	local bounds =
	{
		left = min.x,
		top = min.y,
		right = max.x,
		bottom = max.y
	}
	
	return bounds
end

local function Update(self, time)
	local bounds
	
	for i = 1, #self.playInfo.bones do
		-- Update animation state then cache
		local defaultBone = self.data.skeleton.bones[i]
		local cacheBone = self.playInfo.bones[i]
		local curAnim = self.data.skeleton.animations[cacheBone.current.name]
		local nextAnim = self.data.skeleton.animations[cacheBone.next.name]
		
		cacheBone.current.time = cacheBone.current.time + (time / self.data.interval)
		
		if cacheBone.current.time >= 1.0 and nextAnim then
			local dt = 1 - cacheBone.current.time
			cacheBone.current = cacheBone.next
			cacheBone.next = CreateAnimationState(cacheBone.current.name,
				FindNextFrame(cacheBone.current.frame, #curAnim),
				dt)
		end
		
		if curAnim == nil then
			if nextAnim == nil then
				local tx, ty = GetTranslation(defaultBone, self.data.skin)
				 
				cacheBone.matrix = CreateMatrix(defaultBone.x, defaultBone.y,
					defaultBone.rotation, tx, ty)
			end
		elseif nextAnim == nil then -- TODO: Make sure this never happens
			local curFrame = curAnim[cacheBone.current.frame][i]
			local tx, ty = GetTranslation(defaultBone, self.data.skin)
			
			cacheBone.matrix = CreateMatrix(curFrame.x, curFrame.y,
				curFrame.rotation, tx, ty)
		else
			local curFrame = curAnim[cacheBone.current.frame][i]
			local nextFrame = nextAnim[cacheBone.next.frame][i]
			local t = cacheBone.current.time
			local x = Math.Interpolate((curFrame.x or 0) + defaultBone.x, (nextFrame.x or 0) + defaultBone.x, t)
			local y = Math.Interpolate((curFrame.y or 0) + defaultBone.y, (nextFrame.y or 0) + defaultBone.y, t)
			local r = Spinor.SlerpAngles(curFrame.rotation or defaultBone.rotation, nextFrame.rotation or defaultBone.rotation, t)
			
			local tx, ty = GetTranslation(defaultBone)
			local cx, cy = GetTranslationCenter(defaultBone)
			
			cacheBone.matrix = CreateMatrix(x + cx, y + cy, r, tx, ty)
		end
		
		if defaultBone.parent > 0 then
			cacheBone.matrix = self.playInfo.bones[defaultBone.parent].matrix *
				cacheBone.matrix
		end
		
		-- Calculate bounds of the bone
		local b = GetBounds(defaultBone, self.data.skin, cacheBone.matrix)
		
		if bounds == nil then
			bounds = b
		else 
			bounds.left = Math.Min(bounds.left, b.left)
			bounds.top = Math.Min(bounds.top, b.top)
			bounds.right = Math.Max(bounds.right, b.right)
			bounds.bottom = Math.Max(bounds.bottom, b.bottom)
		end
	end
	
	self.playInfo.bounds = { x = bounds.left, y = bounds.top, 
		width = bounds.right - bounds.left, height = bounds.bottom - bounds.top }
end

local function Draw(self, matrix, callbacks)
	Graphics.PushView()
	
	for i = 1, #self.data.skeleton.order do
		local bone = self.playInfo.bones[self.data.skeleton.order[i]]
		local default = self.data.skeleton.bones[self.data.skeleton.order[i]]
		local view = matrix * bone.matrix
		
		Graphics.SetView(view)
		
		if default.image ~= "none" then
			self.data.skin:GetImage(default.image):Draw(0, 0)
		end
		
		if callbacks and callbacks[default.name] then
			callbacks[default.name](default, bone.matrix)
		end
		
		if self.data.debugPaint then
			if self.data.debugPaint.origin then
				self.data.debugPaint.origin:Fill(0, 0, 16, 16)
			end
			
			if self.data.debugPaint.anchor then
				local x, y = GetTranslation(default)
				
				self.data.debugPaint.anchor:Fill(x, y, 8, 8)
			end
			
			if self.data.debugPaint.offset then
				local x, y = GetTranslationCenter(default)
				
				self.data.debugPaint.offset:Fill(x, y, 4, 4)
			end
		end
	end
	
	Graphics.PopView()
end

function Animation.Skeletal.Load(filename)
	local s = LoadSkeleton(filename)
	
	return s
end

function Animation.Skeletal.CreateAnimator(skeleton, skin)
	local p =
	{
		data =
		{
			skeleton = skeleton,
			skin = skin,
			interval = 1
			--debugPaint = blabla 
		},
		
		playInfo =
		{
			bones = {},
			bounds = { x = 0, y = 0, width = 0, height = 0 }
		},
		
		cache =
		{
			skeleton = {}
		}
	}
	
	for i = 1, #skeleton.bones do
		p.playInfo.bones[i] =
		{
			matrix = Matrix.Identity()
		}
	end
	
	-- This builds the skeleton.
	Play(p, "none") -- "none" is reserved
	Update(p, 0)
	
	p.Play = Play
	p.Update = Update
	p.Draw = Draw
	
	return p
end

readonly(Animation.Skeletal)
