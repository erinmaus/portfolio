Resources = {}

-- Load callee metatable
local _L = {}

function _L.__call(self, filename, forceUnique, ...)
	if self.manager.resources[filename] and not forceUnique then
		return self.manager.resources[filename]
	else
		local r = _G[self.name].Load(filename, ...)
		
		if forceUnique then
			Table.Insert(self.manager.uniqueResources, r)
		else
			self.manager.resources[filename] = r
		end
		
		return r
	end
end

-- Load caller metatable
local function CreateLoadCaller(resourceManager)
	local _R = {}
	
	_R.__index = function(self, index)
		local l =
		{
			name = index,
			manager = resourceManager
		}
		
		Table.SetMetatable(l, _L)
		
		return l
	end
	
	local r = {}
	
	Table.SetMetatable(r, _R)
	
	return r
end

local function Destroy(self)
	for _, resource in pairs(self.resources) do
		if resource.Destroy then
			resource:Destroy()
		end
	end
	
	for i = 1, #self.uniqueResources do
		if self.uniqueResources[i].Destroy then
			self.uniqueResources[i]:Destroy()
		end
	end
end

function Resources.Create()
	local r =
	{
		resources = {},
		uniqueResources = {}
	}
	
	r.Load = CreateLoadCaller(r)
	r.Destroy = Destroy
	
	return r
end

readonly(Resources)
