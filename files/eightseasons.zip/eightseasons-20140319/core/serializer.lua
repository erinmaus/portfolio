local function value(object)
	local t = type(object)
	
	if t == "number" or t == "boolean" then
		return tostring(object)
	elseif t == "string" then
		return string.format("%q", object)
	elseif t == "function" then
		return "function() end"
	else
		return "nil"
	end 
end

function serialize(k, v, serialized)
	serialized = serialized or {}
	local s = k .. " = "
	
	if type(v) ~= "table" then
		s = string.format("%s%s\n", s, value(v))
	else
		if serialized[v] then
			s = string.format("%s%s\n", s, serialized[v])
		else
			serialized[v] = k
			
			s = s .. "{}\n"
			
			for tk, tv in pairs(v) do
				local field = string.format("%s[%s]", k, value(tk))
				
				s = s .. serialize(field, tv, serialized)
			end
		end
	end
	
	return s
end
