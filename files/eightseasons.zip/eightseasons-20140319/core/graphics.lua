GraphicsUtility = {}

function GraphicsUtility.CreatePaint(col)
	local p = Paint.Create(PaintMode.Solid)
	p:AddColor(col)
	p:Finish()
	
	return p
end

readonly(GraphicsUtility)
