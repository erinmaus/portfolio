Stage.Prop = {}

function Stage.Prop.Load(stage, prop)
	local g = sandbox()
	g.parent = stage
	
	local s, r = load(g, Stage.GetObjectFilename(prop[1]), prop)
	
	if not s then
		error(r)
	end
	
	g.id = prop[1]
	
	return g
end

readonly(Stage.Prop)
