Stage = {}

local function LoadStage(filename)
	local success, ret = load({}, filename)
	
	if not success then
		error(ret)
	end
	
	return ret
end

local function LoadGeometry(stage, data)
	for i = 1, #data.geometry do
		local geom = data.geometry[i]
		
		if geom[1] == "heightmap" then
			local width = geom[2]
			
			stage.geometry.heightmap.width = width
			
			for i = 3, #geom do
				stage.geometry:AddHeight(geom[i])
			end
		end
	end
end

local function LoadLayers(stage, data, isDelayed)
	for i = 1, #data.layers do
		local layer = data.layers[i]
		local l = {}
		
		if layer.scroll then
			l.scrollMultiplier = Vector2.Create(layer.scroll.x, layer.scroll.y)
		else
			l.scrollMultplier = Vector2.Create(1, 1)
		end
		
		if layer.size then
			l.size = Vector2.Create(layer.size.width, layer.size.height)
		else
			l.size = Vector2.Create(0, 0)
		end
		
		if layer.color then
			l.background = GraphicsUtility.CreatePaint(Color.Create(
				layer.color.red, layer.color.green, layer.color.blue, 1))
		end
		
		l.props = {}		
		for j = 1, #layer.props do
			local prop = layer.props[j]
			
			local s, r = call(Stage.Prop.Load, stage, prop)
			
			if isDelayed then
				Coroutine.Yield()
			end
			
			if not s then
				print(printp(Color.Create(1, 1, 0), r))
			else
				Table.Insert(l.props, r)
			end
		end
		
		Table.Insert(stage.layers, l)
	end
end

local function LoadPlayer(stage, data, entrance)
	local s, r = call(Stage.Prop.Load, stage, { "Player.Player", spawn = data.player[entrance] })
	
	if not s then
		print(printp(Color.Create(1, 0, 0), r))
	else
		Table.Insert(stage.actors, r)
	end 
end

local function Update(self, time)
	if not self.isPaused then
		self.geometry:Update(time)
	end
	
	for i = 1, #self.layers do
		for j = 1, #self.layers[i].props do
			local prop = self.layers[i].props[j]
			 
			if prop.Update then
				prop.Update(time)
			end
		end
	end
	
	if not self.isPaused then
		for i = 1, #self.actors do
			local actor = self.actors[i]
			
			if actor.Update then
				actor.Update(time)
			end
		end
	end
	
	self.camera:Update(time)
end

local function Draw(self, matrix)
	for i = 1, #self.layers do
		local layer = self.layers[i]
		local view = matrix * self.camera.layers[i].view
		local bounds = self.camera.layers[i].bounds
		
		if layer.background then
			layer.background:Fill(self.camera.offset.x, self.camera.offset.y, layer.size.x, layer.size.y)
		end
		
		for j = 1, #layer.props do
			local prop = layer.props[j]
			
			if prop.Draw then
				Graphics.PushView()
				
				prop.Draw(view, bounds)
				
				Graphics.PopView()
			end
		end
		
		if i == self.activeLayer then
			for j = 1, #self.actors do
				local actor = self.actors[j]
				
				if actor.Draw then
					Graphics.PushView()
					
					actor.Draw(view)
					
					Graphics.PopView()
				end
			end
		end
	end
	
	for i = 1, #self.hud.widgets do
		if self.hud.widgets[i].state.isActive then
			self.hud.widgets[i]:Draw()
		end
	end
end

local function FindByID(self, id)
	local r = {}
	
	for i = 1, #self.actors do
		if self.actors[i].id == id then
			Table.Insert(r, self.actors[i])
		end
	end
	
	return Table.Unpack(r)
end

local function Destroy(self)
	for i = 1, #self.layers do
		for j = 1, #self.layers[i] do
			if self.layers[i].props[j].Destroy then
				self.layers[i].props[j].Destroy()
			end
		end
	end
	
	for i = 1, #self.actors do
		if self.actors[i].Destroy then
			self.actors[i].Destroy()
		end
	end
	
	self.resources:Destroy()
end

function Stage.Load(filename, game, entrance, isDelayed)
	local data = LoadStage(filename)
	
	if isDelayed then
		Coroutine.Yield()
	end
	
	local s =
	{
		name = data.name or filename,
		activeLayer = data.activeLayer or 1,
		isPaused = false,
		
		actors = {},
		layers = {},
		hud =
		{
			widgets = {}
		},
		
		resources = Resources.Create(),
		game = game,
		
		input = game.input,
		keys =
		{
			action = EventQueue.Action.CreateButton(EventQueue.Action.Type.Keyboard, Keycode.Space)
		}
	}
	
	if not game.state.stage[filename] then
		game.state.stage[filename] = {}
		game.state.stage[filename].id = filename
	end
	
	s.state = game.state.stage[filename]
	game.state.player.lastStage = filename
	game.state.player.lastEntrance = entrance
	
	s.camera = Stage.Camera.Create(s, 64)
	
	s.geometry = Stage.Geometry.Create()
	
	LoadPlayer(s, data, entrance)
	LoadLayers(s, data, isDelayed)
	LoadGeometry(s, data)
	
	s.geometry.player = s.actors[1]
	
	s.Update = Update
	s.Draw = Draw
	s.FindByID = FindByID
	s.Destroy = Destroy
	
	return s
end

-- The prefix that is...prefixed to each prop's name
local prefix = "content/stages"

function Stage.GetObjectFilename(name, p)
	local s = Table.Pack(split(name, "%."))
	local filename = p or prefix
	
	for i = 1, #s do
		local part = s[i]:sub(1, 1):lower() .. s[i]:sub(2)
		
		filename = format("%s/%s", filename, part)
	end
	
	filename = format("%s.lua", filename)
	
	return filename
end

require(_G, "core/stage/camera.lua")
require(_G, "core/stage/geometry.lua")
require(_G, "core/stage/prop.lua")

readonly(Stage)
