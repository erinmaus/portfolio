Stage.Camera = {}

local function SmoothInterpolate(a, b, t)
	return a + (b - a) * t
end

local function UpdatePosition(self, time)
	local max = self.stage.layers[self.stage.activeLayer].size * self.zoom
	local tx = Math.Clamp(self.target.x * self.zoom - self.size.x / 2, 0, max.x - self.size.x)
	local ty = Math.Clamp(self.target.y * self.zoom - self.size.y / 2, 0, max.y - self.size.y)
	local t = time * self.dampening
	
	self.position = SmoothInterpolate(self.position, Vector2.Create(tx, ty), t)
end

local function Update(self, time)
	local oldPosition = self.position
	UpdatePosition(self, time)
	self.stage.game.MovePaper(oldPosition.x - self.position.x, oldPosition.y - self.position.y)
	
	self.zoom = Math.Interpolate(self.zoom, self.targetZoom, time * self.zoomDampening)
	
	for i = 1, #self.stage.layers do
		local layer = self.stage.layers[i]
		local x, y
		
		x = self.position.x * layer.scrollMultiplier.x
		y = self.position.y * layer.scrollMultiplier.y
		
		self.layers[i] = {}
		self.layers[i].view = Matrix.Translate(-x, -y, 0) * Matrix.Scale(self.zoom, self.zoom, 1)
		
		self.layers[i].bounds = {}
		self.layers[i].bounds.left = x * self.zoom
		self.layers[i].bounds.right = (x + Math.Min(self.size.x, layer.size.x)) / self.zoom
		self.layers[i].bounds.bottom = y * self.zoom
		self.layers[i].bounds.top = (y + Math.Min(self.size.y, layer.size.y)) / self.zoom
	end
end

local function Snap(self)
	local max = self.stage.layers[self.stage.activeLayer].size * self.targetZoom
	local tx = Math.Clamp((self.target.x * self.zoom - self.size.x / 2) / self.targetZoom, 0, max.x - self.size.x)
	local ty = Math.Clamp((self.target.y * self.zoom - self.size.y / 2) / self.targetZoom, 0, max.y - self.size.y)
	
	self.position = Vector2.Create(tx, ty)
	self.zoom = self.targetZoom
end

local function Draw(self)
	self.clipPaint:Fill(self.offset.x, self.offset.y, self.size.x, self.size.y,
		PaintClipMode.Clip)
end

function Stage.Camera.Create(stage)
	local c =
	{
		position = Vector2.Create(0, 0),
		target = Vector2.Create(0, 0),
		
		zoom = 1,
		targetZoom = 1,
		
		dampening = 2,
		zoomDampening = 1,
		
		offset = Vector2.Create(0, 0),
		size = Vector2.Create(Screen.Width, Screen.Height),
		
		clipPaint = GraphicsUtility.CreatePaint(Color.Create(0, 0, 0, 0)),
		
		stage = stage,
		layers = {}
	}
	
	c.Update = Update
	c.Draw = Draw
	c.Snap = Snap
	
	return c
end

readonly(Stage.Camera)
