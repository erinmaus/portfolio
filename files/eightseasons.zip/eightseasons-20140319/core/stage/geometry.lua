Stage.Geometry = {}

local function AddHeight(self, height)
	Table.Insert(self.heightmap.heights, height)
end

local function GetElevation(self, x, smooth)
	if smooth == nil then
		smooth = true
	end
	
	local normX = x / self.heightmap.width
	local tileIndex = Math.Clamp(Math.Floor(normX) + 1, 1, #self.heightmap.heights)
	local fract = normX - Math.Floor(normX)
	
	local curY = self.heightmap.heights[tileIndex]
	local nextY = self.heightmap.heights[Math.Min(tileIndex + 1, #self.heightmap.heights)]
	
	if smooth then
		fract = Math.SmoothStep(0, 1, fract)
	end
	
	return Math.Interpolate(curY, nextY, fract)
end

local function CreateEvent(self, position, width, callback)
	local e = {}
	
	e.position = position
	e.width = width
	e.callback = callback
	
	Table.Insert(self.events, e)
	
	return e
end

local function Update(self, delta)
	for i = 1, #self.events do
		local playerPosition = self.player.state.position
		local eventPosition = self.events[i].position
		local eventWidth = self.events[i].width
		
		if playerPosition.x > eventPosition and playerPosition.x < eventPosition + eventWidth then
			self.events[i].callback(self.player, true)
		else
			self.events[i].callback(self.player, false)
		end
	end
end

function Stage.Geometry.Create()
	local g = {}
	
	g.heightmap = {}
	g.heightmap.width = 64
	g.heightmap.heights = {}
	g.events = {}
	
	g.GetElevation = GetElevation
	g.AddHeight = AddHeight
	g.Update = Update
	g.CreateEvent = CreateEvent
	
	return g
end

readonly(Stage.Geometry)
