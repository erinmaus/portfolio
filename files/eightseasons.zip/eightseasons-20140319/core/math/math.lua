MathUtil = {}
MathUtil.Primitives = {}

function MathUtil.Primitives.PointInRectangle(x, y, w, h, px, py)
	local cx = px - x
	local cy = py - y
	
	return (cx >= 0 and cx <= w and cy >= 0 and cy <= h)
end

function MathUtil.Primitives.Bounds(a, b)
	return (a.left < b.right and a.right > b.left
		and a.bottom < b.top and a.top > b.bottom)
end

readonly(MathUtil.Primitives)
readonly(MathUtil)
