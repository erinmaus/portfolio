Spinor = {}

local function CreateSpinor(r, c)
	local s = Spinor.Create()
	
	s.real = r
	s.imaginary = c
	
	return s
end

local function GetLengthSquared(self)
	return self.real * self.real + self.imaginary * self.imaginary
end

local function GetLength(self)
	return Math.Sqrt(self:GetLengthSquared())
end

local function Normalize(self)
	local l = self:GetLength()
	
	return CreateSpinor(self.real / l, self.imaginary / l)
end

local function ToAngle(self)
	return Math.Atan2(self.imaginary, self.real) * 2
end

local _M = {}

function _M.__add(a, b)
	return CreateSpinor(a.real + b.real, a.imaginary + b.imaginary)
end

function _M.__mul(a, b)
	if luatype(b) == "number" then
		return CreateSpinor(a.real * b, b.imaginary * b)
	else
		return CreateSpinor(a.real * b.real - a.imaginary * b.imaginary,
			a.real * b.imaginary + a.imaginary * b.real)
	end
end

function _M.__unm(a)
	local s = CreateSpinor(a.real, -a.imaginary)
	local l = s:GetLength()
	
	s.real = s.real * l
	s.imaginary = s.imaginary * l
	
	return s 
end

function Spinor.Create(angle)
	local s = {}
	
	s.real = Math.Cos((angle or 0) * 0.5)
	s.imaginary = Math.Sin((angle or 0) * 0.5)
	
	s.GetLength = GetLength
	s.GetLengthSquared = GetLengthSquared
	s.Normalize = Normalize
	s.ToAngle = ToAngle
	
	Table.SetMetatable(s, _M)
	
	return s
end

function Spinor.Lerp(from, to, t)
	return CreateSpinor(Math.Interpolate(from.real, to.real, t),
		Math.Interpolate(from.imaginary, to.imaginary, t))
end

function Spinor.Slerp(from, to, t, e)
	local tr, tc, omega, cosom, sinom, s1, s2
	
	-- Get the dot product, or arccos
	cosom = from.real * to.real + from.imaginary * to.imaginary
	
	-- Adjust the sign, if required
	if cosom < 0 then
		cosom = -cosom
		tr = -to.real
		tc = -to.imaginary
	else
		tr = to.real
		tc = to.imaginary
	end
	
	-- Calculate coeffecients
	if (1.0 - cosom)  > (e or 0.001) then
		omega = Math.Acos(cosom)
		--sinom = Math.Sin(omega)
		sinom = Math.Sqrt(1.0 - cosom * cosom)
		
		s1 = Math.Sin((1.0 - t) * omega) / sinom
		s2 = Math.Sin(t * omega) / sinom
	 else
	 	s1 = 1.0 - t
	 	s2 = t
	 end
	 
	 -- Finish up!
	 return CreateSpinor(s1 * from.real + s2 * tr, s1 * from.imaginary + s2 * tc)
end

-- This method converts the angles to spinors and THEN rotates
-- Just for testing
function Spinor.SlerpAngles(from, to, t)
	local a = Spinor.Create(from)
	local b = Spinor.Create(to)
	
	return Spinor.Slerp(a, b, t):ToAngle()
end

readonly(Spinor)
