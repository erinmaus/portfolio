AudioManager = {}

local function IsMusicClean(self)
	for i = 1, #self.music do
		if not self.music[i].track.isPlaying then
			return false, i
		end
	end
	
	return true, nil
end

local function Update(self, delta)
	for i = 1, #self.samples do
		if self.samples[i] and not self.samples[i].isPlaying then
			self.samples[i]:Detach()
			self.samples[i]:Destroy()
			self.samples[i] = false -- Get rid of its entry
			
			Table.Insert(self.freeSamples, i)
		end
	end
	
	for i = 1, #self.music do
		self.music[i].duration = self.music[i].duration + delta
	end
	
	-- Adjust volume (gain) of music based on duration.
	for i = 1, #self.music do
		if not self.music[i].isJingle then
			if self.music[i].duration > self.core.musicFade then
				if self.music[i].mode == "start" then
					self.music[i].track.gain = 1
				else
					self.music[i].track.isPlaying = false
				end
			elseif not self.music[i].isJingle then
				local gain = self.music[i].duration / self.core.musicFade
				
				if self.music[i].mode == "end" then
					gain = 1 - gain
				end
				
				self.music[i].track.gain = Math.Clamp(gain, 0, 1)
			end
		end
	end
	
	local isClean, dirty = IsMusicClean(self)
	
	while not isClean do
		self.music[dirty].track:Detach()
		self.music[dirty].track:Destroy()
		
		Table.Remove(self.music, dirty)
		
		isClean, dirty = IsMusicClean(self)
	end
end

local function PrepareSample(self, sample)
	local index
	
	if #self.freeSamples > 0 then
		index = Table.Remove(self.freeSamples, 1)
	else
		index = #self.samples + 1
	end
	
	self.samples[index] = AudioSampleInstance.Create(sample)
	self.samples[index]:AttachToMixer(self.core.mixer)
	
	return self.samples[index]
end

local function IsSongPlaying(self, filename)
	for i = 1, #self.music do
		if self.music[i].filename == filename and self.music[i].mode == "start" then
			return true
		end
	end

	return false
end

local function PlaySong(self, filename, loop, jingle)
	if not jingle then
		-- Check to see if this song is already playing (if it's not a jingle)
		for i = 1, #self.music do
			if self.music[i].filename == filename and not self.music[i].isJingle then
				-- Check to see if it's ending; if so, reverse the process
				
				if self.music[i].mode == "end" then
					self.music[i].mode = "start"
					self.music[i].duration = self.core.musicFade - self.music[i].duration
				end
				
				-- If it is, don't play it.
				return false, self.music[i].track
			end
		end
	end
	
	local m = {}
	m.duration = 0
	m.track = AudioStream.Load(filename)
	m.filename = filename
	m.mode = "start"
	m.isJingle = jingle or false
	
	if loop then
		m.track.playMode = AudioPlayMode.Loop
	else
		m.track.playMode = AudioPlayMode.Once
	end
	
	m.track:AttachToMixer(self.core.musicMixer)
	
	for i = 1, #self.music do
		if not jingle and self.music[i].track.isPlaying then
			self.music[i].mode = "end"
			self.music[i].duration = 0
		end
	end
	
	Table.Insert(self.music, m)
	
	return true, m.track
end

local function Destroy(self)
	for i = 1, #self.samples do
		if self.samples[i] then
			self.samples[i]:Detach()
			self.samples[i]:Destroy()
			
			self.samples[i] = nil
		end
	end
	
	for i = 1, #self.music do
		self.music[i].track:Detach()
		self.music[i].track:Destroy()
	end
	
	self.core.soundEffectMixer:Detach()
	self.core.musicMixer:Detach()
	self.core.mixer:Detach()
	
	self.core.soundEffectMixer:Destroy()
	self.core.musicMixer:Destroy()
	self.core.mixer:Destroy()
	self.core.voice:Destroy()
end

function AudioManager.Create(freq)
	local a =
	{
		core =
		{
			voice = AudioVoice.Create(freq or 44100, AudioDepth.Int16, AudioChannel["2"]),
			mixer = AudioMixer.Create(freq or 44100, AudioDepth.Int16, AudioChannel["2"]),
			soundEffectMixer = AudioMixer.Create(freq or 44100, AudioDepth.Int16, AudioChannel["2"]),
			musicMixer = AudioMixer.Create(freq or 44100, AudioDepth.Int16, AudioChannel["2"]),
			musicFade = 1
		},
		
		samples = {},
		freeSamples = {},
		music = {}
	}
	
	a.Update = Update
	a.Destroy = Destroy
	a.PrepareSample = PrepareSample
	a.PlaySong = PlaySong
	a.IsSongPlaying = IsSongPlaying
	
	a.core.mixer:AttachToVoice(a.core.voice)
	a.core.soundEffectMixer:AttachToMixer(a.core.mixer)
	a.core.musicMixer:AttachToMixer(a.core.mixer)
	
	return a
end

readonly(AudioManager)
