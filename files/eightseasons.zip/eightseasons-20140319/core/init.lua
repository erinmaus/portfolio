local function exec(filename)
	local success, ret = load(_G, filename)
	
	if not success then
		error(ret)
	end
end

run = exec

local function init()
	exec("core/animation/animation.lua")
	exec("core/audio/manager.lua")
	exec("core/collision/collision.lua")
	exec("core/events/queue.lua")
	exec("core/graphics.lua")
	exec("core/lg/lg.lua")
	exec("core/logic/transition.lua")
	exec("core/math/math.lua")
	exec("core/math/spinor.lua")
	exec("core/resources/manager.lua")
	exec("core/stage/stage.lua")
	exec("core/state/state.lua")
	exec("core/story/story.lua")
	exec("core/ui/widget.lua")
	
	-- Remove the run method before sandboxing.
	run = nil
	
	-- This has to be executed last, since it creates a copy of the environment
	exec("core/sandbox/sandbox.lua")
end

return init
