LG = {}

local function Relativity(t)
	if t:lower() == t then
		return VectorCommandType.Relative
	else
		return VectorCommandType.Absolute
	end
end

local function CompilePath(path, quality)
	local p = VectorPath.Create(quality or settings().quality)
	
	for i = 1, #path do
		local command = path[i]
		local type = command[1]
		
		if type == "M" or type == "m" then
			p:MoveTo(command[2], command[3], Relativity(type))
		elseif type == "L" or type == "l" then
			p:LineTo(command[2], command[3], Relativity(type))
		elseif type == "C" or type == "c" then
			p:CubicTo(
				command[2], command[3],
				command[4], command[5],
				command[6], command[7],
				Relativity(type))
		elseif type == "Q" or type == "q" then
			p:QuadraticTo(
				command[2], command[3],
				command[4], command[5],
				Relativity(type))
		end
	end
	
	p:Finish()
	
	return p
end

local function CompilePaint(col)
	if not col then
		col = { red = 0, green = 0, blue = 0, alpha = 0 }
	end
	
	if rawtype(col) == "string" then
		return col
	else
		local p = Paint.Create(PaintMode.Solid)
		p:AddColor(Color.Create(col))
		p:Finish()
		
		return p
	end
end

-- Returns a pseudo-class that acts as an image, as necessary for some classes
-- (e.g., skeletal animations using LGs as skins)
-- This only draws the first frame, sadly.
local function GetImage(lg, image, frame)
	local i = {}
	
	function i:Draw(x, y)
		LG.Draw(lg, image, frame or 1, x or 0, y or 0)
	end
	
	function i:GetBounds()
		return LG.Bounds(lg, image, frame or 1)
	end
	
	return i
end

function LG.Load(filename)
	local success, lg = load({}, filename)
	
	if not success then
		error(lg)
	end
	
	lg.__filename = filename
	
	return lg
end


function LG.Compile(lg)
	local c = {}
	
	for groupName, group in pairs(lg) do
		if groupName ~= "__filename" then
			c[groupName] = {}
			
			for frameName, frame in pairs(lg[groupName]) do
				local f = {}
				
				for i = 1, #frame do
					local p =
					{
						fill = {}
					}
					
					local g = format("%s@%d", groupName, frameName)
					--if VectorPath.IsCached ~= nil and VectorPath.IsCached(lg.__filename, g, i, settings().quality) then
					--	p.fill.path = VectorPath.GetCachedPath(lg.__filename, g, i, settings().quality)
					--else
						p.fill.path = CompilePath(lg[groupName][frameName][i], settings().quality)
						
					--	if VectorPath.AddCachedPath ~= nil then
					--		VectorPath.AddCachedPath(lg.__filename, g, i, p.fill.path)
					--	end
					--end
					
					-- Only yield when caching stuff.
					if Coroutine.Current() ~= nil then
						Coroutine.Yield()
					end
					
					p.fill.paint = CompilePaint(lg[groupName][frameName][i].fill)
					
					Table.Insert(f, p)
				end
				
				c[groupName][frameName] = f
			end
		end
	end
	
	c.colorTable = colorTable
	c.GetImage = GetImage
	
	return c
end

function LG.Destroy(lg)
	lg.GetImage = nil
	
	for groupName, group in pairs(lg) do
		for i = 1, #group do
			for j = 1, #group[i] do
				group[i][j].fill.path:Destroy()
				
				if rawtype(group[i][j].fill.paint) ~= "string" then 
					group[i][j].fill.paint:Destroy()
				end
				
				if group[i][j].stroke then
					group[i][j].stroke.path:Destroy()
					
					if rawtype(group[i][j].fill.paint) ~= "string" then
						group[i][j].stroke.paint:Destroy()
					end
				end
			end
		end
	end
end

-- Draws one frame without interpolation
-- For interpolation, use an animated thingy
-- TODO: Implement said animated thingy
function LG.Draw(lg, group, frame, x, y, m)
	x = x or 0
	y = y or 0
	frame = frame or 1
	
	local f = lg[group][frame]
	
	if m then
		Graphics.PushView()
		Graphics.SetView(m)
	end
	
	for i = 1, #f do
		local fill = f[i].fill.paint
		
		if lg.colorTable and lg.colorTable[f[i].fill.paint] ~= nil then
			fill = lg.colorTable[f[i].fill.paint] 
		end
		
		f[i].fill.path:Draw(fill, x, y)
		
		if f[i].stroke then
			local stroke = f[i].stroke.paint 
			
			if lg.colorTable and lg.colorTable[f[i].stroke.paint] == nil then
				fill = lg.colorTable[f[i].stroke.paint]
			end
			
			f[i].stroke.path:Draw(stroke, x, y)
		end
	end
	
	if m then
		Graphics.PopView()
	end
end

-- Bounds go by fill, not stroke
function LG.Bounds(lg, group, frame)
	local f = lg[group][frame]
	
	-- No animation, no changing bounds per frame
	if f.bounds then
		return f.bounds
	end
	
	local l, r, t, b = Math.HugeValue, -Math.HugeValue, Math.HugeValue, -Math.HugeValue
	
	for i = 1, #f do
		local tx, ty, tw, th = f[i].fill.path:GetBounds()
		
		l = Math.Min(l, tx)
		b = Math.Min(b, ty)
		r = Math.Max(r, tw + tx)
		t = Math.Max(t, th + ty)
	end
	
	f.bounds = { x = l, y = b, width = r - l, height = t - b}
	f.bounds.rectangle = { left = l, right = r, bottom = b, top = t }
	
	return f.bounds
end


readonly(LG)
