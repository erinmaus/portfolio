-- Holds data regarding the scene. This value is returned.
-- The parent script is expected to set _S._G to something sane,
-- like a sandbox.
local _S =
{
	identifiers = {},
	resources = {},
	objects = {},
	animations = {},
	particles = {},
	env = {}
}

local function AddIdentifier(id, v)
	v.id = id
	
	if id ~= nil then
		if _S.identifiers[id] then
			_S.env.error("Identifier " .. id .. " already exists.")
		end
		
		_S.identifiers[id] = v
	end
end

local function GetIdentifier(id)
	return _S.identifiers[id]
end

local loaders = {}

function loaders.image(path, value)
	local env = _S.env
	local r = {}
	
	r.type = "image"
	r.resource = env.LG.Compile(env.LG.Load(path), env.settings().quality)
	r.Draw = function(o)
		r.resource:GetImage(value, o.frame or 1).Draw()
	end
	r.Destroy = function()
		env.LG.Destroy(r.resource)
	end
	
	return r
end

function loaders.paint(path, value)
	local env = _S.env
	local r = {}
	
	r.type = "paint"
	r.resource = env.GraphicsUtility.CreatePaint(env.Color.Create(value[1], value[2], value[3]))
	r.Draw = function()
		-- Nothing.
	end
	r.Destroy = function()
		r.resource:Destroy()
	end
	
	return r
end

function loaders.text(path, value)
	local env = _S.env
	local r = {}
	
	r.type = "text"
	r.resource = env.Font.Load(path, value[1], 16)
	
	local fill = env.GraphicsUtility.CreatePaint(env.Color.Create(value[2][1], value[2][2], value[2][3]))
	
	r.Draw = function()
		r.resource:DrawText(fill, 0, 0, value[3])
	end
	r.Destroy = function()
		r.resource:Destroy()
		fill:Destroy()
	end
	
	return r
end

function resource(t)
	local env = _S.env
	local r = loaders[t.type](t.path, t.value)
	
	env.Table.Insert(_S.resources, r)
	
	AddIdentifier(t.id, r)
end

function object(t)
	local env = _S.env
	local o = {}
	
	o.resource = GetIdentifier(t.resource)
	o.origin = t.origin or { 0, 0 }
	o.position = { 0, 0 }
	o.scale = { 1, 1 }
	o.rotation = 0
	o.alpha = 1
	o.isHidden = false
	
	env.Table.Insert(_S.objects, o)
	
	AddIdentifier(t.id, o)
	
	return o
end

local particles = {}
particles.snow = {}

	
function particles.snow.Initialize(system, t)
	local env = _S.env
	for i = 1, t.size do
		local p = {}
		
		p.lifeSpan = 0
		p.life = 0
		p.isDead = true
		
		env.Table.Insert(system.particles, p)
		env.Table.Insert(system.deadParticles, i)
	end
	
	system.startX = t.start[1]
	system.startY = t.start[2]
	system.width = t.width
	system.windFactor = t.windFactor
	system.gravity = t.gravity
	system.gravityVariance = t.gravityVariance
	system.offset = t.offset
	system.lifeSpanFactor = t.lifeSpanFactor
	system.lifeSpanVariance = t.lifeSpanVariance
	system.scaleFactor = t.scaleFactor
	system.scaleVariance = t.scaleVariance
	system.spawnChance = t.spawnChance
	
	for i = 1, t.batch do
		system:Update(t.spawnDelta or (1 / 60))
	end
end

function particles.snow.Update(system, delta)
	local env = _S.env
	
	if #system.deadParticles > 0 then
		local c = system.random:NextNumber()
		
		if c <= system.spawnChance then
			local index = env.Table.Remove(system.deadParticles)
			local p = system.particles[index]
			
			p.position = { system.startX + system.random:NextNumber() * system.width, system.startY }
			p.velocity = system.random:NextNumber() * system.gravityVariance
			p.scale = system.random:NextNumber() * system.scaleVariance + system.scaleFactor
			p.offset = system.random:NextNumber() * system.offset + system.offset
			p.lifeSpan = system.lifeSpanFactor + system.random:NextNumber() * system.lifeSpanVariance
			p.life = 0
			p.isDead = false
		end
	end
	
	for i = 1, #system.particles do
		local p = system.particles[i]
		
		if p.life >= p.lifeSpan then
			if not p.isDead then
				p.isDead = true
				env.Table.Insert(system.deadParticles, i)
			end
		else
			p.position[1] = p.position[1] + (system.windFactor + env.Math.Sin(p.life / p.offset) * system.windFactor) * delta
			p.position[2] = p.position[2] + system.gravity * delta
			
			p.life = p.life + delta
		end
	end
end

function particles.snow.Draw(system, view)
	local env = _S.env
	local Matrix = env.Matrix
	
	env.Graphics.PushBlenderMode()
	env.Graphics.SetBlenderMode(env.BlenderMode.TintAlpha)
	env.Graphics.SetBlenderTint(env.Color.Create(0, 0, 0, system.alpha or 1))
	
	for i = 1, #system.particles do
		local p = system.particles[i]
		
		if not p.isDead then
			local pos = Matrix.Translate(p.position[1], p.position[2], 0)
			local scale = Matrix.Scale(p.scale, p.scale, 1)
			
			env.Graphics.SetView(view * pos * scale)
			
			system.resource.Draw(system)
		end
	end
	
	env.Graphics.PopBlenderMode()
end

function particle(t)
	local env = _S.env
	
	local p = object(t)
	p.isParticleSystem = true
	
	p.particles = {}
	p.deadParticles = {}
	p.random = env.Random.Create(t.seed or 132)
	
	p.Update = particles[t.type].Update
	p.Draw = particles[t.type].Draw
	p.Reset = function()
		particles[t.type].Initialize(p, t)
	end
	
	p.Reset()
	
	return p
end

function animation(id)
	local env = _S.env
	local a = {}
	
	_S.currentAnimation = a
	env.Table.Insert(_S.animations, a)
	
	AddIdentifier(id, a)
end

-- Here be commands.
-- A command is expected to return a few values in the following order:
-- [bool]  - indicates if the animation should continue. Useful for yield
--           (basically, if the return value is false, no more commands
--          will be processed).
-- [bool]  - indicates if the animation is complete.
--           (ensures the command will be processed no further).
-- [table] - any changes since the last frame
--           (these changes should not be relative since last call; also,
--           there should be a value in the field called 'id' which
--           corresponds to the affected object)
--           
--
-- Also, a command receives a few* parameters. Here they are:
-- [number] - the elapsed duration of the command.
--            (divide the elapsed duration (x) by the total duration
--            to calculate a delta value)
--
-- *: only one for now...

-- Move an object over time.
function move(t)
	local env = _S.env
	local anim = _S.currentAnimation
	
	local c = function(elapsed)
		local r = {}
		r.id = t.target
		
		local done = false
		
		if t.duration then
			local delta = env.Math.Clamp(elapsed / t.duration, 0, 1)
			
			if t.interpolation == "smooth" then
				delta = env.Math.SmoothStep(0, 1, delta)
			end
			
			r.position = {}
			r.position[1] = env.Math.Interpolate(t.value[1][1], t.value[2][1], delta)
			r.position[2] = env.Math.Interpolate(t.value[1][2], t.value[2][2], delta)
			
			if delta >= 1 then
				done = true
			end
		else
			r.position = t.value[1]
			done = true
		end
		
		return false, done, r
	end
	
	env.Table.Insert(anim, c)
end

-- Bounces an object over time.
function bounce(t)
	local env = _S.env
	local anim = _S.currentAnimation
	
	local c = function(elapsed)
		local r = {}
		r.id = t.target
		
		local done = false
		
		if t.duration then
			local delta = env.Math.Clamp(elapsed / t.duration, 0, 1)
			
			if t.interpolation == "smooth" then
				delta = env.Math.SmoothStep(0, 1, delta)
			end

			local x = env.Math.Sin(t.value[2][1] * delta * env.Math.Pi * 2) * t.value[2][2]
			local y = env.Math.Sin(t.value[3][1] * delta * env.Math.Pi * 2) * t.value[3][2]
			
			r.position = {}
			r.position[1] = t.value[1][1] + x
			r.position[2] = t.value[1][2] + y
			
			if delta >= 1 then
				done = true
			end
		else
			done = true
		end
		
		return false, done, r
	end
	
	env.Table.Insert(anim, c)
end

-- Rotate an object over time.
function rotate(t)
	local env = _S.env
	local anim = _S.currentAnimation
	
	local c = function(elapsed)
		local r = {}
		r.id = t.target
		
		local done = false
		
		if t.duration then
			local delta = env.Math.Clamp(elapsed / t.duration, 0, 1)
			
			if t.interpolation == "smooth" then
				delta = env.Math.SmoothStep(0, 1, delta)
			end
			
			r.rotation = env.Math.Interpolate(t.value[1], t.value[2], delta)
			
			if delta >= 1 then
				done = true
			end
		else
			r.rotation = t.value[1]
			done = true
		end
		
		return false, done, r
	end
	
	env.Table.Insert(anim, c)
end

-- Scale an object over time.
function scale(t)
	local env = _S.env
	local anim = _S.currentAnimation
	
	local c = function(elapsed)
		local r = {}
		r.id = t.target
		
		local done = false
		
		if t.duration then
			local delta = env.Math.Clamp(elapsed / t.duration, 0, 1)
			
			if t.interpolation == "smooth" then
				delta = env.Math.SmoothStep(0, 1, delta)
			end
			
			r.scale = {}
			r.scale[1] = env.Math.Interpolate(t.value[1][1], t.value[2][1], delta)
			r.scale[2] = env.Math.Interpolate(t.value[1][2], t.value[2][2], delta)
			
			if delta >= 1 then
				done = true
			end
		else
			r.scale = t.value[1]
			done = true
		end
		
		return false, done, r
	end
	
	env.Table.Insert(anim, c)
end

-- Fade an object over time.
function fade(t)
	local env = _S.env
	local anim = _S.currentAnimation
	
	local c = function(elapsed)
		local r = {}
		r.id = t.target
		
		local done = false
		
		if t.duration then
			local delta = env.Math.Clamp(elapsed / t.duration, 0, 1)
			
			if t.interpolation == "smooth" then
				delta = env.Math.SmoothStep(0, 1, delta)
			end
			
			r.alpha = env.Math.Interpolate(t.value[1], t.value[2], delta)
			
			if delta >= 1 then
				done = true
			end
		else
			r.alpha = t.value[1]
			done = true
		end
		
		return false, done, r
	end
	
	env.Table.Insert(anim, c)
end

-- Shows an object.
function show(t)
	local env = _S.env
	local anim = _S.currentAnimation
	
	local c = function()
		local r = {}
		r.id = t.target
		r.frame = t.frame or 1
		r.isHidden = false
		
		return false, true, r
	end
	
	env.Table.Insert(anim, c)
end

-- Hides an object.
function hide(t)
	local env = _S.env
	local anim = _S.currentAnimation
	
	local c = function()
		local r = {}
		r.id = t.target
		r.isHidden = true
		
		return false, true, r
	end
	
	env.Table.Insert(anim, c)
end

-- Stalls any further commands until a duration has elapsed.
function yield(t)
	local env = _S.env
	local anim = _S.currentAnimation
	
	local c = function(elapsed)
		local done = false
		
		if elapsed >= t.duration then
			done = true
		end
		
		return not done, done, nil
	end
	
	env.Table.Insert(anim, c)
end

return _S
