Story = {}

require(_G, "core/story/scene.lua")

readonly(Story)
