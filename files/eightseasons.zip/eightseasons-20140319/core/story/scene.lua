Story.Scene = {}

local function LoadCommands()
	local e = {}
	local success, ret = load(e, "core/story/commands.lua")
	
	if not success then
		error(ret)
	end
	
	ret.env = sandbox()
	
	return e, ret
end

function Story.Scene.Load(filename)
	local env, scene = LoadCommands()
	local success, ret = load(env, filename)
	
	if not success then
		error(ret)
	end
	
	return scene
end

require(_G, "core/story/sceneView.lua")

readonly(Story.Scene)
