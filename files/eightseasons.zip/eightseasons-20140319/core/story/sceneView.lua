Story.Scene.Viewer = {}

local function CreateAnimation(anim)
	local a = {}
	
	for i = 1, #anim do
		a[i] =
		{
			elapsedDuration = 0,
			isDone = false,
			Update = anim[i]
		}
	end
	
	return a
end

local function Destroy(self)
	for _, resource in pairs(self.scene.resources) do
		resource.Destroy()
	end
end

local function FindObject(self, name, e)
	for i = 1, #self.objects do
		if self.objects[i].id == name then
			return self.objects[i]
		end
	end
	
	if e == nil or e == true then
		error("could not find object: " .. tostring(name))
	end
	
	return nil
end

local function Update(self, delta)
	if self.currentAnimation ~= nil and self.animations[self.currentAnimation] ~= nil then
		local anim = self.animations[self.currentAnimation]
		
		for i = 1, #anim do
			local command = anim[i]
			
			if not command.isDone then
				command.elapsedDuration = command.elapsedDuration + delta
				
				local yield, done, props = command.Update(command.elapsedDuration)
				
				if props ~= nil then
					local object = FindObject(self, props.id)
					
					for name, value in pairs(props) do
						object[name] = value
					end
				end
				
				if done then
					command.isDone = true
				end
				
				if yield then
					break
				end
			end
		end
	end
	
	-- Update particle systems
	for i = 1, #self.objects do
		if self.objects[i].isParticleSystem then
			self.objects[i]:Update(delta)
		end
	end
end

local function Draw(self, view)
	Graphics.PushView()
	
	for i = 1, #self.objects do
		local object = self.objects[i]
		
		if not object.isHidden and object.resource then
			local m = Matrix.Translate(object.position[1], object.position[2], 0) *
				Matrix.Translate(object.origin[1], object.origin[2], 0) *
				Matrix.Rotate(object.rotation) *
				Matrix.Scale(object.scale[1], object.scale[2], 1) *
				Matrix.Translate(-object.origin[1], -object.origin[2], 0)
			
			if view then
				m = view * m
			end
			
			if object.isParticleSystem then
				object:Draw(m)
			else
				Graphics.SetView(m)
				
				if object.alpha < 1 then
					Graphics.PushBlenderMode()
					Graphics.SetBlenderMode(BlenderMode.TintAlpha)
					
					Graphics.SetBlenderTint(Color.Create(0, 0, 0, object.alpha or 1))
				end
				
				object.resource.Draw(object)
				
				if object.alpha < 1 then
					Graphics.PopBlenderMode()
				end
			end
		end
	end
	
	Graphics.PopView()
end

local function Reset(self, clear)
	if clear then
		self.objects = {}
		
		for i = 1, #self.scene.objects do
			self.objects[i] = deepclone(self.scene.objects[i], nil, { [self.scene.objects[i].resource or ""] = true })
			self.objects[i].resource = self.scene.objects[i].resource
		end
	end
	
	if self.currentAnimation ~= nil and self.animations[self.currentAnimation] ~= nil then
		local anim = self.animations[self.currentAnimation]
		
		for i = 1, #anim do
			anim[i].elapsedDuration = 0
			anim[i].isDone = false
		end
	end
end

local function ChangeAnimation(self, newAnimation, clear)
	if clear == nil then
		clear = true
	end
	
	Reset(self, clear)
	
	self.currentAnimation = newAnimation
end

local function IsAnimationFinished(self)
	if self.currentAnimation == nil or self.animations[self.currentAnimation] == nil then
		return false
	end
	
	local anim = self.animations[self.currentAnimation]
	
	for i = 1, #anim do
		if not anim[i].isDone then
			return false
		end
	end
	
	return true
end

function Story.Scene.Viewer.Create(scene)
	local v = {}
	
	v.scene = scene
	v.animations = {}
	
	for i = 1, #scene.animations do
		v.animations[scene.animations[i].id] = CreateAnimation(scene.animations[i])
	end
	
	v.objects = {}
	
	v.Destroy = Destroy
	v.ChangeAnimation = ChangeAnimation
	v.Update = Update
	v.Draw = Draw
	v.IsAnimationFinished = IsAnimationFinished
	v.FindObject = FindObject
	
	return v
end

readonly(Story.Scene.Viewer)
