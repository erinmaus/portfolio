local fontSize = 12
local fontTranslucency = 1
local defaultColor = Color.Create(0, 1, 0, fontTranslucency)
local prefixColor = Color.Create(1, 1, 0, fontTranslucency)
local font = Font.Load("default/font.ttf", fontSize)
local messages = {}
local maxMessages = 16

local function CreateMessagePacket(c, m)
	local paint = Paint.Create(PaintMode.Solid)
	paint:AddColor(Color.Create(c.red, c.green, c.blue, fontTranslucency))
	paint:Finish()
	
	local p = { paint = paint, message = m }
	
	return p
end

local function DestroyMessagePacket(p)
	if p.paint then
		p.paint:Destroy()
		p.paint = nil
	end
end

local function FreeMessages()
	while #messages > maxMessages do
		for i = 1, #messages[1] do
			DestroyMessagePacket(messages[1][i])
		end
		
		Table.Remove(messages, 1)
	end
end

function printp(col, text)
	local t = { col, text }
	t.__isPacket = true
	
	return t
end

function print(...)
	local t = Table.Pack(...)
	local message = {}
	
	for i = 1, #t do
		if rawtype(t[i]) == "table" and t[i].__isPacket then
			Table.Insert(message, CreateMessagePacket(t[i][1], t[i][2]))
		else
			Table.Insert(message, CreateMessagePacket(defaultColor,
				tostring(t[i])))
		end
	end
	
	if #messages >= maxMessages then
		FreeMessages()
	end
	
	Table.Insert(messages, message)
end

function printl(message, col)
	local messages = Table.Pack(split(message, "\n"))
	
	for i = 1, #messages do
		if col then
			print(printp(col, messages[i]))
		else
			print(messages[i])
		end
	end
end

function log(from, ...)
	print(printp(prefixColor, format("%s:", tostring(from))), ...)
end

function maxprint(val)
	assert(val > -1, "max messages")
	
	maxMessages = val
	FreeMessages()
end

local function draw(top)
	local x
	local y = top - fontSize
	
	for i = 1, #messages do
		x = 0
		
		for j = 1, #messages[i] do
			local p = messages[i][j]
			local fx, fy, fw = font:Measure(format("%s ", tostring(p.message)))
			
			font:DrawText(p.paint, x, y, tostring(p.message))
			
			x = x + (fw)
		end
		
		y = y - fontSize
	end 
end

return draw
