Widget.DialogueBox = {}

local corners =
{
	-- name, x, y, w, h (for positions; see Draw())
	{ "topLeft", 1, 1, 0, 0 },
	{ "topRight", 1, 1, 1, 0 },
	{ "bottomLeft", 1, 1, 0, 1 },
	{ "bottomRight", 1, 1, 1, 1 }
}

local function Draw(self, x, y)
	x = x + self.x
	y = y + self.y
	
	if self.data.font and self.data.foreground and self.data.background and self.data.skin then
		self.data.background:Fill(x, y, self.width, self.height)
		
		for i = 1, #corners do
			local corner = self.data.skin:GetImage(corners[i][1])
			local bounds = corner:GetBounds()
			local cx = -(bounds.width / 2) + (x * corners[i][2] + self.width * corners[i][4])
			local cy = -(bounds.height / 2) + (y * corners[i][3] + self.height * corners[i][5])
			
			corner:Draw(cx, cy)
		end
		
		local x = x + self.data.padding
		local y = y + self.height - self.data.padding
		
		for i = 1, #self.data.lines do			
			local _, fh = self.data.font:Measure(self.data.lines[i])
			y = y - fh * self.data.lineSpacing
			
			self.data.font:DrawText(self.data.foreground, x, y, self.data.lines[i])
		end
	end
end

function Widget.DialogueBox.Create(...)
	local d = Widget.Create(...)
	
	d.data.padding = 0
	d.data.lineSpacing = 1.5
	d.data.lines = {}
	
	d:OnDraw(Draw)
	
	return d
end

function Widget.DialogueBox.Wrap(widget, text)
	local lineWidth = widget.width - widget.width + widget.data.padding * 2
	local spaceLeft = lineWidth
	local words = Table.Pack(split(text, "%s"))
	local lines = {}
	local current = ""
	
	for i = 1, #words do
		local word = words[i] .. " "
		local _, _, w = widget.data.font:Measure(word)
		
		if w > spaceLeft then
			Table.Insert(lines, current)
			current = word
			spaceLeft = lineWidth - w
		else
			current = current .. word
			spaceLeft = spaceLeft - w
		end
	end
	
	Table.Insert(lines, current)
	
	return lines
end

readonly(Widget.DialogueBox)
