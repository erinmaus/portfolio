Widget.Transition = {}

local function TransitionBase(time, update, type)
	local t = {}
	
	t.transition = Transition.Create(time, time, type or Transition.Type.In)
	t.Update = update
	
	return t
end

local function BaseUpdate(self, widget, time)
	if self.transition:Update(time) == true then
		widget:FinishTransition(self)
		
		return false
	else
		return true
	end
end

local Fade = {}

function Fade.Update(self, widget, time, type)
	if BaseUpdate(self, widget, time) then
		widget.data.alpha = self.transition.normal
	end
end

local Scale = {}

function Scale.Create(time, scale, type)
	local t = TransitionBase(time, Scale.Update, type)
	t.scale = scale
	
	return t
end

function Scale.Update(self, widget, time)
	if BaseUpdate(self, widget, time) then
		widget.data.scale = Math.Interpolate(1, self.scale,
			self.transition.normal)
	end
end

local Callback = {}
function Callback.Update(self, widget, time)
	if not BaseUpdate(self, widget, time) then
		self.Callback(widget)
	end
end

function Widget.Transition.Fade(time, type)
	return TransitionBase(time, Fade.Update, type)
end

-- Base method defaults to in hence no need to have a "FadeIn" constructor
function Widget.Transition.FadeOut(time)
	return TransitionBase(time, Fade.Update, Transition.Type.Out)
end

-- There is a reason this uses Out, but I can't recall it at this moment...
function Widget.Transition.Scale(time, scale)
	return Scale.Create(time, scale, Transition.Type.Out)
end

function Widget.Transition.ScaleOut(time, scale)
	return Scale.Create(time, scale, Transition.Type.In)
end

function Widget.Transition.Callback(time, callback)
	local t = TransitionBase(time, Callback.Update)
	t.Callback = callback
	
	return t
end

readonly(Widget.Transition)
