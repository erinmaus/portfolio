Menu = {}

-- "Self call"
local function scall(obj, method, ...)
	local success, ret = call(obj[method], obj, ...)
	
	if not success then
		log(method, tostring(ret))
	end
end

-- "Self call if"
local function scallif(obj, method, cond, ...)
	if cond == true then
		scall(obj, method, ...)
	end
end

-- "Hook call"
local function hcall(self, hook, ...)
	local success, ret = call(hook, self, ...)
	
	if not success then
		log(method, tostring(ret))
	end
end

-- "Generic event"
local function gevent(name)
	return function(self, e, ...)
		local event = "on" .. name
		
		for i = 1, #self.events[event] do
			hcall(self, self.events[event][i], e, ...)
		end
		
		for i = 1, #self.children do
			scall(self.children[i], name, e, ...)
		end
	end
end

-- "Func hook"
local function fhook(name)
	return function(self, func)
		local event = "on" .. name
		
		Table.Insert(self.events[event], func)
		
		return self
	end
end

local PostUpdate = gevent("Update")
local function Update(self, delta)
	PostUpdate(self, delta)
end

local function Draw(self, m)
end

function Menu.Create(parent, radius, ...)
	local menu =
	{
		events =
		{
			onUpdate = {},
			onDraw = {},
			onClick = {},
			onHide = {},
			onShow = {}
		},
		
		state =
		{
			isActive = false,
			isVisible = false
		},
		
		data =
		{
			targetOption = 0,
			currentOption = 0,
			radius = radius or 0
		},
		
		transitions = {},
		
		children = { ... },
		parent = parent
	}
	
	menu.
end

readonly(Menu)
