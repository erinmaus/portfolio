Widget.Button = {}

local function DrawLabel(self, x, y)
	local _, h, w = self.data.font:Measure(self.data.text)
	local col
	
	if self.state.isActive then
		col = self.data.background
	else
		col = self.data.foreground
	end
	
	--self.data.font:DrawText(col, x + (self.width - w) / 2, y + (self.height - h) / 2, self.data.text) 
	self.data.font:DrawText(col, x, y, self.data.text) 
end

local function Draw(self, x, y)
	x = x + self.x
	y = y + self.y
	
	if self.data.skin then
		
		local image, bounds
		
		if self.state.isActive then
			if self.state.wasClicked then
				image = self.data.skin:GetImage("click")
			else
				image = self.data.skin:GetImage("active")
			end
		else
			image = self.data.skin:GetImage("default")
		end
		
		bounds = image:GetBounds()
		
		local w = self.width / bounds.width
		local h = self.height / bounds.height
		
		Graphics.PushView()
		Graphics.MultiplyView(Matrix.Translate(x, y, 0) * Matrix.Scale(w, h, 1))
		
		image:Draw(0, 0)
		
		Graphics.PopView()
	end
		
	if self.data.text and self.data.font and self.data.foreground and self.data.background then
		DrawLabel(self, x, y)
	end
end

local function Click(self, e)
	if not self.state.wasClicked then 
		self.state.wasClicked = true
	
		self:Transition(Widget.Transition.Callback(self.data.clickDuration,
			function() self.state.wasClicked = false end))
	end
end

function Widget.Button.Create(...)
	local b = Widget.Create(...)
	
	b.data.clickDuration = 0.2
		
	b.state.wasClicked = false
	
	b:OnDraw(Draw)
	b:OnClick(Click)
	
	return b
end

readonly(Widget.Button)
