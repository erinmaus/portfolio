Widget = {}

-- "Self call"
local function scall(obj, method, ...)
	local success, ret = call(obj[method], obj, ...)
	
	if not success then
		log(method, tostring(ret))
	end
end

-- "Self call if"
local function scallif(obj, method, cond, ...)
	if cond == true then
		scall(obj, method, ...)
	end
end

-- "Hook call"
local function hcall(self, hook, ...)
	local success, ret = call(hook, self, ...)
	
	if not success then
		log(method, tostring(ret))
	end
end

-- "Generic event"
local function gevent(name)
	return function(self, e, ...)
		local event = "on" .. name
		
		for i = 1, #self.events[event] do
			hcall(self, self.events[event][i], e, ...)
		end
		
		for i = 1, #self.children do
			scall(self.children[i], name, e, ...)
		end
	end
end

-- "Func hook"
local function fhook(name)
	return function(self, func)
		local event = "on" .. name
		
		Table.Insert(self.events[event], func)
		
		return self
	end
end

local function IsTransitioning(self)
	if #self.transitions > 0 then
		self.state.isTransitioning = true
	else
		self.state.isTransitioning = false
	end
end

local PostUpdate = gevent("Update")
local function Update(self, time)
	-- TODO: Write Table.Shallow/Table.Clone/something
	local t = Table.Pack(Table.Unpack(self.transitions))
	
	for i = 1, #t do
		t[i]:Update(self, time)
	end
	
	IsTransitioning(self)
	
	PostUpdate(self, time)
end
local OnUpdate = fhook("Update")

local function Draw(self, x, y)
	x = x or 0
	y = y or 0
	
	for i = 1, #self.events.onDraw do
		hcall(self, self.events.onDraw[i], x, y)
	end
	
	for i = 1, #self.children do
		scall(self.children[i], "Draw", x + self.x, y + self.y)
	end
end
local OnDraw = fhook("Draw")

local function IsValidClick(self, px, py, x, y)
	return MathUtil.Primitives.PointInRectangle(self.x + px, self.y + py, 
		self.width, self.height, x, y)
end

local function MouseFunc(name, self, e, x, y)
	x = x or 0
	y = y or 0
	
	if not IsValidClick(self, x, y, e.x, e.y) then
		if name == "Hover" and self.state.isActive then
			name = "Blur"
			self.state.isActive = false
		else
			return false
		end
	else
		self.state.isActive = true
	end
	
	for i = 1, #self.events["on" .. name] do
		hcall(self, self.events["on" .. name][i], e)
	end
	
	for i = 1, #self.children do
		local c = self.children[i]
		local sx, sy = x + self.x, y + self.y
		
		if IsValidClick(c, sx, sy, e.x, e.y) or name == "Blur" then
			scall(c, name, e, sx, sy)
		elseif name == "Hover" then
			scall(c, "Blur", e, sx, sy)
		end
	end
	
	return true
end

local function Hover(self, e, x, y)
	return MouseFunc("Hover", self, e, x, y)
end
local OnHover = fhook("Hover")

local function Blur(self, e)
	self.state.isActive = false
	
	for i = 1, #self.events.onBlur do
		hcall(self, self.events.onBlur[i], e)
	end
	
	for i = 1, #self.children do
		scallif(self.children[i], "Blur",
			self.children[i].state.isActive == true, e)
	end
end
local OnBlur = fhook("Blur")  

local function Click(self, e, x, y)
	return MouseFunc("Click", self, e, x, y)
end
local OnClick = fhook("Click")

local function Key(self, e)
	for i = 1, #self.events.onKey do
		hcall(self, self.events.onKey[i], e)
	end
	
	for i = 1, #self.children do
		scallif(self.children[i], "Key", self.state.isActive == true, e)
	end
end
local OnKey = fhook("Key")

local function KeyPress(self, e)
	for i = 1, #self.events.onKeyPress do
		hcall(self, self.events.onKeyPress[i], e)
	end
	
	for i = 1, #self.children do
		scallif(self.children[i], "KeyPress", self.state.isActive == true, e)
	end
end
local OnKeyPress = fhook("KeyPress")

local function Transition(self, ...)
	local t = Table.Pack(...)
	
	for i = 1, #t do
		Table.Insert(self.transitions, t[i])
	end

	return self
end

local function FinishTransition(self, trans)
	for i = 1, #self.transitions do
		if self.transitions[i] == trans then
			Table.Remove(self.transitions, i)
			break
		end
	end
end

local function AppendChild(self, child)
	child.parent = self
	Table.Insert(self.children, child)
	
	return self
end

local function RemoveChild(self, child)
	for i = 1, #self.children do
		if self.children[i] == child then
			Table.Remove(self.children, i)
			break
		end
	end
end

function Widget.Create(x, y, w, h)
	local widget =
	{
		events =
		{
			onUpdate = {},
			onDraw = {},
			onClick = {},
			onHover = {},
			onBlur = {},
			onKey = {},
			onKeyPress = {}
		},
		
		state =
		{
			isActive = false,
			isTransitioning = false,
			isVisible = true
		},
		
		data = 
		{
			alpha = 1,
			scale = 1
		},
		
		children = {},
		transitions = {},
		
		width = w or 0,
		height = h or 0,
		x = x or 0,
		y = y or 0,
	}
	
	widget.Update = Update
	widget.OnUpdate = OnUpdate
	widget.Draw = Draw
	widget.OnDraw = OnDraw
	widget.Click = Click
	widget.OnClick = OnClick
	widget.Hover = Hover
	widget.OnHover = OnHover
	widget.Blur = Blur
	widget.OnBlur = OnBlur
	widget.Key = Key
	widget.OnKey = OnKey
	widget.KeyPress = KeyPress
	widget.OnKeyPress = OnKeyPress
	widget.AppendChild = AppendChild
	widget.RemoveChild = RemoveChild
	widget.Transition = Transition
	widget.FinishTransition = FinishTransition
	
	return widget
end

load(_G, "core/ui/transition.lua")

load(_G, "core/ui/button.lua")
load(_G, "core/ui/dialogueBox.lua")

readonly(Widget)
