local function OriginalMetatable(new, old)
	Table.SetMetatable(new, Table.GetMetatable(old))
end
local _S = deepclone(_G, OriginalMetatable, { [_G] = true, [Game] = true })

function sandbox()
	local r = deepclone(_S, OriginalMetatable, { [_S] = true })
	r._G = r
	r.sandbox = sandbox
	
	return r
end
