Collision.Shape = {}

local function RecalculateAxes(self)
	for i = 1, #self.points do
		local p1, p2
		
		p1 = self.points[i]
		
		if i + 1 > #self.points then
			p2 = self.points[1]
		else
			p2 = self.points[i + 1]
		end
		
		local p = p2 - p1
		local v = Vector2.Create(-p.y, p.x)
		v = Vector2.Normalize(v)
		
		self.axes[i] = v
	end
end

local function UpdateBounds(self)
	local x1, y1, x2, y2 = self.points[1].x, self.points[1].y, self.points[1].x, self.points[1].y
	
	for i = 2, #self.points do
		x1 = Math.Min(x1, self.points[i].x)
		y1 = Math.Min(y1, self.points[i].y)
		x2 = Math.Max(x2, self.points[i].x)
		y2 = Math.Max(y2, self.points[i].y)
	end
	
	self.bounds.left = x1 + self.offset.x
	self.bounds.right = x2 + self.offset.x
	self.bounds.top = y1 + self.offset.y
	self.bounds.bottom = y2 + self.offset.y
end

local function UpdatePosition(self, offset)
	self.offset = offset
	
	UpdateBounds(self)
end

local function ProjectAxes(self, axis, offset)
	offset = offset or Vector2.Create(0, 0)
	local min = Vector2.Dot(self.points[1] + self.offset + offset, axis)
	local max = min
	
	for i = 2, #self.points do
		local dot = Vector2.Dot(self.points[i] + self.offset + offset, axis)
		
		min = Math.Min(min, dot)
		max = Math.Max(max, dot)
	end
	
	return Vector2.Create(min, max)
end

local function CheckWinding(self)
	local edge1 = self.points[2] - self.points[1]
	local edge2 = self.points[3] - self.points[2]
	
	if (edge1.x * edge2.y) - (edge1.y * edge2.x) < 0 then
		return -1
	else
		return 1
	end
end

function Collision.Shape.Rectangle(w, h, offset)
	local points =
	{
		Vector2.Create(0, 0),
		Vector2.Create(0, h),
		Vector2.Create(w, h),
		Vector2.Create(w, 0)
	}
	
	return Collision.Shape.Polygon(points, offset)
end

function Collision.Shape.Polygon(points, offset)
	local p =
	{
		axes = {},
		points = points,
		bounds = {},
		offset = offset or Vector2.Create(0, 0)
	}
	
	p.cells = { left = 0, top = 0, right = 0, bottom = 0 }
	
	RecalculateAxes(p)
	UpdateBounds(p)
	
	p.UpdatePosition = UpdatePosition
	p.Project = ProjectAxes
	p.Winding = CheckWinding
	
	return p
end

readonly(Collision.Shape)
