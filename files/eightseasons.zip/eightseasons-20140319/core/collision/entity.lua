Collision.Entity = {}

local function Update(self, world, time)
	if self.isStatic then
		return false
	end
	
	for i = 1, #world.forces do
		world.forces[i](self, time)
	end
	
	self.position = self.position + self.velocity * time
	
	self.shape:UpdatePosition(self.position)
	
	return true
end

local function Respond(self, depth, normal, other)
	if not self.isStatic then
		for i = 1, #self.events.onCollision do
			self.events.onCollision[i](self, depth, normal, other)
		end
		
		self.shape:UpdatePosition(self.position)
	end
end

local function OnCollision(self, callback)
	Table.Insert(self.events.onCollision, callback)
end

function Collision.Entity.Create(shape, position)
	local e =
	{
		position = position or Vector2.Create(0, 0),
		velocity = Vector2.Create(0, 0),
		shape = shape,
		
		events =
		{
			onCollision = {}
		}
	}
	
	e.Update = Update
	e.Respond = Respond
	e.OnCollision = OnCollision
	
	return e
end