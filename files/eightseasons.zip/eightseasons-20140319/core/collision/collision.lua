Collision = {}

local function BoundsTest(a, b, s, t)
	return not (b.left + t.x > a.right + s.x or b.right + t.x < a.left + s.x
		or b.top + t.y > a.bottom + s.y or b.bottom + t.y < a.top + s.y)
end

local function GetOverlap(a, b)
	if a.x < b.x then
		return b.x - a.y
	else
		return a.x - b.y
	end
end

local function Test(a, b, s, t)
	local overlap, minimum = Math.HugeValue, nil
	local axes = { Table.Unpack(b.axes), Table.Unpack(a.axes) }
	
	for i = 1, #axes do
		axis = axes[i]
		local p1, p2, v = a:Project(axis, s), b:Project(axis, t)
		local o = GetOverlap(p1, p2)
		
		if o > 0 then
			return false, nil
		else
			o = Math.Abs(o)
			
			if o < overlap then
				overlap = o
				minimum = axis
			end
		end
	end
	
	return true, overlap, minimum
end

local function Update(self, time)
	if true then return false end
	
	-- Resolve collisions.
	for pass = 1, self.resolutions do
		for i = 1, #self.entities do
			local s = self.entities[i].velocity * time
			
			for j = 1, #self.entities do
				local t = self.entities[j].velocity * time
				
				-- Check if the bounding boxes intercept.
				if i ~= j and BoundsTest(self.entities[i].shape.bounds, self.entities[j].shape.bounds, s, t) then
					local collided, depth, normal = Test(self.entities[i].shape, self.entities[j].shape, s, t)
					
					if collided and not self.entities[j].isStatic then						
						local difference = (self.entities[j].shape.offset + t) - (self.entities[i].shape.offset + s)
						
						if Vector2.Dot(difference, normal) > 0 then
							normal.x = -normal.x
							normal.y = -normal.y
						end
						
						if self.entities[i].isStatic then
							if not self.entities[j].isStatic then
								self.entities[j]:Respond(-depth, normal, self.entities[i])
							end
						else
							if not self.entities[j].isStatic then
								self.entities[i]:Respond(depth * 0.5, normal, self.entities[j])
								self.entities[j]:Respond(-(depth * 0.5), normal, self.entities[i])
							else
								self.entities[i]:Respond(depth, normal, self.entities[j])
							end
						end
					end
				end
			end
		end
	end
	
	for i = 1, #self.entities do
		-- Update forces on entity.
		self.entities[i]:Update(self, time)
	end
end

local function AttachEntity(self, entity)
	Table.Insert(self.entities, entity)
end

local function AttachStatic(self, shape)
	local entity = Collision.Entity.Create(shape)
	entity.isStatic = true
	
	Table.Insert(self.entities, entity)
end

local function AttachForce(self, force)
	-- `force' is a function that takes an entity and a delta as parameters
	-- Does nothing if the entity is static.
	Table.Insert(self.forces, force)
end

function Collision.Create()
	local c =
	{
		entities = {},
		forces = {},
		resolutions = 8
	}
	
	c.Update = Update
	c.AttachEntity = AttachEntity
	c.AttachStatic = AttachStatic
	c.AttachForce = AttachForce
	
	return c
end

require(_G, "core/collision/entity.lua")
require(_G, "core/collision/shape.lua")

readonly(Collision)