resource {
	id = "tree",
	type = "image",
	path = "content/overlays/battle/background.lg",
	value = "tree"
}

resource {
	id = "momentumBar",
	type = "image",
	path = "content/overlays/battle/background.lg",
	value = "momentumBar"
}

resource {
	id = "frame",
	type = "image",
	path = "content/overlays/battle/background.lg",
	value = "frame"
}

object {
	id = "Tree",
	resource = "tree"
}

object {
	id = "MomentumBar",
	resource = "momentumBar"
}

object {
	id = "Frame",
	resource = "frame"
}

animation "Default"

move {
	target = "Frame",
	value = { { 480, 230 } }
}

move {
	target = "Tree",
	value = { { 820, 32 } }
}

move {
	target = "MomentumBar",
	value = { { 480, 410 } }
}
