resource {
	id = "circle",
	type = "image",
	path = "content/overlays/battle/circle.lg",
	value = "circle"
}

resource {
	id = "left",
	type = "image",
	path = "content/overlays/battle/left.lg",
	value = "left"
}

resource {
	id = "right",
	type = "image",
	path = "content/overlays/battle/right.lg",
	value = "right"
}

object {
	id = "HaikuCircle",
	resource = "circle"
}

object {
	id = "HaikuTotem"
}

object {
	id = "OpponentCircle",
	resource = "circle"
}

object {
	id = "OpponentTotem"
}

object {
	id = "Left",
	resource = "left"
}

object {
	id = "Right",
	resource = "right"
}

animation "Begin"

hide {
	target = "Left"
}

hide {
	target = "Right"
}

move {
	target = "HaikuCircle",
	value = { { 200, 270 } }
}

move {
	target = "HaikuTotem",
	value = { { 200, 270 } }
}

hide {
	target = "HaikuTotem"
}

move {
	target = "OpponentCircle",
	value = { { 760, 270 } }
}

move {
	target = "OpponentTotem",
	value = { { 760, 270 } }
}

hide {
	target = "OpponentTotem"
}

fade {
	target = "HaikuCircle",
	value = { 0, 1 },
	interpolation = "smooth",
	duration = 1
}

fade {
	target = "OpponentCircle",
	value = { 0, 1 },
	interpolation = "smooth",
	duration = 1
}

yield {
	duration = 1
}

show {
	target = "HaikuTotem"
}

show {
	target = "OpponentTotem"
}

fade {
	target = "HaikuTotem",
	value = { 0, 1 },
	interpolation = "smooth",
	duration = 0.5
}

fade {
	target = "OpponentTotem",
	value = { 0, 1 },
	interpolation = "smooth",
	duration = 0.5
}

yield {
	duration = 1
}

rotate {
	target = "HaikuCircle",
	value = { 0, 6.14 },
	interpolation = "smooth",
	duration = 1
}

rotate {
	target = "OpponentCircle",
	value = { 0, 6.28 },
	interpolation = "smooth",
	duration = 1
}

yield {
	duration = 1
}

show {
	target = "Left"
}

show {
	target = "Right"
}

move {
	target = "Left",
	value = { { -480, 0 }, { 0, 0 } },
	interpolation = "smooth",
	duration = 1
}

move {
	target = "Right",
	value = { { 960, 0 }, { 480, 0 } },
	interpolation = "smooth",
	duration = 1
}

yield {
	duration = 1
}

animation "End"

hide {
	target = "HaikuCircle"
}

hide {
	target = "HaikuTotem"
}

hide {
	target = "OpponentCircle"
}

hide {
	target = "OpponentTotem"
}

show {
	target = "Left"
}

show {
	target = "Right"
}

move {
	target = "Left",
	value = { { 0, 0 }, { -480, 0 } },
	interpolation = "smooth",
	duration = 1
}

move {
	target = "Right",
	value = { { 480, 0 }, { 960, 0 } },
	interpolation = "smooth",
	duration = 1
}

yield {
	duration = 1
}

hide {
	target = "Left",
}

hide {
	target = "Right"
}

animation "Close"

hide {
	target = "HaikuCircle"
}

hide {
	target = "HaikuTotem"
}

hide {
	target = "OpponentCircle"
}

hide {
	target = "OpponentTotem"
}

move {
	target = "Left",
	value = { { -480, 0 }, { 0, 0 } },
	interpolation = "smooth",
	duration = 1
}

move {
	target = "Right",
	value = { { 960, 0 }, { 480, 0 } },
	interpolation = "smooth",
	duration = 1
}

yield {
	duration = 1
}
