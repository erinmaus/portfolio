resource {
	id = "dialogueFrame",
	type = "image",
	path = "content/overlays/dialogue/dialogue.lg",
	value = "frame"
}

resource {
	id = "headFrame",
	type = "image",
	path = "content/overlays/dialogue/head.lg",
	value = "frame"
}

resource {
	id = "nameFrame",
	type = "image",
	path = "content/overlays/dialogue/name.lg",
	value = "frame"
}

object {
	id = "DialogueFrame",
	resource = "dialogueFrame"
}

object {
	id = "HeadFrame",
	resource = "headFrame",
	origin = { 135, 150 }
}

object {
	id = "NameFrame",
	resource = "nameFrame",
	origin = { 115, 50 }
}

animation "Start-Narrator"

move {
	target = "HeadFrame",
	value = { { -300, 180 } }
}

move {
	target = "NameFrame",
	value = { { -300, 65 } }
}

hide {
	target = "HeadFrame"
}

hide {
	target = "NameFrame"
}

move {
	target = "DialogueFrame",
	value = { { 960, 45 }, { 200, 45 } },
	interpolation = "smooth",
	duration = 0.5
}

animation "Start-Speaker"

move {
	target = "DialogueFrame",
	value = { { 960, 45 }, { 350, 45 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "HeadFrame",
	value = { { -300, 180 }, { 70, 180 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "NameFrame",
	value = { { -300, 65 }, { 80, 65 } },
	interpolation = "smooth",
	duration = 0.5
}

animation "In-Speaker"

show {
	target = "HeadFrame"
}

show {
	target = "NameFrame"
}

move {
	target = "DialogueFrame",
	value = { { 200, 45 }, { 350, 45 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "HeadFrame",
	value = { { -300, 180 }, { 70, 180 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "NameFrame",
	value = { { -300, 65 }, { 80, 65 } },
	interpolation = "smooth",
	duration = 0.5
}

yield {
	duration = 0.5
}

animation "In-Narrator"

move {
	target = "HeadFrame",
	value = { { 70, 180 }, { -300, 180 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "NameFrame",
	value = { { 80, 65 }, { -300, 65 } },
	interpolation = "smooth",
	duration = 0.5
}

yield {
	duration = 0.5
}

hide {
	target = "HeadFrame"
}

hide {
	target = "NameFrame"
}

move {
	target = "DialogueFrame",
	value = { { 350, 45 }, { 200, 45 } },
	interpolation = "smooth",
	duration = 0.5
}

animation "Out-Speaker"

move {
	target = "HeadFrame",
	value = { { 70, 180 }, { -300, 180 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "NameFrame",
	value = { { 80, 65 }, { -300, 65 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "DialogueFrame",
	value = { { 350, 45 }, { 960, 45 } },
	interpolation = "smooth",
	duration = 0.5
}

animation "Out-Narrator"

move {
	target = "HeadFrame",
	value = { { 70, 180 }, { -300, 180 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "NameFrame",
	value = { { 80, 65 }, { -300, 65 } },
	interpolation = "smooth",
	duration = 0.5
}

move {
	target = "DialogueFrame",
	value = { { 200, 45 }, { 960, 45 } },
	interpolation = "smooth",
	duration = 0.5
}

animation "neutral"

animation "happy"

bounce {
	target = "DialogueFrame",
	value = { { 350, 45 }, { 0, 0 }, { 1, 20 } },
	interpolation = "linear",
	duration = 0.5
}

animation "angry"

bounce {
	target = "DialogueFrame",
	value = { { 350, 45 }, { 4, 15 }, { 0, 0 } },
	interpolation = "linear",
	duration = 0.5
}

animation "sad"

bounce {
	target = "DialogueFrame",
	value = { { 350, 45 }, { 0, 0 }, { 0.5, -30 } },
	interpolation = "linear",
	duration = 0.5
}
