resource {
	id = "page",
	type = "image",
	path = "content/scenes/common/page.lg",
	value = "page"
}

object {
	id = "Page",
	resource = "page",
	origin = { 0, 0 }
}

animation "In"

move {
	target = "Page",
	value = { { 960, 0 }, { 100, 0 } },
	interpolation = "smooth",
	duration = 0.5
}

animation "Out"

yield {
	duration = 0.5
}

move {
	target = "Page",
	value = { { 100, 0 }, { 960, 0 } },
	interpolation = "smooth",
	duration = 0.5
}
