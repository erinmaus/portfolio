resource {
	id = "haiku",
	type = "image",
	path = "content/scenes/tutorial/haiku.lg",
	value = "haiku"
}

resource {
	id = "glass1",
	type = "image",
	path = "content/scenes/tutorial/glass1.lg",
	value = "glass"
}

resource {
	id = "temple",
	type = "image",
	path = "content/scenes/tutorial/temple.lg",
	value = "temple"
}

resource {
	id = "glass2",
	type = "image",
	path = "content/scenes/tutorial/glass2.lg",
	value = "glass"
}


resource {
	id = "page",
	type = "image",
	path = "content/scenes/common/page.lg",
	value = "page"
}

object {
	id = "Haiku",
	resource = "haiku",
	origin = { 40, 70 }
}

object {
	id = "Glass1",
	resource = "glass1"
}

object {
	id = "Glass2",
	resource = "glass2"
}

object {
	id = "Temple",
	resource = "temple"
}

object {
	id = "Page",
	resource = "page"
}

animation "Play"

hide {
	target = "Page"
}

move {
	target = "Temple",
	value = { { 0, 0 } }
}

move {
	target = "Haiku",
	value = { { 0, 200 }, { 650, 220 } },
	interpolation = "smooth",
	duration = 1.25
}

rotate {
	target = "Haiku",
	value = { 0, -12.56 },
	interpolation = "smooth",
	duration = 1.25
}

move {
	target = "Glass1",
	value = { { 0, 540 }, { 600, 80 } },
	interpolation = "smooth",
	duration = 1.5
}

move {
	target = "Glass2",
	value = { { 0, 0 }, { 580, 400 } },
	interpolation = "smooth",
	duration = 1.5
}

yield {
	duration = 1.5
}

fade {
	target = "Haiku",
	value = { 1, 0 },
	interpolation = "smooth",
	duration = 1.5
}

yield {
	duration = 2
}

show {
	target = "Page"
}

move {
	target = "Page",
	value = { { 960, 0 }, { -220, 0 } },
	interpolation = "smooth",
	duration = 0.5
}
