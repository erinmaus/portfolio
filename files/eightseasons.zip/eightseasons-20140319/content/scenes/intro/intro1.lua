resource {
	id = "titleText",
	type = "text",
	path = "content/fonts/normal.ttf",
	value = { 128, { 0, 0, 0 }, "Eight Seasons" }
}

resource {
	id = "haiku",
	type = "image",
	path = "content/scenes/intro/haiku.lg",
	value = "haiku"
}

resource {
	id = "orb",
	type = "image",
	path = "content/scenes/intro/orb.lg",
	value = "orb"
}

object {
	id = "TitleText",
	resource = "titleText",
	origin = { 370, 60 }
}

object {
	id = "Orb",
	resource = "orb"
}

object {
	id = "Haiku",
	resource = "haiku",
	origin = { 325, 255 }
}

animation "Play"

hide {
	target = "Haiku"
}

hide {
	target = "TitleText"
}

move {
	target = "Orb",
	value = { { 240, 190 } }
}

fade {
	target = "Orb",
	value = { 0, 1 },
	interpolation = "smooth",
	duration = 1.5
}

rotate {
	target = "Orb",
	value = { 0, 32 },
	interpolation = "linear",
	duration = 10
}

yield {
	duration = 1
}

show {
	target = "Haiku"
}

move {
	target = "Haiku",
	value = { { 0, 0 } }
}

fade {
	target = "Haiku",
	value = { 0, 1 },
	duration = 2
}

yield {
	duration = 3
}

fade {
	target = "Haiku",
	value = { 1, 0 },
	duration = 1
}

yield {
	duration = 1
}

scale {
	target = "Orb",
	value = { { 1, 1 }, { 4, 4 } },
	interpolation = "smooth",
	duration = 5
}

yield {
	duration = 4
}

fade {
	target = "Orb",
	value = { 1, 0 },
	interpolation = "smooth",
	duration = 0.25
}

show {
	target = "TitleText"
}

move {
	target = "TitleText",
	value = { { 100, 210 } }
}

fade {
	target = "TitleText",
	value = { 0, 1 },
	interpolation = "smooth",
	duration = 4
}

yield {
	duration = 5
}

fade {
	target = "TitleText",
	value = { 1, 0 },
	interpolation = "smooth",
	duration = 4
}
