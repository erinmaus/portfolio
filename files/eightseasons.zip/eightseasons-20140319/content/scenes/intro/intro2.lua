resource {
	id = "image",
	type = "image",
	path = "content/scenes/intro/image2.lg",
	value = "image"
}

resource {
	id = "slash",
	type = "image",
	path = "content/scenes/intro/slash.lg",
	value = "slash"
}

object {
	id = "Image",
	resource = "image"
}

object {
	id = "Slash",
	resource = "slash"
}

animation "Play"

hide {
	target = "Slash"
}

fade {
	target = "Image",
	value = { 0, 1 },
	interpolation = "smooth",
	duration = 1
}

move {
	target = "Image",
	value = { { 230, 0 } }
}

yield {
	duration = 2
}

hide {
	target = "Image"
}

show {
	target = "Slash"
}

move {
	target = "Slash",
	value = { { 360, 150 } }
}

yield {
	duration = 0.125
}

fade {
	target = "Slash",
	value = { 1, 0 },
	interpolation = "smooth",
	duration = 0.5
}
