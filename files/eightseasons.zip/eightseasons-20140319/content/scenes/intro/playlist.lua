local p =
{
	{ "scene", "content/scenes/common/page.scene" },
	{ "scene", "content/scenes/intro/intro1.lua" },
	{ "dialogue", "content/conversations/intro/conversation1.lua" },
	{ "scene", "content/scenes/common/page.scene" },
	{ "scene", "content/scenes/intro/intro2.lua" },
	{ "dialogue", "content/conversations/intro/conversation2.lua" },
	{ "scene", "content/scenes/common/page.scene" },
	{ "scene", "content/scenes/intro/intro3.lua" },
	{ "dialogue", "content/conversations/intro/conversation3.lua" }
}

return p
