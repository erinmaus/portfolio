resource {
	id = "image",
	type = "image",
	path = "content/scenes/intro/image3.lg",
	value = "image"
}

object {
	id = "Image",
	resource = "image"
}

animation "Play"


fade {
	target = "Image",
	value = { 0, 1 },
	interpolation = "smooth",
	duration = 1
}

move {
	target = "Image",
	value = { { 400, 100 } }
}

yield {
	duration = 2
}

fade {
	target = "Image",
	value = { 1, 0 },
	interpolation = "smooth",
	duration = 1
}
