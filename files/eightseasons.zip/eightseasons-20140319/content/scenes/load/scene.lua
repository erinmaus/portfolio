resource {
	id = "loadingText",
	type = "text",
	path = "content/fonts/normal.ttf",
	value = { 42, { 0, 0, 0 }, "Loading. . ." }
}

resource {
	id = "circle",
	type = "image",
	path = "content/scenes/load/graphics.lg",
	value = "circle"
}

object {
	id = "Circle",
	resource = "circle",
	origin = { 185, 175 }
}

object {
	id = "LoadingText",
	resource = "loadingText",
	origin = { 95, 20 }
}

animation "Loading"

move {
	target = "Circle",
	value = { { 295, 95 } }
}

move {
	target = "LoadingText",
	value = { { 385, 250 } }
}

rotate {
	target = "Circle",
	value = { 0, 6.14 },
	interpolation = "linear",
	duration = 2
}

yield {
	duration = 2
}

animation "Done"

move {
	target = "Circle",
	value = { { 295, 95 } }
}

move {
	target = "LoadingText",
	value = { { 385, 250 } }
}

fade {
	target = "Circle",
	value = { 1, 0 },
	interpolation = "smooth",
	duration = 0.5
}

fade {
	target = "LoadingText",
	value = { 1, 0 },
	interpolation = "smooth",
	duration = 0.5
}