self = {}
state = {}

local function CanMove()
	return not parent.game.IsHudVisible()
end

local function FinishRestraint()
	if self.targetCallback then
		self.targetCallback()
	end
	
	self.target = nil
	self.targetCallback = nil
end

local function Move(delta)
	if (parent.input.current.mouse.buttons[1] or self.target) and CanMove() then
		local newX
		local isMoving = false
		
		if self.target then
			if self.ignoreTarget then
				if self.currentAnimation ~= "idle" then
					self.currentAnimation = "idle"
					self.animations.idle.animation:Reset()
				end
				
				return
			end
			
			newX = self.target - state.position.x
		else
			newX = parent.input.current.mouse.axes.x - Screen.Width / 2
		end
		
		if newX < 0 then
			state.position.x = state.position.x - state.speed * delta
			state.currentDirection = "left"
			
			if self.target and Math.Abs(self.target - state.position.x) < state.speed * delta then
				isMoving = false
				FinishRestraint()
			else
				isMoving = true
			end
		else
			state.position.x = state.position.x + state.speed * delta
			state.currentDirection = "right"
			
			if self.target and Math.Abs(self.target - state.position.x) < state.speed * delta then
				isMoving = false
				FinishRestraint()
			else
				isMoving = true
			end
		end
		
		if isMoving then
			if self.currentAnimation ~= "run" then
				self.currentAnimation = "run"
				self.animations.run.animation:Reset()
			end
		else
			if self.currentAnimation ~= "idle" then
				self.currentAnimation = "idle"
				self.animations.idle.animation:Reset()
			end
		end
	else
		if self.currentAnimation ~= "idle" then
			self.currentAnimation = "idle"
			self.animations.idle.animation:Reset()
		end
	end
end

function Update(delta)
	Move(delta)
	
	self.animations[self.currentAnimation].animation:Update(delta)
	
	state.position.x = Math.Clamp(state.position.x, 0, parent.layers[parent.activeLayer].size.x)
	state.position.y = parent.geometry:GetElevation(state.position.x, true)
	
	parent.camera.target.x = state.position.x
	parent.camera.target.y = state.position.y + 200
	
	if self.snapCamera then
		parent.camera:Snap()
		
		self.snapCamera = false
	end
	
	self.ignoreTarget = false
end

function Draw(matrix)
	local multiplier = 1
	
	if state.currentDirection == "left" then
		multiplier = -1
	end
	
	Graphics.SetView(matrix * 
		Matrix.Translate(state.position.x, state.position.y, 0) *
		Matrix.Scale(0.5 * multiplier, 0.5, 1))
	
	LG.Draw(self.animations[self.currentAnimation].image, self.currentAnimation, self.animations[self.currentAnimation].animation.currentFrame)
end

function Destroy()
	LG.Destroy(self.animations.idle.image)
	LG.Destroy(self.animations.run.image)
end

function Restrain(target, callback)
	self.ignoreTarget = true
	self.target = target
	self.targetCallback = callback
end

local function Create(arg)
	state.position = Vector2.Create(arg.spawn.x, arg.spawn.y)
	state.currentDirection = arg.spawn.direction
	state.speed = 480
	
	self.animations = {}
	
	self.animations.idle = {}
	self.animations.idle.image = LG.Compile(parent.resources.Load["LG"]("content/stages/player/idle.lg"))
	self.animations.idle.animation = Animation.Frame.Create(self.animations.idle.image, "idle")
	
	self.animations.run = {}
	self.animations.run.image = LG.Compile(parent.resources.Load["LG"]("content/stages/player/run.lg"))
	self.animations.run.animation = Animation.Frame.Create(self.animations.run.image, "run", 0.1)
	
	self.currentAnimation = "idle"
	
	self.snapCamera = true
	
	if arg.spawn.zoom then
		parent.camera.targetZoom = arg.spawn.zoom
	end
end

Create(...)
