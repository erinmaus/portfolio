self = {}

local function LoadStage()
	parent.game.LoadStage(self.stage, self.entrance)
end

local function OnLoad(player, collision)
	if collision and 
		(parent.keys.action:CheckAgainst(parent.input.previous) == false
		and parent.keys.action:CheckAgainst(parent.input.current) == true)
	then
		if self.key == nil or parent.game.HasInventoryItem(self.key) then
			parent.game.PlayScene("content/scenes/common/page.scene", true, LoadStage)
		else
			parent.game.Converse(self.message)
		end
	end
end

local function Create(data)
	self.stage = data.stage
	self.entrance = data.entrance
	self.position = data.position
	self.width = data.width
	self.key = data.key
	self.message = data.message
	
	parent.geometry:CreateEvent(self.position, self.width, OnLoad)
end

Create(...)
