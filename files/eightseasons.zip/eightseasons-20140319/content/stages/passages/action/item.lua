self = {}

local function GiveItem(player, collision)
	if collision and 
		(parent.keys.action:CheckAgainst(parent.input.previous) == false
		and parent.keys.action:CheckAgainst(parent.input.current) == true)
	then
		if not parent.game.HasInventoryItem(self.item) then
			parent.game.GiveInventoryItem(self.item)
			
			if self.callback then
				self.callback(parent.game)
			end
		end
	end
end

local function Create(data)
	self.item = data.item
	self.position = data.position
	self.width = data.width
	self.callback = data.callback
	
	parent.geometry:CreateEvent(self.position, self.width, GiveItem)
end

Create(...)
