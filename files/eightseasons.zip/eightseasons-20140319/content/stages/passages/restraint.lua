self = {}

local function RestrainPlayer(player, collision)
	if collision and not self.isActive then
		local c = true
		
		if self.callback then
			c = self.callback(parent.game)
		end
		
		if c then
			player.Restrain(self.target, function()
				self.isActive = false
			end)
			
			self.isActive = true
			
			if self.conversation then
				parent.game.Converse(self.conversation)
			end
		end
	end
end

local function Create(data)
	self.position = data.position
	self.width = data.width
	self.callback = data.callback
	self.conversation = data.conversation
	self.target = data.target
	
	parent.geometry:CreateEvent(self.position, self.width, RestrainPlayer)
end

Create(...)
