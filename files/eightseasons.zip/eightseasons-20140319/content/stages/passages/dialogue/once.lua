self = {}

local function OnConverse(player, collision)
	if collision and not parent.state[self.key] then
		parent.state[self.key] = true
		parent.game.Converse(self.conversation)
	end
end

local function Create(data)
	self.position = data.position
	self.width = data.width
	self.key = data.key
	self.conversation = data.conversation
	
	parent.geometry:CreateEvent(self.position, self.width, OnConverse)
end

Create(...)
