self = {}

local function Battle(player, collision)
	if collision and not parent.state[self.key] and self.active then
		parent.game.Battle(self.enemy, function(win)
			parent.state[self.key], self.active = self.postCallback(parent.game, parent.state, win)

			if self.push and not parent.state[self.key] then
				player.Restrain(self.push, function()
					self.active = true
				end)
			end
		end, function(win)
			self.preCallback(parent.game, parent.state)
		end)
	end
end

local function Create(data)
	self.position = data.position
	self.width = data.width
	self.key = data.key
	self.enemy = data.enemy
	self.preCallback = data.preCallback
	self.postCallback = data.postCallback
	self.active = true
	self.push = data.push
	
	parent.geometry:CreateEvent(self.position, self.width, Battle)
end

Create(...)
