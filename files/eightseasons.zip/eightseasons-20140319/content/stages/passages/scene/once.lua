self = {}

local function PlayScene(player, collision)
	local active

	if rawtype(self.key) == "function" then
		active = not self.key(parent.game, parent.state)
	else
		active = parent.state[self.key]
	end

	if collision and not active then
		if self.preCallback then
			self.preCallback(parent.game, parent.state)
		end
		
		parent.game.PlayScene(self.scene, self.showStage, function()
			if self.postCallback then
				self.postCallback(parent.game, parent.state)
			end
		end)
	end
end

local function Create(data)
	self.position = data.position
	self.width = data.width
	self.key = data.key
	self.scene = data.scene
	self.showStage = data.showStage
	self.preCallback = data.preCallback
	self.postCallback = data.postCallback
	
	parent.geometry:CreateEvent(self.position, self.width, PlayScene)
end

Create(...)
