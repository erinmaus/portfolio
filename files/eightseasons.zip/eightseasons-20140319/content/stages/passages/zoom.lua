self = {}

local function OnZoom(player, collision)
	if collision then
		parent.camera.targetZoom = self.zoom
	end
end

local function Create(data)
	self.zoom = data.zoom
	self.position = data.position
	self.width = data.width
	
	parent.geometry:CreateEvent(self.position, self.width, OnZoom)
end

Create(...)
