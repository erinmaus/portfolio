self = {}

local function LoadStage()
	parent.game.LoadStage(self.stage, self.entrance)
end

local function OnLoad(player, collision)
	if collision then
		parent.game.PlayScene("content/scenes/common/page.scene", true, LoadStage)
	end
end

local function Create(data)
	self.stage = data.stage
	self.entrance = data.entrance
	self.position = data.position
	self.width = data.width
	
	parent.geometry:CreateEvent(self.position, self.width, OnLoad)
end

Create(...)
