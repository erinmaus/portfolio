self = {}

function Update(delta)
	if not parent.game.audio:IsSongPlaying(self.track) then
		parent.game.audio:PlaySong(self.track)
	end
end

local function Create(data)
	self.track = data.track
end

Create(...)
