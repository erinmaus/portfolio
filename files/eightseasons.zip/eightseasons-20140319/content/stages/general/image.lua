self = {}

function Update(delta)
	if self.update then
		self.update(_G, delta)
	end
end

function Draw(matrix, viewBounds)
	local position = self.position + self.offset
	local m = Matrix.Translate(position.x, position.y, 0) * Matrix.Rotate(self.rotation or 0)

	Graphics.SetView(matrix * m)
	
	local imageBounds = LG.Bounds(self.image, self.group, self.frame).rectangle
	local localBounds = {}
	
	localBounds.left = imageBounds.left + position.x
	localBounds.right = imageBounds.right + position.x
	localBounds.top = imageBounds.top + position.y
	localBounds.bottom = imageBounds.bottom + position.y
	
	if MathUtil.Primitives.Bounds(localBounds, viewBounds) or self.static then
		if self.callback == nil or self.callback(parent.game, parent.state) then
			LG.Draw(self.image, self.group, self.frame)
		end
	end
end

function Destroy()
	LG.Destroy(self.image)
end

local function Create(data)
	self.position = Vector2.Create(data.x or 0, data.y or 0)
	self.imageSource = data.imageSource
	
	self.image = LG.Compile(parent.resources.Load["LG"](data.imageSource),
		settings().quality)
	self.group = data.image or "prop"
	self.frame = data.frame or 1
	self.static = data.static or false

	self.offset = Vector2.Create(0, 0)
	self.rotation = 0

	if data.update then
		local s = sandbox()
		local success, ret = load(s, data.update)

		if not success then
			error(ret)
		end

		self.update = s.Update
	end
	
	self.callback = data.callback
end

Create(...)
