local t = 0

function Update(obj, delta)
	obj.self.rotation = obj.self.rotation + Math.Pi * 2 * delta

	t = t + delta
	obj.self.offset = Vector2.Create(0, Math.Sin(t) * 20)
end
