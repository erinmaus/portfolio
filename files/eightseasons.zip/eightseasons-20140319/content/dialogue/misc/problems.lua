local d =
{
	["en"] =
	{
		name = "Door",
		
		["noItems"] =
		{
			{
				"",
				"(I have nothing with me.)",
			}
		}
	}
}

return d
