local d =
{
	["en"] =
	{
		name = "Door",
		
		["locked"] =
		{
			{
				"",
				"(The door is locked.)",
			}
		}
	}
}

return d
