local d =
{
	["en"] =
	{
		name = "Haiku",
		
		["introduction1"] =
		{
			{
				"",
				"The past solstice came with a troubling Sight",
				"That pit my tribe, and the world, against me--",
				"Haiku--known before as 'She who is wise,'",
				"Now I am to be known by the horrific title,",
				"'Thrall who stops the passing of the seasons.'"
			},

			{
				"",
				"The Sight, as it were, cried out my mistakes",
				"Of which I undoubtedly have many--",
				"But such is life? For to err is human",
				"(To err is to live, to err is to think)."
			},

			{
				" ",
				"I will not shed memory of that day,",
				"When I had been awoken by the toll",
				"Of that horrible bell up on the Loft",
				"That rang only when catastrophe struck."
			},
		},
		
		["introduction2"] =
		{
			{
				" ",
				"The bitter, yet respected, 'He who prays'--",
				"Our only tribal scribe--had been murdered",
				"By an unimaginable enemy,",
				"One who seldom interferes with humans,",
				"'It which strikes with thorns,' and his renown sword.",
				"The accomplished assassin disturbed nothing,",
				"Leaving the Sight untouched--and unfinished."
			},

			{
				"",
				"I was treated as if I were guilty,",
				"To stand before my tribe, by the council,",
				"Is punishment for broken tradition--",
				"I had broken no tradition (by law),",
				"Yet, I was forced to read the Sight aloud",
				"Before all of my friends and family.",
				"Thus I read the Sight, as it was written:",
			},

			{
				"",
				"\"Haiku's mistakes will be the end of our tribe!",
				"If she is to pass the seasons once more",
				"Winter will perish, Spring will dance no more;",
				"Summer shall whither to Autumn's embrace,",
				"Which will weaken until the coming end!",
				"Haiku is but an ancient spirit's thrall",
				"I see it now--the spirit's thousand schemes",
				"Will be revealed in her dreams come dawn.\"",
			},

			{
				"",
				"Then Councilman 'He who runs' spoke his words:",
				"\"You are a disgrace to us proud people.",
				"I should have listened to Sijin's advice:",
				"'To give Haiku that crucial privilege--",
				"overseer of the season cycle--",
				"Is such folly, for she will destroy us;",
				"Look no further than her constant nightmares!",
				"Give another this privilege--not her!'\"",
			},

			{
				"",
				"'He who runs' continued after a pause.",
				"\"I was a fool. I will bear that burden.",
				"But you, Haiku? You shall now be known as",
				"'Thrall who stops the passing of the seasons.'",
				"Your legacy will be ruination--\"",
			}
		},
		
		["introduction3"] =
		{
			{
				"",
				"I then spoke, interrupting his judgment:",
				"\"Sijin was a fool; 'He who prays' likewise!",
				"I will pass the seasons successfully",
				"As I have done cycle after cycle.",
				"In my last dreams, I saw prosperity",
				"After hardships--the Sight is mistaken!\"",
			},

			{
				"",
				"The shock of my choice words was felt throughout.",
				"Never had I spoken out of order. . .",
				"But before, I had never needed to.",
				"'He who runs' continued when peace returned:",
			},

			{
				"",
				"\"'Thrall,' your dreams. . . They are no longer important.",
				"Yes, we all know, you must pass the seasons;",
				"But, you will do so without aid from us!",
				"The passing is your task. We will prepare",
				"For the end of cycles; for it is near.",
				"Make peace--for you are now a simple guest",
				"In the settlement of the Winter Tribe.\"",
			},

			{
				"",
				"My heart fell further at his utterance.",
				"At first I felt like an unwelcome ghost,",
				"But ghosts do not feel the rage I possessed.",
				"Outside, the calm snow became a blizzard.",
				"When my rage reached its peak, a great gale",
				"Shook the very constructs of our village.",
				"And this is the end of my remembrance.",
			},

			{
				"",
				"I awoke some days later as a ward",
				"Of the council--under their constant watch,",
				"I could go nowhere until the passing.",
				"They restrained me from pursuing the Word",
				"For in my words there is a great power.",
			},

			{
				"",
				"Every day passed blurred--I mostly slept.",
				"For in my sleep I am free--unlike them.",
				"Soon arrived the dawn of that special day",
				"Where I would guide her, the Winter Spirit,",
				"And prove my people were so very wrong.",
			}
		},
		
		["tutorial1"] =
		{
			{
				"angry",
				"Winter is not here--her presence is absent!",
				"Evil is working against me right now. . .",
			},
			
			{
				"sad",
				". . .Nonsense! The cold must be numbing my heart.",
				"There is little time; I must descend now",
				"Upon the ceremony site by the river below."
			}
		},
		
		["tutorial2"] =
		{
			{
				"angry",
				"Gatekeeper. . .? Why would he desert his post?",
				"This is not right; the door must be unlocked",
				"By his hand with his key!--but where is he?"
			}
		},
		
		["tutorial3"] =
		{
			{
				"sad",
				"No, no! The gatekeeper has been murdered!",
				"Who--what--no. . . the frog spirit assassin",
				"Must be here--it bears marks of his technique!",
			},
			
			{
				"angry",
				"This shall end. . . now! He will pay for his sins!"
			},
		},
		
		["tutorial4"] =
		{
			{
				"angry",
				"There you stand, smirk upon your vile mask!",
				"What kind of evil must you be to think",
				"That the gatekeeper child was a threat. . .?",
				"This ends now--",
			}
		},
		
		["tutorial5"] =
		{
			{
				"angry",
				"My purpose is to ensure the passing!",
				"In your physical form, you are mortal,",
				"And so painfully shall you meet your end."
			}
		},
		
		["tutorial6"] =
		{
			{
				"sad",
				"The gatekeeper--I must attend to him",
				"Before I seek out the frog assassin,",
				"Lest his soul become a vengeful phantom."
			}
		},
		
		["tutorial7"] =
		{
			{
				"",
				"My legacy. . . shall be my salvation.",
				"The evil that works against the balance",
				"Of all things, shall know me by my title,",
				"'She who is wise,' and fear its power.",
				"For the power drawn from the sacred Word,",
				"'Tetragrammaton,' ensures my freedom",
				"And will lay ruin to those who defy It.",
				"My heart shall show them no mercy! Amen."
			}
		}
	}
}

return d
