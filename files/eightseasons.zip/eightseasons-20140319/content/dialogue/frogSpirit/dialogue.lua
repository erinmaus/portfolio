local d =
{
	["en"] =
	{
		name = "Frog Spirit",
		
		["tutorial1"] =
		{
			{
				"neutral",
				"Pardon, my dear friend, but that is not true.",
				"The end? No, not yet. My master agrees",
				"That this is just the start of a new dawn.",
				"Listen, friend, to the silence around us.",
				"Do you hear it? The warning is simple:",
				"You, my dear friend, please do not interfere."
			}
		},
		
		["tutorial2"] =
		{
			{
				"neutral",
				"My friend, that is not a proper greeting!",
				"Have your way, Haiku. You will regret it."
			}
		},
		
		["tutorial3HaikuWon"] =
		{
			{
				"neutral",
				"Mortal or not, you cannot kill me, friend.",
				"Come any closer and face your end."
			}
		},
		
		["tutorial3HaikuLost"] =
		{
			{
				"neutral",
				"I told you, friend, that you would regret it.",
				"Now please leave me be. I prefer silence."
			}
		}
	}
}

return d
