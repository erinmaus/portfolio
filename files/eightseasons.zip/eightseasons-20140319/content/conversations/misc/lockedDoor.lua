local c =
{
	{ nil, "content/dialogue/misc/door.lua", "locked" },
}

return c
