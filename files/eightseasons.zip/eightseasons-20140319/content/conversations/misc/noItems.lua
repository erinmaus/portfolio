local c =
{
	{ nil, "content/dialogue/misc/problems.lua", "noItems" },
}

return c
