local c =
{
	{ "content/dialogue/haiku/face.lg", "content/dialogue/haiku/dialogue.lua", "tutorial3" }
}

return c
