local c =
{
	{ "content/dialogue/frogSpirit/face.lg", "content/dialogue/frogSpirit/dialogue.lua", "tutorial3HaikuWon" }
}

return c
