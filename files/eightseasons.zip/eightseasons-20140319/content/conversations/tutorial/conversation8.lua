local c =
{
	{ nil, "content/dialogue/haiku/dialogue.lua", "tutorial7" }
}

return c
