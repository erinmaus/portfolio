local c =
{
	{ "content/dialogue/haiku/face.lg", "content/dialogue/haiku/dialogue.lua", "tutorial4" },
	{ "content/dialogue/frogSpirit/face.lg", "content/dialogue/frogSpirit/dialogue.lua", "tutorial1" },
	{ "content/dialogue/haiku/face.lg", "content/dialogue/haiku/dialogue.lua", "tutorial5" },
	{ "content/dialogue/frogSpirit/face.lg", "content/dialogue/frogSpirit/dialogue.lua", "tutorial2" }
}

return c
