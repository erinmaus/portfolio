local c =
{
	{ "content/dialogue/haiku/face.lg", "content/dialogue/haiku/dialogue.lua", "tutorial2" }
}

return c
