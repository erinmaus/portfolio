local c =
{
	{ nil, "content/dialogue/haiku/dialogue.lua", "introduction2" }
}

return c
