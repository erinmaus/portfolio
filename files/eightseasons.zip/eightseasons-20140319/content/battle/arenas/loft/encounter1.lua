local arena =
{
	name = "Loft Temple",
	size = { x = 6, y = 4 },
	
	obstacles =
	{
		{
			name = "altar",
			position = { x = 2, y = 1 },
			size = { width = 4, height = 2 },
			image = "content/battles/arenas/loft/altar.scene"
		}
	},
	
	combatants =
	{
		{
			position = { x = 3, y = 2 },
			direction = "right",
			team = "good"
		},
		
		{
			path = "content/battle/enemies/frogSpirit.lua",
			position = { x = 6, y = 3 },
			direction = "left",
			team = "evil"
		}
	}
}

return arena
