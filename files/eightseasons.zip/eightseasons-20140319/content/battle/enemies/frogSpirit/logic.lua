Enemy("Thornwood Frog Spirit",
{
	image = "content/battle/enemies/frogSpirit/image.lg",
	scene = "content/battle/enemies/frogSpirit/scene.lua",
	stats =
	{
		health = 800,
		accuracy = 50,
		evasion = 30,
		attack = 50,
		defense = 10,
		speed = 50,
		dexterity = 6
	}
})

local Backstab = Attack("Backstab")
Backstab.preHit = function(self, target, stats)
	stats.power = 8
	stats.baseDamage = 200
	stats.target.evasion = 0
end
Backstab.onHit = function(self, target, stats)
	if target.isPlayer and Roll(25) then
		BlockChannel(target, "random")
	end
end

local Embrace = Enchantment("Embrace")
Embrace.onUse = function(self, target, stats)
	Enchant(self, "attack", 2)
	Enchant(self, "defense", 0.5)
end

local NeedleStrike = Attack("Needle Strike")
NeedleStrike.preHit = function(self, target, stats)
	stats.power = 8
	stats.baseDamage = 50
end

local function PerformMovement(self)	
	local path = Path(self, self.target, "front")

	if path.isValid then
		Move(path, "Run")
	end
end

local function PerformBackstab(self)
	local teleport = Teleport(self, self.target, "behind")
	
	if teleport.isValid then
		Message("%s teleported behind %s!", self.name, target.name)
		PerformAction(self, nil, teleport.action, "Teleport")
		
		Message("%s stabbed %s in the back!", self.name, target.name)
		PerformAction(self, self.target, Backstab.action, "Attack")
	else
		if Roll(75) then
			PerformMovement(self)
		else
			Message("%s embraces pain!")
			PerformAction(self, nil, Embrace.action, "Attack")
		end
	end
end

function Think(self)
	if self.target == nil then
		self.target = Target("Hakut")
	end
	
	if Distance(self, self.target) > self.stats.dexterity or Roll(12.5) then
		PerformBackstab(self)
	else
		local ray = Ray(self, self.target)
		
		if ray.isVisible and ray.distance < self.stats.dexterity then
			Message("%s throws a dart!", self.name)
			PerformAction(self, self.target, NeedleStrike.action, "Attack")
		else
			PerformMovement(self)
		end
	end
	
	FinishTurn(self, "Idle")
end

function OnHit(self, miss)
	if miss then
		PerformAction(self, nil, nil, "Parry")
	else
		PerformAction(self, nil, nil, "Hit")
	end
end
