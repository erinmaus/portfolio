local image = Resource("Image", "content/battle/enemies/frogSpirit/image.lg")
local teleportFog = Resource("Image", "content/battle/enemies/frogSpirit/teleportFog.lg")
local character = Character("Thornwood Frog Spirit")

local animation = character:Animation("Attack")
animation:Begin()