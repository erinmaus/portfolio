local e =
{
	image = "content/battle/enemies/frogSpirit.lg",
	scene = "content/battle/enemies/frogSpirit.scene",
	logic = "content/battle/enemies/frogSpirit.logic",
	name = "Frog Spirit",

	music =
	{
		filename = "content/battle/music/frogSpirit.ogg",
		loopStart = 19.734,
		loopEnd = 124.939
	},
	
	stats =
	{
		health = 80000,
		accuracy = 1000,
		evasion = 200,
		attack = 500,
		defense = 100,
		speed = 2000
	},

	state =
	{
		wasHit = false,
		isIdle = false,
		isAttacking = false,
		toxicity = 0,
		maxToxicity = 2
	}
}

return e
