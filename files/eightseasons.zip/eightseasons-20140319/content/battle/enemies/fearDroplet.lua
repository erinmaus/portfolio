local e =
{
	image = "content/battle/enemies/fearDroplet.lg",
	scene = "content/battle/enemies/fearDroplet.scene",
	logic = "content/battle/enemies/fearDroplet.logic",
	name = "Fear Droplet",

	-- music =
	-- {
	-- 	filename = "content/battle/music/fearDroplet.ogg",
	-- 	loopStart = 19.734,
	-- 	loopEnd = 124.939
	-- },
	
	stats =
	{
		health = 10000,
		accuracy = 1000,
		evasion = 100,
		attack = 750,
		defense = 100,
		speed = 500
	},

	state =
	{
		seed = 132
	}
}

return e
