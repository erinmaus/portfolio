local item =
{
	image = "content/items/keys/gatekeeper/item.lg",
	name = "Gatekeeper's key",
	description = "Unlocks the path to the river below the Loft."
}

return item
