-- "Package" is a special table that defines the game's title, group, and 
-- version.
Package =
{
	application =
	{
		title = "Brightside",
		group = "Comma Excess",
		version = "alpha",
		conf = 2
	}
}

-- Emulates Lua 5.2
function loadin(t, string, name)
	local f, e = loadstring(string, name)
	
	if not f then
		return f, e
	end
	
	setfenv(f, t)
	
	return f
end

function Initialize(args)
	-- Initialize file system
	File.Initialize(Package.application.title, Package.application.group)
	
	-- Find archives in the root directory and include them.
	local files = File.GetFiles("/")
	for i = 1, #files do
		local index = files[i]:find("%.data$")
		
		if index and not File.IsDirectory(files[i]) then
			File.Include(files[i], "/")
			print(string.format("added '%s' to search path", files[i]))
		end
	end
	
	-- Load the configuration data
	if File.Exists("conf.lua") then
		local env = {}
		local rawConf = loadin(env, File.ReadAllData("conf.lua"),
			"conf.lua")
		local status, message = pcall(rawConf)
		
		if not status then
			print(message)
		else
			if env.conf.version == Package.application.conf then
				conf = env.conf
			end
		end
	end
	
	if conf == nil then
		local env = {}
		local rawConf = loadin(env, File.ReadAllData("core/conf.lua"),
			"core/conf.lua")
			
		rawConf()
		
		conf = env.conf
		conf.version = Package.application.conf
	end
	
	Main.CreateDisplay(conf.width, conf.height, conf.isFullscreen, conf.samples)
	
	if not File.Exists("core/allegro.lua") then
		error("core script not found: core/allegro.lua")
	else
		local allegro = loadstring(File.ReadAllData("core/allegro.lua"), "allegro")
		
		allegro()
	end
	
	-- Check for the main script
	if not File.Exists("core/main.lua") then
		error("core script not found: core/main.lua")
	else
		local main, err = loadstring(File.ReadAllData("core/main.lua"), "main")
		
		if main == nil then
			error(err)
		end
		
		main()
	end
end

function Update(fps, t)
	if Brightside.Update then
		return Brightside.Update(fps, t)
	end
	
	return false, false
end

function Draw()
	if Brightside.Draw then
		return Brightside.Draw()
	end
end

function Close()
	if Brightside.Close then
		Brightside.Close()
	end
end

function JoystickAxisChanged(e)
	if Brightside.Joystick and Brightside.Joystick.Axis then
		Brightside.Joystick.Axis(e)
	end
end

function JoystickButtonDown(e)
	if Brightside.Joystick and Brightside.Joystick.ButtonDown then
		Brightside.Joystick.ButtonDown(e)
	end
end

function JoystickButtonUp(e)
	if Brightside.Joystick and Brightside.Joystick.ButtonUp then
		Brightside.Joystick.ButtonUp(e)
	end
end

function KeyDown(e)
	if Brightside.Keyboard and Brightside.Keyboard.KeyDown then
		Brightside.Keyboard.KeyDown(e)
	end
end

function KeyUp(e)
	if Brightside.Keyboard and Brightside.Keyboard.KeyUp then
		Brightside.Keyboard.KeyUp(e)
	end
end

function KeyPressed(e)
	if Brightside.Keyboard and Brightside.Keyboard.KeyPress then
		Brightside.Keyboard.KeyPress(e)
	end
end

function MouseMoved(e)
	if Brightside.Mouse and Brightside.Mouse.Axis then
		Brightside.Mouse.Axis(e)
	end
end

function MouseButtonDown(e)
	if Brightside.Mouse and Brightside.Mouse.ButtonDown then
		Brightside.Mouse.ButtonDown(e)
	end
end

function MouseButtonUp(e)
	if Brightside.Mouse and Brightside.Mouse.ButtonUp then
		Brightside.Mouse.ButtonUp(e)
	end
end

function SwitchedIn(e)
	if Brightside.Display and Brightside.Display.In then
		Brightside.Display.In(e)
	end
end

function SwitchedOut(e)
	if Brightside.Display and Brightside.Display.Out then
		Brightside.Display.Out(e)
	end
end
