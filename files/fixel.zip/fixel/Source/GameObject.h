#ifndef F_GAMEOBJECT_H_
#define F_GAMEOBJECT_H_

#include <string>
#include <map>

#include "FLua.h"
#include "Point.h"
#include "Rectangle.h"

class Bitmap;
class ISKill;
class Objector;

enum DrawOrder
{
	DrawFirst = 0,
	DrawLast,
	DrawNormal,
	DrawMax
};

class GameObject
{
	private:
		class Objector * objector;
		lua_State * luaState;
		std::string table;

		int uid; /* The unique identifier for this object. */
		std::string name; /* The name of the object. */

		Point location; /* The location of the game object in the world. */
		unsigned int width, height; /* The width and height of the object. */

		DrawOrder drawOrder; /* The order the object should be drawn. */
		int ySortValue; /* The sort value (unused at the moment...) */

		bool alwaysDraw; /* If the object should always be drawn, despite being out of view. */
		bool canMove; /* If the object can move or not. */
		bool isInvincible; /* If the object is invincible (chairs, etc). */
		bool isDead; /* If the object is dead. */
		bool isSolid; /* If the object is solid. */
		bool hasSpawned; /* If the object has spawned yet. */

		int team; /* The team this object is on. */
		int teamRank; /* The rank this object has. */

	public:
		/* This takes a table of arguments to be passed to the function.  The table of arguments
			should be absolute. Negative indicates no arguments. */
		GameObject(class Objector * o, lua_State * l, const std::string& f, int index);
		~GameObject(void);

		/* Synchronizes the object's state with the Lua version's. */
		void Synchronize(void);

		/* This is called by sending an event to the object.  A table with the event arguments
			should be at the provided index, which should be positive.  Negative indicates no
			arguments. */
		void OnEvent(const std::string& e, int index);

		/* This is called to update the game object. */
		void Update(void);

		/* This is called to draw the game object. */
		void Draw(class Bitmap& buffer, Rectangle& cam);

		/* Gets Objector. */
		class Objector * Get_Objector(void) const { return objector; }

		/* Gets the UID. */
		int Get_Uid(void) const { return uid; }

		/* Gets the name. */
		const std::string& Get_Name(void) const { return name; }

		/* Gets the location. */
		const Point& Get_Location(void) const { return location; }

		/* Gets the width/height. */
		int Get_Width(void) const { return width; }
		int Get_Height(void) const { return height; }

		/* Gets various booleans. */
		bool Get_AlwaysDraw(void) const { return alwaysDraw; }
		bool Get_CanMove(void) const { return canMove; }
		bool Get_IsInvincible(void) const { return isInvincible; }
		bool Get_IsDead(void) const { return isDead; }
		bool Get_IsSolid(void) const { return isSolid; }
		bool Get_HasSpawned(void) const { return hasSpawned; }

		/* Gets some team related stuff. */
		int Get_Team(void) const { return team; }
		int Get_TeamRank(void) const { return teamRank; }

		/* Operator. */
		bool operator <(const class GameObject& o);

		/* Extermination. */
		void Remove(void);
};

#endif
