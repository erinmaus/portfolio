#include <string>
#include <vector>

#include "Color.h"
#include "Exception.h"
#include "File.h"
#include "TileSheet.h"

TileSheet::TileSheet(const std::string& filename)
{
	File f(filename, FileModeRead, true);

	if (f.ReadInteger() != MagicNumber)
		throw Exception(filename + " is not a valid tile sheet.", "Wrong file?");

	int version = f.ReadInteger();

	if (version < Version)
		throw Exception(filename + " is an older tile sheet version.", "Wrong file?");
	else if (version > Version)
		throw Exception(filename + " is a newer tile sheet version.", "Wrong file?");

	int size = f.ReadInteger();

	for (int i = 0; i < size; i++)
	{
		Tile * t = new Tile();

		t->Border = f.ReadInteger();
		t->Inner = f.ReadInteger();
		t->Next = f.ReadInteger();
		t->Speed = f.ReadDouble();

		tiles.push_back(t);
	}
}

TileSheet::~TileSheet(void)
{
	while (tiles.size() > 0)
	{
		delete tiles.back();
		tiles.pop_back();
	}
}

void TileSheet::RemoveTileAt(int index)
{
	if (index >= tiles.size())
		throw Exception("Invalid index for a tile.", "Logic error?");

	delete tiles[index];
	tiles.erase(tiles.begin() + index);
}

void TileSheet::SaveToFile(const std::string& filename) const
{
	File f(filename, FileModeWrite, true);

	f.Write(MagicNumber);
	f.Write(Version);

	f.Write((int)tiles.size());

	for (std::vector<Tile *>::const_iterator i = tiles.begin(); i != tiles.end(); i++)
	{
		f.Write((int)(*i)->Border);
		f.Write((int)(*i)->Inner);
		f.Write((int)(*i)->Next);
		f.Write((*i)->Speed);
	}
}
