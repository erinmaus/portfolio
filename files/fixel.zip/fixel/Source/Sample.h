#ifndef F_SOUND_H_
#define F_SOUND_H_

#include <allegro.h>
#include <string>

enum SampleType
{
	SampleSquareWave = 0,
	SampleSineWave,
	SampleTriangleWave,
	SampleTypeMax
};

class Sample
{
	private:
		SAMPLE * sample;
		bool shared;

	public:
		Sample(SAMPLE * s, bool sh = true) : sample(s), shared(sh) { }
		Sample(const std::string& filename);
		~Sample(void) { if (!shared) destroy_sample(sample); }

		inline int Play(int volume, int pan, int freq, bool loop) const { return play_sample(sample, volume, pan, freq, loop); }
		inline void Stop(void) const { stop_sample(sample); }

		inline void Adjust(int volume, int pan, int freq, bool loop) const { adjust_sample(sample, volume, pan, freq, loop); }

		void SaveToFile(const std::string& filename);
};

#endif
