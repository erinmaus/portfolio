#ifndef F_RECTANGLE_H_
#define F_RECTANGLE_H_

struct Rectangle
{
	int X, Y; /* The x and y of the rectangle. */
	int Width, Height; /* The width and height of the rectangle. */

	/* Quick way to build a rectangle object. */
	Rectangle(const struct Rectangle& r) : X(r.X), Y(r.Y), Width(r.Width), Height(r.Height) { }
	Rectangle(int x, int y, int w, int h) : X(x), Y(y), Width(w), Height(h) { }
	Rectangle(void) : X(0), Y(0), Width(0), Height(0) { }

	/* Checks for a collision. */
	inline bool Collision(const struct Rectangle& r) { return !(X >= r.X + r.Width || r.X >= X + Width || Y >= r.Y + r.Height || r.Y >= Y + Height); }

	/* Checks to see if a rectangle is within another. */
	inline bool Inside(const struct Rectangle& r) { return (X >= r.X && X + Width <= r.X + r.Width && Y >= r.Y && Y + Height <= r.Y + r.Height); }

	/* Equals thing. */
	inline Rectangle& operator=(const Rectangle& r) { X = r.X; Y = r.Y; Width = r.Width; Height = r.Height; return *this; }
};

#endif
