#include <map>
#include <string>

#include "FLua.h"
#include "State.h"

namespace FLua
{
	namespace FSTable
	{
		int Index(lua_State * l)
		{
			STable * s = (STable *)FromLua(l, 1, false, "STable")->Data;
			std::string k = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, k.c_str());
			
			if (!lua_isnil(l, -1))
				return 1;

			try
			{
				s->Get_Object(k)->ToLua(l);
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			STable * s = (STable *)FromLua(l, 1, false, "STable")->Data;
			std::string key = luaL_checkstring(l, 2);

			try
			{
				s->ObjectFromLua(l, 3, key);
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		const luaL_Reg st[] =
		{
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ 0, 0 }
		};
	}

	namespace FState
	{
		int Create(lua_State * l)
		{
			State * s = new State;

			s->RegisterSerializer(new NumberSerializer, "Number");
			s->RegisterSerializer(new StringSerializer, "String");
			s->RegisterSerializer(new TableSerializer, "Table");
			s->RegisterSerializer(new BooleanSerializer, "Boolean");

			if (lua_type(l, 1) == LUA_TSTRING)
				s->LoadFromFile(luaL_checkstring(l, 1));

			ToLua(l, s, false, "State");

			return 1;
		}

		int IStateToLua(lua_State * l)
		{
			STable * s;

			if (IsType(l, 1, "STable") || IsType(l, 1, "State"))
			{
				LuaObject * o = (LuaObject *)lua_touserdata(l, 1);
				s = (STable *)o->Data;

				s->ToTable(l);

				return 1;
			}
			else
				luaL_error(l, "state expected");

			return 0;
		}

		const luaL_Reg stateLib[] =
		{
			{ "Create", &Create },
			{ "ToTable", &IStateToLua },
			{ 0, 0 }
		};

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "State");

			if (!(o->Shared))
				delete (State *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			State * s = (State *)FromLua(l, 1, false, "State")->Data;
			std::string k = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, k.c_str());
			
			if (!lua_isnil(l, -1))
				return 1;

			try
			{
				s->Get_Object(k)->ToLua(l);
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			State * s = (State *)FromLua(l, 1, false, "State")->Data;
			std::string key = luaL_checkstring(l, 2);

			try
			{
				s->ObjectFromLua(l, 3, key);
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		int SaveToFile(lua_State * l)
		{
			State * s = (State *)FromLua(l, 1, false, "State")->Data;
			std::string filename = luaL_checkstring(l, 2);

			try
			{
				s->SaveToFile(filename);
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		const luaL_Reg state[] =
		{
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "SaveToFile", &SaveToFile },
			{ 0, 0 }
		};
	}
}
