#include <map>
#include <string>

#include "Bitmap.h"
#include "Exception.h"
#include "FLua.h"
#include "Game.h"
#include "Input.h"
#include "ManagerList.h"
#include "Screen.h"
#include "Screeny.h"

namespace FLua
{
	namespace FScreen
	{
		class LScreen : public Screen
		{
			private:
				int reference;
				lua_State * l;
				std::string table;
				std::string name;

				/* This handy-dandy function gets the object's table and pushes it onto the stack. */
				inline bool GetTable(void)
				{
					lua_getglobal(l, table.c_str());

					if (lua_isnil(l, -1))
						throw Exception(table + " is nil.", "Logic error?");

					lua_rawgeti(l, -1, reference);

					if (lua_isnil(l, -1))
						throw Exception("Reference points to nothing.", "Logic error?");

					lua_getfield(l, -1, name.c_str());

					if (lua_isnil(l, -1))
						throw Exception(name + " is nil.", "Logic error?");

					return true;
				}

			public:
				LScreen(Screeny * s, lua_State * l, std::string t, std::string n, int r) : Screen(s), reference(r), l(l), table(t), name(n) { Set_IsPopup(false); }

				~LScreen(void)
				{
					if (reference != LUA_NOREF)
					{
						SaveStack(l);

						{
							SaveStack(l);

							if (GetTable())
							{
								lua_getfield(l, -1, "Destroy");

								if (!lua_isnil(l, -1))
								{
									lua_pushvalue(l, -2);

									if (lua_pcall(l, 1, 0, 0) != 0)
										throw Exception(lua_tostring(l, -1), "Syntax error?");
								}
							}

							RestoreStack(l);
						}

						lua_getglobal(l, table.c_str());

						luaL_unref(l, -1, reference);

						RestoreStack(l);
					}
				}

				/* Never call this inside Lua. */
				void Initialize(void)
				{
					SaveStack(l);

					if (reference != LUA_NOREF)
					{
						if (GetTable())
						{
							lua_getfield(l, -1, "Initialize");

							if (!lua_isnil(l, -1))
							{
								lua_pushvalue(l, -2);

								if (lua_pcall(l, 1, 0, 0) != 0)
									throw Exception(lua_tostring(l, -1), "Syntax error?");
							}
							else
								lua_pop(l, 1);

							lua_getfield(l, -1, "IsPopup");

							if (!lua_isnil(l, -1))
								Set_IsPopup(lua_toboolean(l, -1));
						}
					}

					RestoreStack(l);
				}

				/* Same goes for this one. */
				void Update(bool covered, bool inFocus)
				{
					SaveStack(l);

					if (reference != LUA_NOREF)
					{
						if (GetTable())
						{
							/* This stops screens from `accidentally' getting rid of their reference and the Remove `function'. */
							lua_pushinteger(l, reference);
							lua_setfield(l, -2, "Reference");
							
							ToLua(l, this, true, "Screen");
							lua_setfield(l, -2, "Remove");

							lua_getfield(l, -1, "Update");

							if (!lua_isnil(l, -1))
							{
								lua_pushvalue(l, -2);
								lua_pushboolean(l, covered);
								lua_pushboolean(l, inFocus);

								if (lua_pcall(l, 3, 0, 0) != 0)
									throw Exception(lua_tostring(l, -1), "Syntax error?");
							}
						}
					}

					RestoreStack(l);
				}

				/* And this one. */
				void HandleInput(Input& input)
				{
					SaveStack(l);

					if (reference != LUA_NOREF)
					{
						if (GetTable())
						{
							lua_getfield(l, -1, "HandleInput");

							if (!lua_isnil(l, -1))
							{
								lua_pushvalue(l, -2);
								ToLua(l, &input, true, "Input");

								if (lua_pcall(l, 2, 0, 0) != 0)
									throw Exception(lua_tostring(l, -1), "Syntax error?");
							}
						}
					}

					RestoreStack(l);
				}

				/* Especially this one. */
				void Draw(Bitmap& bitmap)
				{
					SaveStack(l);

					if (reference != LUA_NOREF)
					{
						if (GetTable())
						{
							lua_getfield(l, -1, "Draw");

							if (!lua_isnil(l, -1))
							{
								lua_pushvalue(l, -2);
								ToLua(l, &bitmap, true, "Bitmap");

								if (lua_pcall(l, 2, 0, 0) != 0)
									throw Exception(lua_tostring(l, -1), "Syntax error?");
							}
						}
					}

					RestoreStack(l);
				}

				void Remove(void)
				{
					Get_Screeny()->RemoveScreen(this);
				}
		};

		/* Userdata stuuuuuff. */
		int Call(lua_State * l)
		{
			LScreen * s = (LScreen *)FromLua(l, 1, false, "Screen")->Data;

			s->Remove();

			return 0;
		}

		const luaL_Reg screen[] =
		{
			{ "__call", &Call },
			{ 0, 0 }
		};
	}

	namespace FScreeny
	{
		/* Metatable functions.  Well, function, really... */
		int Index(lua_State * l)
		{
			Screeny * s = (Screeny *)FromLua(l, 1, false, "Screeny")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Total")
				lua_pushinteger(l, s->Get_Total());
			else
				luaL_error(l, "expected valid key");

			return 1;
		}

		/* Script functions. The reason `Get_Screen' is not scripted is because it is not needed and unsafe. */
		int Register(lua_State * l)
		{
			Screeny * s = (Screeny *)FromLua(l, 1, false, "Screeny")->Data;

			s->Register(luaL_checkstring(l, 2), luaL_checkstring(l, 3));

			return 0;
		}

		int Unregister(lua_State * l)
		{
			Screeny * s = (Screeny *)FromLua(l, 1, false, "Screeny")->Data;
			
			s->Unregister(luaL_checkstring(l, 2));

			return 0;
		}

		/* Adds a new screen. */
		int Add(lua_State * l)
		{
			Screeny * s = (Screeny *)FromLua(l, 1, false, "Screeny")->Data;
			int ref = DoFile(l, s->Get_RegisteredPath(luaL_checkstring(l, 2)));

			/* Now create the screen. */
			FScreen::LScreen * screen = new FScreen::LScreen(s, l, GlobalTable, GetTableNameFromFilename(s->Get_RegisteredPath(luaL_checkstring(l, 2))), ref);
			s->AddScreen(screen);

			return 0;
		}

		const luaL_Reg screeny[] =
		{
			{ "__index", &Index },
			{ "Register", &Register },
			{ "Unregister", &Unregister },
			{ "Add", &Add },
			{ 0, 0 }
		};
	}
}
