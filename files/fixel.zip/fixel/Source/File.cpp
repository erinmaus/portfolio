#include <allegro.h>
#include <cstdio>
#include <string>

#include "Exception.h"
#include "File.h"

namespace AFile
{
	int Close(void * f)
	{
		return fclose((FILE *)f);
	}

	int GetCharacter(void * f)
	{
		return fgetc((FILE *)f);
	}

	int UnGetCharacter(int c, void * f)
	{
		return ungetc(c, (FILE *)f);
	}

	long Read(void * p, long l, void * f)
	{
		return fread(p, l, 1, (FILE *)f);
	}

	int PutCharacter(int c, void * f)
	{
		return fputc(c, (FILE *)f);
	}

	long Write(const void * p, long l, void * f)
	{
		return fwrite(p, l, 1, (FILE *)f);
	}

	int Seek(void * f, int loc)
	{
		return fseek((FILE *)f, loc, SEEK_SET);
	}

	int EndOfFile(void * f)
	{
		return feof((FILE *)f);
	}

	int Error(void * f)
	{
		return ferror((FILE *)f);
	}

	static const PACKFILE_VTABLE vtable =
	{
		&Close, &GetCharacter, &UnGetCharacter, &Read, &PutCharacter, &Write, &Seek, &EndOfFile, &Error
	};
}

File::File(const std::string& filename, FileMode mode, bool binary, bool flushOnOutput, Endianness endianness)
	: mode(mode), binary(binary), endianness(endianness), flushOnOutput(flushOnOutput)
{
	std::string m; /* Mode. */

	if (mode & FileModeRead)
	{
		if (!binary)
		{
			if (mode & FileModeWrite && !(mode & FileModeCreate))
				m = "r+";
			else if (mode & FileModeWrite && mode & FileModeCreate)
				m = "w+";
			else if (mode & FileModeAppend)
				m = "a+";
			else
				m = "r";
		}
		else
		{
			if (mode & FileModeWrite && !(mode & FileModeCreate))
				m = "rb+";
			else if (mode & FileModeWrite && mode & FileModeCreate)
				m = "wb+";
			else if (mode & FileModeAppend)
				m = "ab+";
			else
				m = "rb";
		}
	}
	else if (mode & FileModeWrite)
	{
		if (!binary)
			m = "w";
		else
			m = "wb";
	}
	else if (mode & FileModeAppend)
	{
		if (!binary)
			m = "a";
		else
			m = "ab";
	}

	file = fopen(filename.c_str(), m.c_str());

	if (!file)
		throw Exception(filename + " couldn't be opened.", "Invalid permissions? Stuff like that?");

	pfile = pack_fopen_vtable(&AFile::vtable, file);

	if (!pfile)
		throw Exception(filename + " couldn't be converted to a packfile.", "Out of memory?");
}

File::~File(void)
{
	pack_fclose(pfile);
}

int File::Write(int i)
{
	int t;

	if (!binary)
		t = fprintf(file, "%d", i);
	else
	{
		if (endianness == BigEndian)
			t = pack_mputl(i, pfile);
		else
			t = pack_iputl(i, pfile);
	}

	if (flushOnOutput)
		fflush(file);

	return t;
}

int File::Write(float f)
{
	int t;

	if (!binary)
		t = fprintf(file, "%f", file);
	else
	{
		union
		{
			float f;
			long l;
		} u;

		u.f = f;

		if (endianness == BigEndian)
			t = pack_mputl(u.l, pfile);
		else
			t = pack_iputl(u.l, pfile);
	}

	if (flushOnOutput)
		fflush(file);

	return t;
}

int File::Write(double d)
{
	int t = 0;

	if (!binary)
		t = fprintf(file, "%lf", d);
	else
	{
		const int dToL = sizeof(double) / sizeof(long);
		union
		{
			double d;
			long l[dToL];
		} u;

		u.d = d;

		if (endianness == BigEndian)
			for (int i = 0; i < dToL; i++)
				t += pack_mputl(u.l[i], pfile);
		else
			for (int i = 0; i < dToL; i++)
				t += pack_iputl(u.l[i], pfile);
	}

	fflush(file);

	return t;
}

int File::Write(char c)
{
	int t;

	t = fputc(c, file);

	if (flushOnOutput)
		fflush(file);

	return t;
}

int File::Write(const std::string& s)
{
	int t;

	if (!binary)
		t = fprintf(file, "%s", s.c_str());
	else
	{
		t = Write((int)s.size());
		t += pack_fwrite(s.c_str(), sizeof(char) * s.size(), pfile);
	}

	return t;
}

int File::ReadInteger(void)
{
	int ret = 0;

	if (!binary)
	{
		if (fscanf(file, "%d", &ret) == EOF)
		{
			error = FileInvalidArgument;
			return -1;
		}
	}
	else
	{
		if (endianness == BigEndian)
			ret = pack_mgetl(pfile);
		else
			ret = pack_igetl(pfile);
	}

	return ret;
}

float File::ReadFloat(void)
{
	float ret = 0;

	if (!binary)
	{
		if (fscanf(file, "%f", &ret) == EOF)
		{
			error = FileInvalidArgument;
			return -1.0f;
		}
	}
	else
	{
		union
		{
			float f;
			long l;
		} u;

		if (endianness == BigEndian)
			u.l = pack_mgetl(pfile);
		else
			u.l = pack_igetl(pfile);

		ret = u.f;
	}

	return ret;
}

double File::ReadDouble(void)
{
	double ret;

	if (!binary)
	{
		if (fscanf(file, "%ld", &ret) == EOF)
		{
			error = FileInvalidArgument;
			return -1.0;
		}
	}
	else
	{
		const int dToL = sizeof(double) / sizeof(long);
		union
		{
			double d;
			long l[dToL];
		} u;

		if (endianness == BigEndian)
			for (int i = 0; i < dToL; i++)
				u.l[i] = pack_mgetl(pfile);
		else
			for (int i = 0; i < dToL; i++)
				u.l[i] = pack_igetl(pfile);

		ret = u.d;
	}

	return ret;
}

char File::ReadCharacter(void)
{
	char ret;

	if (!binary)
	{
		if (fscanf(file, "%c", &ret) == EOF)
		{
			error = FileInvalidArgument;
			return -1;
		}
	}
	else
		ret = fgetc(file);

	return ret;
}

std::string File::ReadString(bool readLine)
{
	std::string ret = "";

	if (!binary)
	{
		if (!readLine)
		{
			char c = 0;

			while ((c = fgetc(file)) != EOF)
				ret += c;
		}
		else
		{
			#ifdef ALLEGRO_WINDOWS

			const char endOfLine[] = { '\15' /* CR */, '\10' /* LF */, '\0' };

			#elif defined ALLEGRO_MACOSX

			const char endOfLine[] = { '\13', '\0' };

			#else /* Unix. */

			const char endOfLine[] = { '\10', '\0' };

			#endif

			while (ret.find(endOfLine) != std::string::npos)
				ret += fgetc(file);
		}
	}
	else
	{
		unsigned int size = ReadInteger();

		if (size < 1)
		{
			error = FileInvalidArgument;
			return ret;
		}
		
		for (unsigned int i = 0; i < size && !Get_IsEndOfFile(); i++)
			ret += fgetc(file);
	}

	return ret;
}
