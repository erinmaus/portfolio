#include <allegro.h>
#include <string>

#include "Exception.h"
#include "File.h"
#include "Sample.h"

Sample::Sample(const std::string& filename)
	: shared(false)
{
	sample = load_sample(filename.c_str());

	if (!sample)
		throw Exception(filename + " couldn't be opened!", "Missingno??");
}

/* Thanks to Spellcaster's code: http://www.allegro.cc/forums/thread/428824/429571#target */
void Sample::SaveToFile(const std::string& filename)
{
	File f(filename, FileModeWrite, true);
	int bps = sample->bits / 8 * (sample->stereo ? 2 : 1);
	int length = sample->len * bps;

	f.Write('R');
	f.Write('I');
	f.Write('F');
	f.Write('F');

	f.Write(36 + length);

	f.Write('W');
	f.Write('A');
	f.Write('V');
	f.Write('E');

	f.Write('f');
	f.Write('m');
	f.Write('t');
	f.Write(' ');

	f.Write(16);
	pack_iputw(1, f.Get_PackFile());
	pack_iputw(sample->stereo ? 2 : 1, f.Get_PackFile());
	f.Write(sample->freq);
	f.Write(sample->freq * bps);
	pack_iputw(bps, f.Get_PackFile());
	pack_iputw(sample->bits, f.Get_PackFile());

	f.Write('d');
	f.Write('a');
	f.Write('t');
	f.Write('a');

	f.Write(length);

	if (sample->bits == 8)
	{
		for (int i = 0; i < length; i++)
			f.Write(((char *)sample->data)[i]);
	}
	else
	{
		for (int i = 0; i < length * (sample->stereo ? 2 : 1); i++)
			pack_iputw(((signed short *)sample->data)[i]^0x8000, f.Get_PackFile());
	}
}
