#ifndef F_STATE_H_
#define F_STATE_H_

#include <map>
#include <string>

#include "Exception.h"
#include "File.h"
#include "FLua.h"

class File;
class ISerializer;

class IStateObject
{
	private:
		std::string id;

	protected:
		inline void Set_Id(const std::string& i) { id = i; }

	public:
		virtual ~IStateObject(void) { }

		virtual void ToFile(File& f) const = 0;
		virtual void FromFile(File& f) = 0;
		virtual void ToLua(lua_State * l) = 0;
		virtual void FromLua(lua_State * l, int index, bool resursive) = 0;

		inline const std::string& Get_Id(void) const { return id; }

		virtual void RegisterSerializer(class ISerializer * serializer, const std::string& id) { }
};

/* This is used only to deserialize an object. */
class ISerializer
{
	public:
		virtual IStateObject * Get_Object(void) const = 0;
};

class STable : public IStateObject
{
	private:
		std::map<std::string, IStateObject *> table;
		std::map<std::string, ISerializer *> serializers;

	protected:
		std::map<std::string, ISerializer *> Get_Serializers(void) const { return serializers; }

	public:
		const char * TableStart;
		const char * TableEnd;

		STable(void) : TableStart("Table"), TableEnd("EndTable") { Set_Id(TableStart); }
		virtual ~STable(void);

		void ToFile(File& f) const;
		void FromFile(File& f);
		
		void ToLua(lua_State * l) { FLua::ToLua(l, this, true, "STable"); }
		void FromLua(lua_State * l, int index, bool recursive); /* This only makes a shallow copy. */
		void ObjectFromLua(lua_State * l, int index, const std::string& name); /* Refer to `FromLua', right there ^ */
		void ToTable(lua_State * l); /* This is kind of like ToLua except it converts it to a table (for use with ipairs(), etc. */

		IStateObject * Get_Object(const std::string& n) const;
		void Set_Object(const std::string& n, IStateObject * o);

		void RegisterSerializer(ISerializer * serializer, const std::string& id);
};

class State : public STable
{
	public:
		~State(void);

		void SaveToFile(const std::string& filename);
		void LoadFromFile(const std::string& filename);
};

/* The classes. */
class NumberState : public IStateObject
{
	private:
		double d;

	public:
		NumberState(void) { Set_Id("Number"); }
		void ToFile(File& f) const { f.Write(d); }
		void FromFile(File& f) { d = f.ReadDouble(); }
		void ToLua(lua_State * l) { lua_pushnumber(l, d); }
		void FromLua(lua_State * l, int index, bool recursive) { d = luaL_checknumber(l, index); }
};

class NumberSerializer : public ISerializer
{
	public:
		IStateObject * Get_Object(void) const { return new NumberState; }
};

class StringState : public IStateObject
{
	private:
		std::string s;

	public:
		StringState(void) { Set_Id("String"); }
		void ToFile(File& f) const { f.Write(s); }
		void FromFile(File& f) { s = f.ReadString(); }
		void ToLua(lua_State * l) { lua_pushstring(l, s.c_str()); }
		void FromLua(lua_State * l, int index, bool recursive) { s = luaL_checkstring(l, index); }
};

class StringSerializer : public ISerializer
{
	public:
		IStateObject * Get_Object(void) const { return new StringState; }
};

class BooleanState : public IStateObject
{
	private:
		bool b;

	public:
		BooleanState(void) { Set_Id("Boolean"); }
		void ToFile(File& f) const { f.Write((char)b); }
		void FromFile(File& f) { b = f.ReadCharacter(); }
		void ToLua(lua_State * l) { lua_pushboolean(l, b); }
		void FromLua(lua_State * l, int index, bool recursive) { b = lua_toboolean(l, index); }
};

class BooleanSerializer : public ISerializer
{
	public:
		IStateObject * Get_Object(void) const { return new BooleanState; }
};

class TableSerializer : public ISerializer
{
	public:
		IStateObject * Get_Object(void) const { return new STable; }
};

#endif
