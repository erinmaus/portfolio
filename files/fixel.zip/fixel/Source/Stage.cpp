#include <allegro.h>
#include <cstring>
#include <string>
#include <vector>

#include "Bitmap.h"
#include "Exception.h"
#include "FLua.h"
#include "Map.h"
#include "Objector.h"
#include "Shader.h"
#include "State.h"
#include "Stage.h"
#include "TileSheet.h"

SMap::SMap(int width, int height)
	: width(width), height(height)
{
	tiles = new Tile[width * height];

	Clear(0, 0);
}

SMap::~SMap(void)
{
	delete[] tiles;
}

inline void SMap::Clear(Color b, Color i)
{
	for (int xy = 0; xy < width * height; xy++)
	{
		tiles[xy].Border = b;
		tiles[xy].Inner = i;
	}
}

void SMap::Draw(Bitmap& b, const Point& xy, int w, int h)
{
	for (int x = 0; x < width; x++)
		for (int y = 0; y < height; y++)
		{
			Rectangle r((x * w) + xy.X , (y * h) + xy.Y, w - 1, h - 1);
			b.DrawPrimitive(r, PrimitiveModeFilled, tiles[y * width + x].Inner);
			b.DrawPrimitive(r, PrimitiveModeLined, tiles[y * width + x].Border);
		}
}

void UMap::Tile::Update(double time, const TileSheet& t)
{
	Time += time;

	if (Time >= t.Get_TileAt(Index).Speed)
	{
		Time = 0.0;
		Index = t.Get_TileAt(Index).Next;
	}
}

UMap::UMap(const Map& m, const TileSheet& t)
	: width(m.Get_Width()), height(m.Get_Height()), tileSheet(t)
{
	tiles = new Tile[width * height];

	for (int x = 0; x < width; x++)
		for (int y = 0; y < height; y++)
		{
			tiles[y * width + x].Index = m.Get_TileAtXY(x, y).Index;
			tiles[y * width + x].Time = 0.0;
		}
}

void UMap::Update(double time)
{
	for (int i = 0; i < width * height; i++)
		tiles[i].Update(time, tileSheet);
}

void UMap::ToSMap(SMap& m, const Point& p)
{
	m.Clear(0, 0);

	for (int x = 0; x < m.Get_Width(); x++)
		for (int y = 0; y < m.Get_Height(); y++)
		{
			if (x + p.X < 0 || x + p.X >= width || y + p.Y < 0 || y + p.Y >= height)
				continue;

			SMap::Tile& t = m.Get_TileAtXY(x, y);
			t.Border = tileSheet.Get_TileAt(tiles[(y + p.Y) * width + (x + p.X)].Index).Border;
			t.Inner = tileSheet.Get_TileAt(tiles[(y + p.Y) * width + (x + p.X)].Index).Inner;
		}
}

Stage::Stage(lua_State * l, State * state, const std::string& filename)
	: luaState(l), state(state)
{
	objector = new Objector(this);

	SaveStack(luaState);

	reference = FLua::DoFile(luaState, filename);
	table = FLua::GetTableNameFromFilename(filename);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, reference);
	lua_getfield(luaState, -1, table.c_str());

	lua_getfield(luaState, -1, "Initialize");
	lua_pushvalue(luaState, -2);

	FLua::ToLua(l, this, true, "Stage");

	if (lua_pcall(luaState, 2, 0, 0) != 0)
		throw Exception(lua_tostring(l, -1), "Syntax error?");

	Synchronize();

	RestoreStack(luaState);

	sMap = new SMap(camera.Width, camera.Height);
	uMap = new UMap(*dMap, *tileSheet);
}

Stage::~Stage(void)
{
	SaveStack(luaState);

	lua_getglobal(luaState, FLua::GlobalTable);
	luaL_unref(luaState, -1, reference);

	RestoreStack(luaState);

	delete objector;

	while (shaders.size() > 0)
	{
		delete shaders.back();
		shaders.pop_back();
	}

	delete dMap;
	delete sMap;
	delete uMap;

	delete tileSheet;
}

void Stage::Synchronize(void)
{
	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, reference);
	lua_getfield(luaState, -1, table.c_str());

	lua_getfield(luaState, -1, "Map");

	if (lua_type(luaState, -1) == LUA_TSTRING)
		dMap = new Map(luaL_checkstring(luaState, -1));
	else
	{
		LuaObject * o = FLua::FromLua(luaState, -1, false, "Map");

		o->Shared = true;
		dMap = (Map *)o->Data;
	}

	lua_pop(luaState, 1);

	/* Get all the shaders. */
	{
		int before = lua_gettop(luaState);

		lua_getfield(luaState, -1, "Shaders");

		if (!lua_isnil(luaState, -1))
		{
			if (!lua_istable(luaState, -1))
				throw Exception("Expect me to index a non-table?", "Logic error?");

			for (int i = 1; /* Nothing. */ ; i++)
			{
				lua_rawgeti(luaState, -1, i);

				if (!lua_isnil(luaState, -1))
				{
					shaders.push_back(new Shader(luaState, luaL_checkstring(luaState, -1)));
					lua_pop(luaState, 1);
				}
				else
				{
					lua_pop(luaState, 1);
					break;
				}
			}
		}

		int after = lua_gettop(luaState);

		lua_pop(luaState, after - before);
	}

	/* Get the tile sheet. */
	lua_getfield(luaState, -1, "TileSheet");

	if (lua_type(luaState, -1) == LUA_TSTRING)
		tileSheet = new TileSheet(luaL_checkstring(luaState, -1));
	else
	{
		LuaObject * o = FLua::FromLua(luaState, -1, false, "TileSheet");

		o->Shared = true;
		tileSheet = (TileSheet *)o->Data;
	}

	lua_pop(luaState, 1);

	/* Get the width and height. */
	lua_getfield(luaState, -1, "TileWidth");
	width = luaL_checkinteger(luaState, -1);

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "TileHeight");
	height = luaL_checkinteger(luaState, -1);

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "CameraWidth");
	camera.Width = luaL_checkinteger(luaState, -1);

	if (camera.Width < 1)
		throw Exception("Width is less than one.", "Logic error?");

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "CameraHeight");
	camera.Height = luaL_checkinteger(luaState, -1);

	if (camera.Height < 1)
		throw Exception("Height is less than one.", "Logic error?");

	lua_pop(luaState, 1);
}

void Stage::Update(double time)
{
	SaveStack(luaState);

	uMap->Update(time);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, reference);
	lua_getfield(luaState, -1, table.c_str());
	lua_getfield(luaState, -1, "Update");

	if(!lua_isnil(luaState, -1))
	{
		lua_pushvalue(luaState, -2);
		lua_pushnumber(luaState, time);

		if(lua_pcall(luaState, 2, 0, 0) != 0)
			throw Exception(lua_tostring(luaState, -1), "Syntax error?");
	}

	objector->Update();

	RestoreStack(luaState);
}

void Stage::Draw(Bitmap& bitmap, const Point& point)
{
	SaveStack(luaState);

	uMap->ToSMap(*sMap, Point(camera.X, camera.Y));

	for (std::vector<Shader *>::iterator i = shaders.begin(); i != shaders.end(); i++)
		(*i)->Shade(*sMap);

	sMap->Draw(bitmap, point, width, height);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, reference);
	lua_getfield(luaState, -1, table.c_str());
	lua_getfield(luaState, -1, "Draw");

	if (!lua_isnil(luaState, -1))
	{
		lua_pushvalue(luaState, -2);
		FLua::ToLua(luaState, &bitmap, true, "Bitmap");
		FLua::ToLua(luaState, new Point(point), false, "Point");

		if(lua_pcall(luaState, 3, 0, 0) != 0)
			throw Exception(lua_tostring(luaState, -1), "Syntax error?");
	}

	objector->Draw(bitmap, camera);

	RestoreStack(luaState);
}

void Stage::RemoveShader(int index)
{
	delete shaders.at(index);
	shaders.erase(shaders.begin() + (int)index);
}
