#include <allegro.h>

#include "Bitmap.h"
#include "Exception.h"
#include "FLua.h"
#include "Point.h"
#include "Rectangle.h"

namespace FLua
{
	namespace FBitmap
	{
		/* Library functions. */
		int Create(lua_State * l)
		{
			if (lua_type(l, 1) == LUA_TSTRING)
			{
				Bitmap * b;

				try
				{
					b = new Bitmap(luaL_checkstring(l, 1));
				}
				catch (const Exception& e)
				{
					luaL_error(l, "%s (%s)", e.Get_Reason().c_str(), e.Get_Sub().c_str());
				}

				ToLua(l, b, false, "Bitmap");
			}
			else
			{
				if (lua_gettop(l) == 2)
				{
					Bitmap * b = new Bitmap(luaL_checkinteger(l, 1), luaL_checkinteger(l, 2));
					ToLua(l, b, false, "Bitmap");
				}
				else
				{
					Bitmap * b = new Bitmap(luaL_checkinteger(l, 1), luaL_checkinteger(l, 2), luaL_checkinteger(l, 3));
					ToLua(l, b, false, "Bitmap");
				}
			}

			return 1;
		}

		const luaL_Reg bitmapLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		/* Metatable functions. */
		inline int ToString(lua_State * l)
		{
			lua_pushfstring(l, "bitmap: %p", FromLua(l, 1, true, "Bitmap")->Data);

			return 1;
		}

		int Index(lua_State * l)
		{
			Bitmap * b = (Bitmap *)FromLua(l, 1, false, "Bitmap")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Width")
				lua_pushinteger(l, b->Get_Width());
			else if (key == "Height")
				lua_pushinteger(l, b->Get_Height());
			else if (key == "Clipping")
			{
				Rectangle * r = new Rectangle(b->Get_ClippingRegion());

				ToLua(l, r, false, "Rectangle");
			}
			else if (key == "Copy")
			{
				Bitmap * c = new Bitmap(b->Get_Bitmap(), false);
				ToLua(l, c, false, "Bitmap");
			}
			else
				luaL_error(l, "%s is an invalid key", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			Bitmap * b = (Bitmap *)FromLua(l, 1, false, "Bitmap")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "Clipping")
			{
				Rectangle * r = (Rectangle *)FromLua(l, 3, false, "Rectangle")->Data;
				b->Set_ClippingRegion(*r);
			}
			else
				luaL_error(l, "%s is an invalid key", key.c_str());

			return 1;
		}

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Bitmap");

			if (!(o->Shared))
				delete (Bitmap *)o->Data;

			return 0;
		}

		/* Actual functions. */
		int BlitTo(lua_State * l)
		{
			Bitmap * b = (Bitmap *)FromLua(l, 1, false, "Bitmap")->Data;
			Bitmap * to = (Bitmap *)FromLua(l, 2, false, "Bitmap")->Data;

			switch(lua_gettop(l))
			{
				case 2: /* Just blit to another bitmap. */
					b->BlitTo(*to);
					break;

				case 3: /* The location is provided only, or a rectangle is... */
					{
						if (IsType(l, 3, "Point"))
						{
							Point * p = (Point *)FromLua(l, 3, false, "Point")->Data;
							b->BlitTo(*to, p->X, p->Y, b->Get_Width(), b->Get_Height());
						}
						else
						{
							Rectangle * r = (Rectangle *)FromLua(l, 3, false, "Rectangle")->Data;
							b->BlitTo(*to, r->X, r->Y, r->Width, r->Height);
						}
					}
					break;

				case 5: /* The whole kaboodle. */
					{
						Rectangle * r = (Rectangle *)FromLua(l, 3, false, "Rectangle")->Data;
						Point * d = (Point *)FromLua(l, 4, false, "Point")->Data;

						b->BlitTo(*to, r->X, r->Y, d->X, d->Y, r->Width, r->Height);
					}

				case 6: /* X and Y, along with the width and height, are provided, or the whole thing as a group of points, etc. */
					b->BlitTo(*to, luaL_checkinteger(l, 3), luaL_checkinteger(l, 4), luaL_checkinteger(l, 5), luaL_checkinteger(l, 6));
					break;

				case 8: /* The X, Y, destination X/Y, and width and height, are provided. */
					b->BlitTo(*to, luaL_checkinteger(l, 3), luaL_checkinteger(l, 4), luaL_checkinteger(l, 5), luaL_checkinteger(l, 6),
						luaL_checkinteger(l, 7), luaL_checkinteger(l, 8));
					break;

				default:
					luaL_error(l, "%d arguments is invalid", lua_gettop(l));
			}

			return 0;
		}

		int Clear(lua_State * l)
		{
			Bitmap * b = (Bitmap *)FromLua(l, 1, false, "Bitmap")->Data;

			if (lua_gettop(l) > 1)
				b->Clear(luaL_checkinteger(l, 2));
			else
				b->Clear();

			return 0;
		}
		
		int Draw(lua_State * l)
		{
			Bitmap * b = (Bitmap *)FromLua(l, 1, false, "Bitmap")->Data;
			Bitmap * to = (Bitmap *)FromLua(l, 2, false, "Bitmap")->Data;
			
			switch(lua_gettop(l))
			{
				case 3:
					{
						Point * p = (Point *)FromLua(l, 3, false, "Point")->Data;
						draw_sprite(to->Get_Bitmap(), b->Get_Bitmap(), p->X, p->Y);
					}
					break;
				case 4:
					draw_sprite(to->Get_Bitmap(), b->Get_Bitmap(), luaL_checkinteger(l, 3), luaL_checkinteger(l, 4));
					break;
				
				default:
					luaL_error(l, "%d arguments is too many/little", lua_gettop(l));
			}
			
			return 0;
		}

		int DrawTrans(lua_State * l)
		{
			Bitmap * b = (Bitmap *)FromLua(l, 1, false, "Bitmap")->Data;
			Bitmap * to = (Bitmap *)FromLua(l, 2, false, "Bitmap")->Data;
			
			switch(lua_gettop(l))
			{
				case 3:
					{
						Point * p = (Point *)FromLua(l, 3, false, "Point")->Data;
						b->DrawTrans(*to, p->X, p->Y);
					}
					break;
				case 4:
					b->DrawTrans(*to, luaL_checkinteger(l, 3), luaL_checkinteger(l, 4));
					break;
				
				default:
					luaL_error(l, "%d arguments are too many/little", lua_gettop(l));
			}
			
			return 0;
		}
		
		int DrawPrimitive(lua_State * l)
		{
			Bitmap * b = (Bitmap *)FromLua(l, 1, false, "Bitmap")->Data;
			
			if (IsType(l, 2, "Point"))
			{
				if (lua_gettop(l) > 3)
					b->DrawPrimitive(*(Point *)FromLua(l, 2, false, "Point")->Data, *(Point *)FromLua(l, 3, false, "Point")->Data, luaL_checkinteger(l, 4));
				else
					b->DrawPrimitive(*(Point *)FromLua(l, 2, false, "Point")->Data, luaL_checkinteger(l, 3));
			}
			else if (IsType(l, 2, "Rectangle"))
			{
				try
				{
					b->DrawPrimitive(*(Rectangle *)FromLua(l, 2, false, "Rectangle")->Data, (PrimitiveMode)luaL_checkinteger(l, 3), luaL_checkinteger(l, 4));
				}
				catch (const Exception& e)
				{
					luaL_error(l, "%s", e.what());
				}
			}
			
			return 0;
		}

		const luaL_Reg bitmap[] =
		{
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "__gc", &Gc },
			{ "BlitTo", &BlitTo },
			{ "Clear", &Clear },
			{ "Draw", &Draw },
			{ "DrawTrans", &DrawTrans },
			{ "DrawPrimitive", &DrawPrimitive },
			{ 0, 0 }
		};
	}
}
