#include <allegro.h>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>

#include "Exception.h"
#include "FLua.h"
#include "Sample.h"

namespace FLua
{
	namespace FSample
	{
		int Create(lua_State * l)
		{
			SAMPLE * s = 0;

			if (lua_gettop(l) > 1)
			{
				int freq = luaL_checkinteger(l, 1);
				int size = luaL_checkinteger(l, 2);

				s = create_sample(8, 0, freq, size); /* Always 8-bit (retro) and always zeeero. */
				memset(s->data, 0, size);

				if (!s)
					luaL_error(l, "out of memory or something");

				int length = luaL_checkinteger(l, 3);
				SampleType t = (SampleType)luaL_checkinteger(l, 4);

				int start = luaL_checkinteger(l, 5) & 0xFF, mod = luaL_checkinteger(l, 6) & 0xFF;

				if (!lua_istable(l, 7))
					luaL_error(l, "expected argument #7 to be a table!");

				std::vector<double> freqs;

				lua_pushnil(l);

				while(lua_next(l, -2))
				{
					freqs.push_back(luaL_checknumber(l, -1));
					lua_pop(l, 1);
				}

				unsigned char * stream = (unsigned char *)s->data;

				for (int i = 0; i < freqs.size(); i++)
				{
					for (int j = 0; j < (length * s->freq) / freqs.size(); j++)
					{
						int position = i * ((length * s->freq) / freqs.size()) + j;
						double sound = ((double)j / freq) * freqs[i];

						if (t == SampleSquareWave)
							stream[position] = start + mod * sound;
						else if (t == SampleSineWave)
							stream[position] = start + mod * sin(sound * 2 * AL_PI);
						else if (t == SampleTriangleWave)
							stream[position] = start + mod * asin(sin(sound * 2 * AL_PI));
						else
							luaL_error(l, "invalid enumeration value");
					}
				}
			}
			else
			{
				s = load_sample(luaL_checkstring(l, 1));

				if (!s)
					luaL_error(l, "file couldn't be found or something");
			}

			ToLua(l, new Sample(s, false), false, "Sample");

			return 1;
		}

		const luaL_Reg sampleLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Sample");

			if (!(o->Shared))
				delete (Sample *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			Sample * s = (Sample *)FromLua(l, 1, false, "Sample")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			return luaL_error(l, "%s is an invalid index", key.c_str());
		}

		int Play(lua_State * l)
		{
			Sample * s = (Sample *)FromLua(l, 1, false, "Sample")->Data;

			lua_pushinteger(l, s->Play(luaL_checkinteger(l, 2), luaL_checkinteger(l, 3), luaL_checkinteger(l, 4), lua_toboolean(l, 5)));

			return 1;
		}

		int Stop(lua_State * l)
		{
			Sample * s = (Sample *)FromLua(l, 1, false, "Sample")->Data;

			s->Stop();

			return 0;
		}

		int Adjust(lua_State * l)
		{
			Sample * s = (Sample *)FromLua(l, 1, false, "Sample")->Data;

			s->Adjust(luaL_checkinteger(l, 2), luaL_checkinteger(l, 3), luaL_checkinteger(l, 4), lua_toboolean(l, 5));

			return 0;
		}

		int SaveToFile(lua_State * l)
		{
			Sample * s = (Sample *)FromLua(l, 1, false, "Sample")->Data;

			s->SaveToFile(luaL_checkstring(l, 2));

			return 0;
		}

		const luaL_Reg sample[] =
		{
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "Play", &Play },
			{ "Stop", &Stop },
			{ "Adjust", &Adjust },
			{ "SaveToFile", &SaveToFile },
			{ 0, 0 }
		};
	}
}
