#ifndef F_STAGE_H_
#define F_STAGE_H_

#include <string>
#include <vector>

#include "Color.h"
#include "FLua.h"
#include "Point.h"
#include "Rectangle.h"

class Bitmap;
class Map;
class Objector;
class Shader;
class State;
class TileSheet;

class SMap /* Stage map.  Or shader map. */
{
	public:
		struct Tile
		{
			public:
				Color Border;
				Color Inner;
		};

	private:
		int width, height;
		Tile * tiles;

	public:
		SMap(int width, int height);
		~SMap(void);

		inline int Get_Width(void) const { return width; }
		inline int Get_Height(void) const { return height; }

		Tile& Get_TileAtXY(int x, int y) const { if (x >= width || y >= height) throw Exception("Invalid index.", "Logic error?"); return tiles[y * width + x]; }

		/* An SMap should only be as big as the viewing area. No more. */
		void Draw(class Bitmap& b, const Point& xy, int w, int h); /* Draws the entire map. */

		void Clear(Color b, Color i);
};

class UMap /* Update-able map. Or unicorn map. */
{
	public:
		struct Tile
		{
			public:
				int Index;
				double Time;

				void Update(double time, const TileSheet& t);
		};

	private:
		int width, height;
		Tile * tiles;

		const class TileSheet& tileSheet;

	public:
		UMap(const class Map& m, const class TileSheet& t);

		inline int Get_Width(void) const { return width; }
		inline int Get_Height(void) const { return height; }

		/* Updates every tile. */
		void Update(double time);

		/* Converts this map to something drawable. */
		void ToSMap(SMap& m, const Point& p);
};

class Stage
{
	private:
		class Map * dMap; /* The default, blank, useless, junky map. */
		SMap * sMap; /* The shader map.  This is the map that actually gets drawn! :o */
		UMap * uMap; /* The update-able map. */

		class TileSheet * tileSheet; /* The tile sheet used by this stage. */

		lua_State * luaState; /* The state used. */
		int reference; /* The reference to all the fun stuff. */
		std::string table; /* The table we wanna mess with. */

		std::vector<class Shader *> shaders;

		Rectangle camera; /* The camera defines the width and height of the view portion upon creation. */

		int width, height; /* The width and height of the tiles. */

		class Objector * objector;

		class State * state; /* This stage's state (usually passed on and on, I guess) */

	public:
		Stage(lua_State * l, class State * state, const std::string& filename);
		~Stage(void);

		void Synchronize(void);

		/* Updates the stage. */
		void Update(double time);

		/* Draws the stage. */
		void Draw(class Bitmap& bitmap, const Point& point);

		/* Adds a shader. */
		void AddShader(class Shader * shader) { shaders.push_back(shader); }
		void RemoveShader(int index); /* You should keep track of the shaders. */

		/* Moves the camera. */
		void MoveCamera(int plusX, int plusY) { camera.X += plusX; camera.Y += plusY; }
		void Set_CameraXY(const Point& p) { camera.X = p.X; camera.Y = p.Y; }

		/* Gets the camera's X and Y. */
		Point Get_CameraXY(void) const { return Point(camera.X, camera.Y); }

		/* Width, height getters/setters. */
		int Get_TileWidth(void) const { return width; }
		int Get_TileHeight(void) const { return height; }

		int Get_CameraWidth(void) const { return camera.Width; }
		int Get_CameraHeight(void) const { return camera.Height; }

		/* Gets Objector. */
		class Objector * Get_Objector(void) const { return objector; }
		class State * Get_State(void) const { return state; }

		/* Gets the map. */
		class Map * Get_Map(void) const { return dMap; }
};

#endif
