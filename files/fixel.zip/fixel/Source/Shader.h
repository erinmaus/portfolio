#ifndef F_SHADER_H_
#define F_SHADER_H_

#include "FLua.h"
#include "Stage.h"

class Shader
{
	private:
		int reference;
		lua_State * luaState;

	public:
		Shader(lua_State * l, const std::string& filename);
		~Shader(void);

		void Shade(SMap& m);
};

#endif
