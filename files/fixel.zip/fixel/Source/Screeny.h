#ifndef F_SCREENY_H_
#define F_SCREENY_H_

#include <string>
#include <vector>

#include "IManager.h"
#include "ManagerList.h"

class Bitmap;
class Game;
class Screen;

class Screeny : public IManager
{
	private:
		std::vector<class Screen *> screens;
		std::vector<class Screen *> toRemove;
		ManagerList list;

	public:
		/* Default, lame constructor. */
		Screeny(class Game * game) : IManager(game) { }

		/* The constructor has to delete each screen object in the list. */
		~Screeny(void);

		/* Returns the amount of screens. */
		inline unsigned int Get_Total(void) const { return screens.size(); }

		/* This will update each screen in the list, `screens'.  If they request to be deleted, then
			they shall be *after* the logic loop for updating has run. The handle-input function is
			called before Update(). */
		void Update(bool firstLogicRun);

		/* This draws each screen one after another, but only if it is visible (as in, not covered by
			anything else). */
		void Draw(class Bitmap& bitmap);

		/* Ways to get another screen.  These should only be used if you for sure know that the screen
			exists side-by-side. */
		inline class Screen& Get_Screen(const std::string& name) { return Get_Screen(name, 0); };
		class Screen& Get_Screen(const std::string& name, unsigned int index);

		/* Adds a screen.  Any screen passed to AddScreen() should be allocated by new, because they
			will be delete'd if they exit, or if the screen manager is deallocated. */
		void AddScreen(class Screen * screen);

		/* This removes a screen.  After it is removed, it will be deleted. */
		void RemoveScreen(class Screen * screen);

		/* This registers a screen. */
		void Register(const std::string& name, const std::string& path) { list.Add(name, path); }
		void Unregister(const std::string& name) { list.Remove(name); }
		const std::string& Get_RegisteredPath(const std::string& name) const { return list.Find(name); }
};

#endif
