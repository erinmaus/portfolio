#ifndef F_FILE_H_
#define F_FILE_H_

#include <allegro.h>
#include <cstdio>
#include <string>

enum FileMode
{
	FileModeWrite = 0x01,
	FileModeRead = 0x02,
	FileModeAppend = 0x04,
	FileModeCreate = 0x08
};

enum Endianness
{
	BigEndian = 0,
	LittleEndian = 1
};

enum FileError
{
	FileEndOfFile = 0,
	FileInvalidArgument = 1,
	FileErrorTotal
};

class File
{
	private:
		PACKFILE * pfile;
		FILE * file;
		FileMode mode;
		Endianness endianness;
		bool binary;
		bool flushOnOutput;

		FileError error;
	
	public:
		File(const std::string& filename, FileMode mode, bool binary = false, bool flushOnOutput = false, Endianness e = LittleEndian);

		~File(void);

		/* Gets the file mode. */
		inline FileMode Get_FileMode(void) const { return mode; }

		/* Get the endianness. */
		inline Endianness Get_Endianness(void) const { return endianness; }

		/* If the file is binary or not. */
		inline bool Get_IsBinary(void) const { return binary; }

		/* Gets/sets if the file should be flushed upon writing to it. */
		inline bool Get_FlushOnOutput(void) const { return flushOnOutput; }
		inline void Set_FlushOnOutput(bool foo) { flushOnOutput = foo; }

		/* If the file has met its end. */
		inline bool Get_IsEndOfFile(void) { return feof(file); }
		inline FileError Get_Error(void) const { return error; }

		/* Gets the FILE * or PACKFILE * structures. */
		inline PACKFILE * Get_PackFile(void) const { return pfile; }
		inline FILE * Get_File(void) const { return file; }
		
		/* Writes various things to the stream. */
		int Write(int i);
		int Write(float f);
		int Write(double d);
		int Write(char c);
		int Write(const std::string& s);
		
		/* Reads various things from the stream. */
		int ReadInteger(void);
		float ReadFloat(void);
		double ReadDouble(void);
		char ReadCharacter(void);
		std::string ReadString(bool readLine = false);
};

#endif
