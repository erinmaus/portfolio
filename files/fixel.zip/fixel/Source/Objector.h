#ifndef F_OBJECTOR_H_
#define F_OBJECTOR_H_

#include <string>
#include <vector>

#include "Point.h"
#include "Rectangle.h"

class Bitmap;
class Game;
class GameObject;
class Stage;

class Objector
{
	private:
		std::vector<GameObject *> objects;
		std::vector<GameObject *> important;
		std::vector<GameObject *> toDelete;

		class Stage * stage;

	public:
		Objector(class Stage * s) : stage(s) { }
		~Objector(void);

		/* Gets the stage everything belongs to. */
		class Stage * Get_Stage(void) const { return stage; }

		/* This adds an object to the object list. If the object is important (say, a player), then
			it should be added to the important list.  Anything on the important list will not be deleted. */
		void AddObject(GameObject * o, bool important);

		/* This removes an object from the object list (and the important list if so desired). */
		void RemoveObject(GameObject * o);

		/* Same as the above, except you provide the UID of the object. */
		void RemoveObject(int uid);

		/* Clears all but the important objects. */
		void Clear(void);

		/* This broadcasts a message to every game object (every object should share the same lua_State,
			so if they don't, you just messed something up). */
		void Broadcast(const std::string& e, int index);

		/* This broadcasts to a team only (with rank `rank' and above).  Refer to `Broadcast' for specific information. */
		void BroadcastToTeam(const std::string& e, int index, int team, int rank = -1);

		/* This gets an object. */
		GameObject * Get_Object(const std::string& name, int index = 0);

		/* This gets the (first) object at the specified location. */
		GameObject * Get_ObjectAtPosition(const Point& loc, int index = 0);

		/* Updates the manager. */
		void Update(void);

		/* Draws the manager. */
		void Draw(class Bitmap& buffer, Rectangle& cam);
};

#endif
