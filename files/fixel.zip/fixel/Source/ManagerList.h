#ifndef F_MANAGERLIST_H_
#define F_MANAGERLIST_H_

#include <map>
#include <string>

/* A manager list simply holds data for a similar manager. */
class ManagerList
{
	private:
		/* Key: <name>, Value: <path/et al> */
		std::map<std::string, std::string> list;

	public:
		~ManagerList(void) { list.clear(); }

		/* Adds an item to the list. */
		void Add(const std::string& key, const std::string& value) { list[key] = value; }

		/* Removes an item. */
		void Remove(const std::string& key) { list.erase(list.find(key)); }

		/* Gets an item from the list. */
		const std::string& operator[](const std::string& key) { return list[key]; }

		/* Finds a value. */
		const std::string& Find(const std::string& key) const { return (*(list.find(key))).second; }
};

#endif
