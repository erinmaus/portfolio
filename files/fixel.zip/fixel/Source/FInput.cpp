#include "Exception.h"
#include "FLua.h"
#include "Input.h"

namespace FLua
{
	namespace FControl
	{
		int Create(lua_State * l)
		{
			Control * c = new Control();

			if (lua_gettop(l) > 0)
				c->Type = (ControlType)luaL_checkinteger(l, 1);

			if (lua_gettop(l) > 1)
				c->Button = luaL_checkinteger(l, 2);

			ToLua(l, c, false, "Control");

			return 1;
		}

		const luaL_Reg contLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Control");

			if (!(o->Shared))
				delete (Control *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			Control * c = (Control *)FromLua(l, 1, false, "Control")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Type")
				lua_pushinteger(l, c->Type);
			else if (key == "Button")
				lua_pushinteger(l, c->Button);
			else
				luaL_error(l, "%s is an invalid key", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			Control * c = (Control *)FromLua(l, 1, false, "Control")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "Type")
				c->Type = (ControlType)luaL_checkinteger(l, 3);
			else if (key == "Button")
				c->Button = luaL_checkinteger(l, 3);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 0;
		}

		int State(lua_State * l)
		{
			Control * c = (Control *)FromLua(l, 1, false, "Control")->Data;
			Input * i = (Input *)FromLua(l, 2, false, "Input")->Data;

			switch (c->Type)
			{
				case ControlKeyboard:
					try
					{
						lua_pushinteger(l, i->Get_KeyState(c->Button));
						return 1;
					}
					catch (const Exception& e)
					{
						luaL_error(l, "%s", e.what());
					}
					break;

				case ControlJoystick:
					if (c->Button < 0)
					{
						Direction d1 = DirectionMax, d2 = DirectionMax;
						ButtonState b1 = ButtonMax, b2 = ButtonMax;

						i->Get_DStickState(0, d1, d2, b1, b2);

						if (c->Button == -((int)DirectionUp + 1) && d1 == DirectionUp)
							lua_pushinteger(l, b1);
						else if (c->Button == -((int)DirectionDown + 1) && d1 == DirectionDown)
							lua_pushinteger(l, b1);
						else if (c->Button == -((int)DirectionLeft + 1) && d2 == DirectionLeft)
							lua_pushinteger(l, b2);
						else if (c->Button == -((int)DirectionRight + 1) && d2 == DirectionRight)
							lua_pushinteger(l, b2);
						else
							lua_pushnil(l);

						return 1;
					}
					else
					{
						try
						{
							lua_pushinteger(l, i->Get_JoystickButton(0, c->Button));

							return 1;
						}
						catch (const Exception& e)
						{
							luaL_error(l, "%s", e.what());
						}
					}
					break;

				default:
					luaL_error(l, "invalid `Type'");
			}

			return 0;
		}

		const luaL_Reg cont[] =
		{
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "State", &State },
			{ 0, 0 }
		};
	}

	namespace FControls
	{
		int Index(lua_State * l)
		{
			Controls * c = (Controls *)FromLua(l, 1, false, "Controls")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (c->Buttons.find(key) == c->Buttons.end())
				luaL_error(l, "%s is an invalid index", key.c_str());
			else
				ToLua(l, c->Buttons[key], true, "Control");

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			Controls * c = (Controls *)FromLua(l, 1, false, "Controls")->Data;
			std::string key = luaL_checkstring(l, 2);
			Control * con = (Control *)FromLua(l, 3, false, "Control")->Data;

			c->Buttons[key] = new Control(con->Type, con->Button);

			return 0;
		}

		int SaveToFile(lua_State * l)
		{
			Controls * c = (Controls *)FromLua(l, 1, false, "Controls")->Data;

			try
			{
				c->SaveToFile(luaL_checkstring(l, 2));
			}
			catch (const std::exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		const luaL_Reg cont[] =
		{
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "SaveToFile", &SaveToFile },
			{ 0, 0 }
		};
	}

	namespace FInput
	{
		/* Metatable functions. */
		int Index(lua_State * l)
		{
			Input * i = (Input *)FromLua(l, 1, false, "Input")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "LastKeyPressed")
				lua_pushinteger(l, i->Get_AnyKey());
			else if (key == "MouseMoved")
				lua_pushboolean(l, i->Get_MouseMoved());
			else if (key == "MouseXY")
			{
				Point * p = new Point(i->Get_MousePosition(InputCurrent));

				ToLua(l, p, false, "Point");
			}
			else if (key == "MouseDifference")
			{
				Point * p = new Point(i->Get_MouseDifference());

				ToLua(l, p, false, "Point");
			}
			else if (key == "JoystickTotal")
				lua_pushinteger(l, i->Get_JoystickTotal());
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		/* Wee.  Actual functions. */
		int GetKeyState(lua_State * l)
		{
			Input * i = (Input *)FromLua(l, 1, false, "Input")->Data;
			int key = luaL_checkinteger(l, 2);

			try
			{
				lua_pushinteger(l, i->Get_KeyState(key));
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s (%s)", e.Get_Reason().c_str(), e.Get_Sub().c_str());
			}

			return 1;
		}

		int GetMouseButton(lua_State * l)
		{
			Input * i = (Input *)FromLua(l, 1, false, "Input")->Data;
			int button = luaL_checkinteger(l, 2);

			try
			{
				lua_pushinteger(l, i->Get_MouseButton((MouseButton)button));
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s (%s)", e.Get_Reason().c_str(), e.Get_Sub().c_str());
			}

			return 1;
		}

		int GetJoystickButton(lua_State * l)
		{
			Input * i = (Input *)FromLua(l, 1, false, "Input")->Data;

			try
			{
				switch(lua_gettop(l))
				{
					case 2:
						lua_pushinteger(l, i->Get_JoystickButton(luaL_checkinteger(l, 2)));
						break;

					case 3:
						lua_pushinteger(l, i->Get_JoystickButton(luaL_checkinteger(l, 2), luaL_checkinteger(l, 3)));
						break;
				}
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s (%s)", e.Get_Reason().c_str(), e.Get_Sub().c_str());
			}

			return 1;
		}

		int ClearKeyBuffer(lua_State * l)
		{
			clear_keybuf();

			return 0;
		}

		int GetJoystickDirection(lua_State * l)
		{
			Input * i = (Input *)FromLua(l, 1, false, "Input")->Data;

			if (i->Get_JoystickTotal() > 0)
			{
				Direction d1 = DirectionMax, d2 = DirectionMax;
				ButtonState b1 = ButtonMax, b2 = ButtonMax;

				i->Get_DStickState(0, d1, d2, b1, b2);

				if (d1 == DirectionMax)
					lua_pushnil(l);
				else
					lua_pushinteger(l, d1);

				if (d2 == DirectionMax)
					lua_pushnil(l);
				else
					lua_pushinteger(l, d2);

				lua_pushinteger(l, b1);
				lua_pushinteger(l, b2);

				return 4;
			}
			else
				lua_pushnil(l);

			return 1;
		}

		const luaL_Reg input[] =
		{
			{ "__index", &Index },
			{ "KeyState", &GetKeyState },
			{ "MouseButton", &GetMouseButton },
			{ "JoystickButton", &GetJoystickButton },
			{ "ClearKeyBuffer", &ClearKeyBuffer },
			{ "JoystickDirection", &GetJoystickDirection },
			{ 0, 0 }
		};
	}
}
