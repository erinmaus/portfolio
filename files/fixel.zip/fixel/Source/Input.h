#ifndef INPUT_H_
#define INPUT_H_

#include <allegro.h>
#include <map>
#include <string>

#include "IManager.h"
#include "Point.h"

class Game;

enum InputState
{
	InputCurrent = 0,
	InputPrevious = 1,
	InputStateMax = 2
};

enum ButtonState
{
	ButtonPressed = 0,
	ButtonReleased = 1,
	ButtonNotHeld = 2,
	ButtonHeld = 3,
	ButtonMax = 4
};

enum MouseButton
{
	MouseButtonLeft = 1,
	MouseButtonRight = 2,
	MouseButtonMiddle = 4
};

enum Direction
{
	DirectionUp = 0,
	DirectionDown,
	DirectionLeft,
	DirectionRight,
	DirectionMax
};

enum ControlType
{
	ControlKeyboard = 0,
	ControlJoystick,
	ControlMax
};

struct JoystickButtons
{
	int Total;
	bool * Buttons;

	void Initialize(int joystick); /* Initializes the structure by allocating the buttons. */
	void Copy(struct JoystickButtons& to); /* Copies the state data to another structure. */
	void Update(int joystick); /* Updates the buttons according to the Allegro joystick button state. */
};

struct JoystickDStick
{
	bool Directions[DirectionMax];

	void Copy(struct JoystickDStick& to);
	void Update(int joystick);
};

struct Control
{
	ControlType Type;
	int Button; /* A negative value when `Type' is `ControlJoystick' will go in this order:
					Up (-1), Down (-2), Left (-3), Right (-4). */

	Control(void) : Type(ControlKeyboard), Button(0) { }
	Control(ControlType t, int b) : Type(t), Button(b) { }
};

struct Controls
{
	std::map<std::string, Control *> Buttons;

	Controls(const std::string& filename);
	~Controls(void);

	void SaveToFile(const std::string& filename);
};

class Input : public IManager
{
	private:
		char keys[InputStateMax][KEY_MAX]; /* The key states. */

		Point mousePosition[InputStateMax]; /* The mouse position states. */
		int mouseButtons[InputStateMax]; /* The mouse buttons. */

		int joystickTotal; /* The total amount of joysticks. */
		JoystickButtons ** joysticks; /* The buttons on the joysticks. */
		JoystickDStick ** dSticks; /* The joystick's `digital' sticks. */

	public:
		Input(class Game * game) : IManager(game), joysticks(0), dSticks(0) { }
		~Input(void);

		/* Initialization. */
		void Initialize(void);

		/* Update. */
		void Update(bool firstLogicRun);

		/* Handling various input states. */
		ButtonState Get_KeyState(int index) const;
		int Get_AnyKey(void) const;

		int Get_MouseButtons(InputState state) const;
		ButtonState Get_MouseButton(MouseButton button) const;

		bool Get_MouseMoved(void) const { return (mousePosition[InputPrevious].X != mousePosition[InputCurrent].X || mousePosition[InputPrevious].Y != mousePosition[InputCurrent].Y); }
		Point Get_MouseDifference(void) const { return Point(mousePosition[InputPrevious] - mousePosition[InputCurrent]); }
		Point Get_MousePosition(InputState state) const { return mousePosition[state]; }

		/* Joystick button state. */
		ButtonState Get_JoystickButton(int joystick, int button) const;
		int Get_JoystickButton(int joystick) const;

		/* Joystick digital stick. */
		void Get_DStickState(int joystick, Direction& d1, Direction& d2, ButtonState& b1, ButtonState& b2) const;

		int Get_JoystickTotal(void) const { return joystickTotal; }

		/* Functions to handle accessing and so on. */
		ButtonState operator[](int index) const { return Get_KeyState(index); }
};

#endif
