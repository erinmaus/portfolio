#ifndef POINT_H_
#define POINT_H_

struct Point
{
	int X, Y; /* The x and y of the point. */

	Point(void) : X(0), Y(0) { }
	Point(int x, int y) : X(x), Y(y) { }
	Point(const struct Point& point) : X(point.X), Y(point.Y) { }

	/* Some operators. */
	inline Point operator +(const struct Point& p) const { return Point(X + p.X, Y + p.Y); }
	inline Point operator -(const struct Point& p) const { return Point(X - p.X, Y - p.Y); }
	inline Point operator *(const struct Point& p) const { return Point(X * p.X, Y * p.Y); }
	inline Point operator /(const struct Point& p) const { return Point(X / p.X, Y / p.Y); }
	inline bool operator==(const struct Point& p) const { return (X == p.X && Y == p.Y); }
	inline bool operator <(const struct Point& p) const { return (X < p.X && Y < p.Y); }
	inline bool operator<=(const struct Point& p) const { return (X <= p.X && Y <= p.Y); }
};

#endif
