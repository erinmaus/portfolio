#ifndef FONT_H_
#define FONT_H_

#include <allegro.h>
#include <string>

class Bitmap;

/* The types of ways to draw the font. Note: justification requires you to call DrawJustified. */
enum FontDrawType
{
	FontDrawLeft = 0,
	FontDrawRight = 1,
	FontDrawCentered = 2,
	FontDrawMax
};

class Font
{
	private:
		FONT * font;
		bool shared;

		/* No empty instantation nor copying. */
		Font(const class Font& font) { };

	public:
		Font(const std::string& filename);
		Font(FONT * font, bool share = true);

		~Font(void) { if (!shared) destroy_font(font); };

		/* Font drawing.  Draw justified is exempt from the FontDrawType enumeration and support in Draw() directly,
			because it requires entirely different arguments than the traditional left, right, and centered ones.
			The DraW() functions will throw an exception if `type' is not correct (within bounds). */
		inline void Draw(FontDrawType type, class Bitmap& bitmap, int x, int y, int color, const std::string& text) { Draw(type, bitmap, x, y, color, -1, text); }
		void Draw(FontDrawType type, class Bitmap& bitmap, int x, int y, int color, int bg, const std::string& text);

		inline void DrawJustified(class Bitmap& bitmap, int x, int x2, int y, int diff, int color, const std::string& text) { DrawJustified(bitmap, x, x2, y, diff, color, -1, text); }
		void DrawJustified(class Bitmap& bitmap, int x, int x2, int y, int diff, int color, int bg, const std::string& text);

		/* Some utility functions. */
		inline int MeasureLength(const std::string& text) const { return text_length(font, text.c_str()); }
		inline int MeasureHeight(void) const { return text_height(font); }

		/* Getters. */
		inline FONT * Get_Font(void) const { return font; }
		inline bool Get_IsShared(void) const { return shared; }
};

#endif
