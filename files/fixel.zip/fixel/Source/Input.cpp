#include <allegro.h>
#include <sstream>
#include <tinyxml.h>

#include "Exception.h"
#include "Game.h"
#include "Input.h"
#include "Loggy.h"
#include "Point.h"

/* This allocates the buttons and sets all of them to false.  It does not keep the joystick it is
	`registered' to, however. */
void JoystickButtons::Initialize(int joystick)
{
	Total = joy[joystick].num_buttons;

	Buttons = new bool[Total];

	for (int i = 0; i < Total; i++)
		Buttons[i] = false;
}

/* Copies the current joystick state information to the provided one. They must have the same amount
	of buttons, however. */
void JoystickButtons::Copy(JoystickButtons& to)
{
	if (to.Total != Total)
		throw Exception("The copy-to joystick does not have the same amount of buttons.", "Logic error?");

	for (int i = 0; i < Total; i++)
		to.Buttons[i] = Buttons[i];
}

/* Updates all the buttons on the joystick.  If the joystick does *not* have the same amount of buttons,
	this function will throw an exception. */
void JoystickButtons::Update(int joystick)
{
	if (joy[joystick].num_buttons != Total)
		throw Exception("The 'registered' joystick somehow has a different amount of buttons.", "Logic error?");

	for (int i = 0; i < Total; i++)
		Buttons[i] = joy[joystick].button[i].b;
}

void JoystickDStick::Copy(JoystickDStick& to)
{
	for (int i = 0; i < DirectionMax; i++)
		to.Directions[i] = Directions[i];
}

void JoystickDStick::Update(int joystick)
{
	Directions[DirectionUp] = joy[joystick].stick[0].axis[1].d1;
	Directions[DirectionDown] = joy[joystick].stick[0].axis[1].d2;
	Directions[DirectionLeft] = joy[joystick].stick[0].axis[0].d1;
	Directions[DirectionRight] = joy[joystick].stick[0].axis[0].d2;
}

/* Loads the controls from an XML document. */
Controls::Controls(const std::string& filename)
{
	TiXmlDocument f(filename);

	if (!f.LoadFile())
		throw Exception(filename + " couldn't be loaded.", "Invalid permissions? Missing file?");

	TiXmlHandle h(&f);

	TiXmlElement * e = h.FirstChildElement("Controls").Element();

	if (!e)
		throw Exception(filename + " is missing the root element.", "Syntax error?");

	TiXmlHandle root(e);

	for (TiXmlElement * e = root.FirstChildElement("Control").Element(); e; e = e->NextSiblingElement())
	{
		const char * name = e->Attribute("Name");
		ControlType t;
		int b;

		if (!name)
			throw Exception(filename + " is missing the attribute `Name'.", "Syntax error?");

		if (e->QueryIntAttribute("Type", (int *)&t) != TIXML_SUCCESS)
			throw Exception("Failed to read `Type' attribute.", "Syntax error?");

		if (e->QueryIntAttribute("Button", &b) != TIXML_SUCCESS)
			throw Exception("Failed to read `Button' attribute.", "Syntax error?");

		Buttons[name] = new Control(t, b);
	}
}

Controls::~Controls(void)
{
	for (std::map<std::string, Control *>::iterator i = Buttons.begin(); i != Buttons.end(); i++)
	{
		delete (*i).second;
		Buttons.erase(i);
	}
}

/* Saves the controls to an XML document. */
void Controls::SaveToFile(const std::string& filename)
{
	TiXmlDocument f;
	TiXmlDeclaration * declaration = new TiXmlDeclaration("1.0", "", "");

	f.LinkEndChild(declaration);

	TiXmlElement * root = new TiXmlElement("Controls");
	f.LinkEndChild(root);

	for (std::map<std::string, Control *>::iterator i = Buttons.begin(); i != Buttons.end(); i++)
	{
		Control * con = (*i).second;
		const std::string& s = (*i).first;

		TiXmlElement * c = new TiXmlElement("Control");
		c->SetAttribute("Name", s);
		c->SetAttribute("Type", (int)con->Type);
		c->SetAttribute("Button", con->Button);

		root->LinkEndChild(c);
	}

	f.SaveFile(filename);
}

/* Initializes the input manager by allocating the joystick buttons and then, in turn, initializing them. */
void Input::Initialize(void)
{
	Get_Game()->Get_Loggy()->Write(0, "Initializing input handler...\n");

	if (num_joysticks > 0)
	{
		std::stringstream s;
		s << "Found " << num_joysticks << ((num_joysticks > 1) ? " joysticks.\n" : " joystick.\n");

		Get_Game()->Get_Loggy()->Write(0, s.str());

		joystickTotal = num_joysticks;

		joysticks = new JoystickButtons*[joystickTotal];

		for (int i = 0; i < joystickTotal; i++)
			joysticks[i] = new JoystickButtons[InputStateMax];

		for (int i = 0; i < joystickTotal; i++)
			for (int j = 0; j < InputStateMax; j++)
				joysticks[i][j].Initialize(i);

		dSticks = new JoystickDStick*[joystickTotal];

		for (int i = 0; i < joystickTotal; i++)
			dSticks[i] = new JoystickDStick[InputStateMax];

		for (int i = 0; i < joystickTotal; i++)
			for (int j = 0; j < InputStateMax; j++)
				for (int k = 0; k < DirectionMax; k++)
					dSticks[i][j].Directions[k] = 0;
	}
	else
	{
		joystickTotal = 0;
		Get_Game()->Get_Loggy()->Write(0, "Found no joysticks.\n");
	}

	/* Set everything else to default. */
	for (int i = 0; i < InputStateMax; i++)
		for (int j = 0; j < KEY_MAX; j++)
			keys[i][j] = 0;

	for (int i = 0; i < InputStateMax; i++)
	{
		mousePosition[i].X = 0;
		mousePosition[i].Y = 0;

		mouseButtons[i] = 0;
		mouseButtons[i] = 0;
	}
}

/* Updates all the positions and similiar. */
void Input::Update(bool firstLogicRun)
{
	/* Poll the joystick. */
	if(poll_joystick() != 0)
		throw Exception("Joystick could not be polled.", "Was the joystick installed?");

	/* Update the joystick. */
	for (int i = 0; i < joystickTotal; i++)
	{
		joysticks[i][InputCurrent].Copy(joysticks[i][InputPrevious]);
		joysticks[i][InputCurrent].Update(i);

		dSticks[i][InputCurrent].Copy(dSticks[i][InputPrevious]);
		dSticks[i][InputCurrent].Update(i);
	}

	/* Updates the mouse X and Y. */
	mousePosition[InputPrevious].X = mousePosition[InputCurrent].X;
	mousePosition[InputPrevious].Y = mousePosition[InputCurrent].Y;

	mousePosition[InputCurrent].X = mouse_x;
	mousePosition[InputCurrent].Y = mouse_y;

	/* Update the mouse buttons. */
	mouseButtons[InputPrevious] = mouseButtons[InputCurrent];
	mouseButtons[InputCurrent] = mouse_b;

	/* Update the keys. */
	for (int i = 0; i < KEY_MAX; i++)
	{
		keys[InputPrevious][i] = keys[InputCurrent][i];
		keys[InputCurrent][i] = key[i];
	}
}

/* Cleans up all the allocated memory, like it should. */
Input::~Input(void)
{
	for (int i = 0; i < joystickTotal; i++)
		delete[] joysticks[i];

	if (joysticks)
		delete[] joysticks;
}

/* Returns a state based on a key press.  These states are either "just pressed",
	"just released", or "[not] held". */
ButtonState Input::Get_KeyState(int index) const
{
	if (index <= -1 || index >= KEY_MAX)
		throw Exception("Key attempted to be accessed was out of bounds.", "Logic error?");

	if (!keys[InputPrevious][index] && !keys[InputCurrent][index])
		return ButtonNotHeld;
	else if (keys[InputPrevious][index] && keys[InputCurrent][index])
		return ButtonHeld;
	else if (!keys[InputPrevious][index] && keys[InputCurrent][index])
		return ButtonPressed;
	else
		return ButtonReleased;
}

/* Gets the button that was just pressed this update and returns it.  If no button is found, a number < 0 is
	returned. */
int Input::Get_AnyKey(void) const
{
	for (int i = 0; i < KEY_MAX; i++)
		if (Get_KeyState(i) == ButtonPressed)
			return i;

	return -1;
}

/* Returns the mouse button complete integer according to the state.  It will throw an exception if
	`state' is invalid. */
int Input::Get_MouseButtons(InputState state) const
{
	if (state > InputPrevious)
		throw Exception("Trying to access a state for the mouse buttons that does not exist.", "Logic error?");

	return mouseButtons[state];
}

/* Gets the state for the given mouse button, and returns it. */
ButtonState Input::Get_MouseButton(MouseButton button) const
{
	if (!(mouseButtons[InputPrevious] & button) && !(mouseButtons[InputCurrent] & button))
		return ButtonNotHeld;
	else if (mouseButtons[InputPrevious] & button && mouseButtons[InputCurrent] & button)
		return ButtonHeld;
	else if (!(mouseButtons[InputPrevious] & button) && mouseButtons[InputCurrent] & button)
		return ButtonPressed;
	else
		return ButtonReleased;
}

/* Gets the state of a button in the joystick.  If either `joystick' or `button' is out of bounds, then
	it will throw an exception. */
ButtonState Input::Get_JoystickButton(int joystick, int button) const
{
	if (joystick >= joystickTotal || button >= joysticks[joystick][InputCurrent].Total)
		throw Exception("Out of bounds joystick index or button index.", "Logic error?");

	if (!joysticks[joystick][InputPrevious].Buttons[button] && !joysticks[joystick][InputCurrent].Buttons[button])
		return ButtonNotHeld;
	else if (joysticks[joystick][InputPrevious].Buttons[button] && joysticks[joystick][InputCurrent].Buttons[button])
		return ButtonHeld;
	else if (!joysticks[joystick][InputPrevious].Buttons[button] && joysticks[joystick][InputCurrent].Buttons[button])
		return ButtonPressed;
	else
		return ButtonReleased;
}

/* Gets a button that was just pressed on the provided joystick.  If the joystick is out of bounds, then an
	exception will be thrown.  It will return a number < 0 if no button was just pressed. */
int Input::Get_JoystickButton(int joystick) const
{
	if (joystick > joystickTotal)
		throw Exception("Out of bounds joystick.", "Logic error?");

	for (int i = 0; i < joysticks[joystick][0].Total; i++)
	{
		if (Get_JoystickButton(joystick, i) == ButtonPressed)
			return i;
	}

	return -1;
}

#define SetButtonState(dir, but) { \
	if (!dSticks[joystick][InputCurrent].Directions[dir] && !dSticks[joystick][InputPrevious].Directions[dir]) \
		but = ButtonNotHeld; \
	else if (dSticks[joystick][InputCurrent].Directions[dir] && dSticks[joystick][InputPrevious].Directions[dir]) \
		but = ButtonHeld; \
	else if (!dSticks[joystick][InputCurrent].Directions[dir] && dSticks[joystick][InputPrevious].Directions[dir]) \
		but = ButtonReleased; \
	else \
		but = ButtonPressed; } \

void Input::Get_DStickState(int joystick, Direction& d1, Direction& d2, ButtonState& b1, ButtonState& b2) const
{
	if (joystick > joystickTotal)
		throw Exception("Out of bounds joystick.", "Logic error?");

	if (dSticks[joystick][InputCurrent].Directions[DirectionUp])
		d1 = DirectionUp;
	else if (dSticks[joystick][InputCurrent].Directions[DirectionDown])
		d1 = DirectionDown;
	else
	{
		d1 = DirectionMax;
		b1 = ButtonNotHeld;
	}

	if (dSticks[joystick][InputCurrent].Directions[DirectionLeft])
		d2 = DirectionLeft;
	else if (dSticks[joystick][InputCurrent].Directions[DirectionRight])
		d2 = DirectionRight;
	else
	{
		d2 = DirectionMax;
		b2 = ButtonNotHeld;
	}

	SetButtonState(d1, b1);
	SetButtonState(d2, b2);
}

#undef SetButtonState
