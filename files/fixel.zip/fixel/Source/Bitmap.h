#ifndef F_BITMAP_H_
#define F_BITMAP_H_

#include <allegro.h>
#include <string>

#include "Point.h"
#include "Rectangle.h"

enum PrimitiveMode
{
	PrimitiveModeLined = 0,
	PrimitiveModeFilled,
	PrimitiveModeTotal
};

class Bitmap
{
	private:
		bool shared;
		BITMAP * bitmap;
		Rectangle clipping;

		/* No copying allowed.  Sorry. :( */
		Bitmap(const class Bitmap& b) { }

		/* This initializes the clipping region and is called by every constructor. */
		void InitializeClippingRegion(void);

	public:
		/* This constructs a bitmap from another bitmap.  The reason `share' defaults to true is because, if an Allegro bitmap
			is passed as a Bitmap, it will call this constructor and when it is destroyed, will *not* destroy the bitmap. */
		Bitmap(BITMAP * b, bool share = true);
		Bitmap(int w, int h, int color = 0);
		Bitmap(const std::string& filename);

		~Bitmap(void) { if (!shared) destroy_bitmap(bitmap); }

		/* This clears the bitmap with the specified color, or black if none is specified. */
		void Clear(int color = 0);

		/* This function simply blits this bitmap to another. */
		inline void BlitTo(class Bitmap& b) { blit(bitmap, b.Get_Bitmap(), 0, 0, 0, 0, bitmap->w, bitmap->h); }

		/* This blits the bitmap to another with the specified x, y, width, and height. */
		inline void BlitTo(class Bitmap& b, int x, int y, int w, int h) { blit(bitmap, b.Get_Bitmap(), x, y, 0, 0, w, h); }

		/* This acts just like Allegro's blit(). */
		inline void BlitTo(class Bitmap& b, int x, int y, int dx, int dy, int w, int h) { blit(bitmap, b.Get_Bitmap(), x, y, dx, dy, w, h); }

		/* This is magical. */
		void DrawTrans(class Bitmap& to, int x, int y);

		/* Draws a rectangle. */
		void DrawPrimitive(const Rectangle& r, PrimitiveMode m, int c);
		inline void DrawPrimitive(const Point& p, int c) { putpixel(bitmap, p.X, p.Y, c); }
		inline void DrawPrimitive(const Point& p1, const Point& p2, int c) { line(bitmap, p1.X, p1.Y, p2.X, p2.Y, c); }

		/* Gets the bitmap's width and height. */
		inline int Get_Width(void) const { return bitmap->w; }
		inline int Get_Height(void) const { return bitmap->h; }

		/* Gets and sets the bitmap's clipping rectangle. */
		inline Rectangle Get_ClippingRegion(void) const { return clipping; }
		void Set_ClippingRegion(const Rectangle& r);

		/* The most important function allows...DNA interpolated! */
		BITMAP * Get_Bitmap(void) const { return bitmap; }
};

#endif
