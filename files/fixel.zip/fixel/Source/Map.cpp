#include <allegro.h>
#include <string>

#include "Bitmap.h"
#include "Exception.h"
#include "File.h"
#include "Map.h"

Map::Map(int w, int h)
	: width(w), height(h)
{
	tiles = new Tile[width * height];

	for (int i = 0; i < width * height; i++)
	{
		tiles[i].Index = 0;
		tiles[i].Flags = 0;
	}
}

Map::Map(const std::string& filename)
{
	File f(filename, FileModeRead, true);

	if (f.ReadInteger() != MagicNumber)
		throw Exception("Not a map file.", "Wrong file?");

	int version = f.ReadInteger();

	if (version < Version)
		throw Exception("Older map version.", "Wrong file?");
	else if (version > Version)
		throw Exception("Newer map version.", "Wrong file?");

	width = f.ReadInteger();

	if (width == 0)
		throw Exception("Width cannot be zero.", "Wrong file?");

	height = f.ReadInteger();

	if (height == 0)
		throw Exception("Height cannot be zero.", "Wrong file?");

	tiles = new Tile[width * height];

	for (int i = 0; i < width * height; i++)
	{
		tiles[i].Index = f.ReadInteger();
		tiles[i].Flags = f.ReadInteger();
	}
}

Map::~Map(void)
{
	delete[] tiles;
}

void Map::SaveToFile(const std::string &filename) const
{
	File f(filename, FileModeWrite, true);

	f.Write(MagicNumber);
	f.Write(Version);

	f.Write((int)width);
	f.Write((int)height);

	for (int i = 0; i < width * height; i++)
	{
		f.Write((int)tiles[i].Index);
		f.Write(tiles[i].Flags);
	}
}
