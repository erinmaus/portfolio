#include "Bitmap.h"
#include "Exception.h"
#include "FLua.h"
#include "Font.h"
#include "Point.h"

namespace FLua
{
	namespace FFont
	{
		/* Library functions. */
		int Create(lua_State * l)
		{
			Font * f;

			try
			{
				f = new Font(luaL_checkstring(l, 1));
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s (%s)", e.Get_Reason().c_str(), e.Get_Sub().c_str());
			}

			ToLua(l, f, false, "Font");

			return 1;
		}

		const luaL_Reg fontLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		/* Metatable functions. */
		int ToString(lua_State * l)
		{
			lua_pushfstring(l, "font: %p", FromLua(l, 1, true, "Font")->Data);

			return 1;
		}

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Font");

			if (!(o->Shared))
				delete (Font *)o->Data;

			return 1;
		}

		int Index(lua_State * l)
		{
			Font * f = (Font *)FromLua(l, 1, false, "Font")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Height")
				lua_pushinteger(l, f->MeasureHeight());
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		/* Ze actual functions, no? */
		int Draw(lua_State * l)
		{
			Font * f = (Font *)FromLua(l, 1, false, "Font")->Data;
			Bitmap * b = (Bitmap *)FromLua(l, 2, false, "Bitmap")->Data;
			FontDrawType t = (FontDrawType)luaL_checkinteger(l, 3);

			try
			{
				switch(lua_gettop(l))
				{
					case 6:
						{
							Point * p = (Point *)FromLua(l, 4, false, "Point")->Data;
							f->Draw(t, *b, p->X, p->Y, luaL_checkinteger(l, 5), luaL_checkstring(l, 6));
						}
						break;

					case 7:
						if (IsType(l, 4, "Point"))
						{
							Point * p = (Point *)FromLua(l, 4, false, "Point")->Data;
							f->Draw(t, *b, p->X, p->Y, luaL_checkinteger(l, 5), luaL_checkinteger(l, 6), luaL_checkstring(l, 7));
						}
						else
						{
							f->Draw(t, *b, luaL_checkinteger(l, 4), luaL_checkinteger(l, 5), luaL_checkinteger(l, 6), luaL_checkstring(l, 7));
						}
						break;

					case 8:
						f->Draw(t, *b, luaL_checkinteger(l, 4), luaL_checkinteger(l, 5), luaL_checkinteger(l, 6), luaL_checkinteger(l, 7), luaL_checkstring(l, 8));
						break;

					default:
						luaL_error(l, "invalid arguments");
				}
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s (%s)", e.Get_Reason().c_str(), e.Get_Sub().c_str());
			}

			return 0;
		}

		int DrawJustified(lua_State * l)
		{
			Font * f = (Font *)FromLua(l, 1, false, "Font")->Data;
			Bitmap * b = (Bitmap *)FromLua(l, 1, false, "Bitmap")->Data;

			switch(lua_gettop(l))
			{
				/* No point because each function requires two X-variables. */
				case 8:
					f->DrawJustified(*b, luaL_checkinteger(l, 3), luaL_checkinteger(l, 4), luaL_checkinteger(l, 5), luaL_checkinteger(l, 6), luaL_checkinteger(l, 7), luaL_checkstring(l, 8));
					break;

				case 9:
					f->DrawJustified(*b, luaL_checkinteger(l, 3), luaL_checkinteger(l, 4), luaL_checkinteger(l, 5), luaL_checkinteger(l, 6), luaL_checkinteger(l, 7), luaL_checkinteger(l, 8), luaL_checkstring(l, 9));
					break;
			}

			return 0;
		}

		int Measure(lua_State * l)
		{
			Font * f = (Font *)FromLua(l, 1, false, "Font")->Data;

			lua_pushinteger(l, f->MeasureLength(luaL_checkstring(l, 2)));

			return 1;
		}

		const luaL_Reg font[] =
		{
			{ "__tostring", &ToString },
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "Draw", &Draw },
			{ "DrawJustified", &DrawJustified },
			{ "Measure", &Measure },
			{ 0, 0 }
		};
	}
}
