#ifndef F_SCREEN_H_
#define F_SCREEN_H_

#include <string>

class Bitmap;
class Input;
class Screeny;

class Screen
{
	private:
		bool isPopup; /* If the screen is a popup--if it is, then underlying screens will still get the draw and update commands, but not the input. */

		std::string name; /* The name of the screen, for other screens to access. */

		class Screeny * manager; /* The manager this screen belongs to. */

		/* No copying. */
		Screen(const class Screen& screen) { }

	public:
		/* Constructor and destructor. */
		Screen(class Screeny * manager) : manager(manager) { }
		virtual ~Screen(void) { }

		/* Set various things. */
		void Set_IsPopup(bool isPopup) { this->isPopup = isPopup; }
		void Set_Name(const std::string& name) { this->name = name; }

		/* Get the screen manager. */
		inline class Screeny * Get_Screeny(void) const { return manager; }

		/* Get/set various things. */
		inline bool Get_IsPopup(void) const { return isPopup; }
		inline const std::string& Get_Name(void) const { return name; }

		/* Initializes the screen.  This is called after it is added to the main screen list in Screeny.
			It is then safe to load graphics, sounds, fonts, and so on without worry. */
		virtual void Initialize(void) { }

		/* Updates the screen.  This is called whenever a screen is visible (for example, it is not covered,
			or it is covered by a popup). This function is required to be overridden. */
		virtual void Update(bool covered, bool inFocus) { }

		/* Handles the screen's input.  This is the only place input should be handled, because no input is
			given if the screen is covered by another (a popup or not). */
		virtual void HandleInput(class Input& input) { }

		/* This draws the screen.  All drawing should be done directly to the provided bitmap and nowhere else,
			because the screen manager may use a different bitmap, depending on its implementation. This is
			called if the screen is covered by a popup, too. */
		virtual void Draw(class Bitmap& bitmap) { }
};

#endif
