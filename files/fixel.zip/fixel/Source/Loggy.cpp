#include <cstdio>
#include <map>
#include <string>
#include <vector>

#include "Exception.h"
#include "Loggy.h"

Loggy::~Loggy(void)
{
	while (logsByIndex.size() > 0)
	{
		fclose(logsByIndex[logsByIndex.size() - 1]);
		logsByIndex.pop_back();
	}

	logsByName.clear();
}

int Loggy::AddLog(const std::string& filename, const std::string& header)
{
	std::string complete = absolutePath + "Logs/" + filename + ".log"; /* The complete path. */
	FILE * f = fopen(complete.c_str(), "w");

	if (!f)
		throw DeadlyException(complete + " could not be opened.", "Out of memory? Invalid write permissions?");

	fprintf(f, header.c_str());
	fflush(f);

	logsByName[filename] = f;
	logsByIndex.push_back(f);

	return logsByIndex.size() - 1;
}

void Loggy::Write(const std::string &log, const std::string &message)
{
	FILE * f = logsByName[log];

	fprintf(f, message.c_str());
	fflush(f);
}

void Loggy::Write(unsigned int log, const std::string &message)
{
	FILE * f = logsByIndex[log];

	fprintf(f, message.c_str());
	fflush(f);
}
