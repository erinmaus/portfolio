#include "FLua.h"
#include "Map.h"
#include "Shader.h"
#include "Stage.h"

Shader::Shader(lua_State * l, const std::string& filename)
	: luaState(l)
{
	reference = FLua::DoFile(l, filename);
}

Shader::~Shader(void)
{
	SaveStack(luaState);

	lua_getglobal(luaState, FLua::GlobalTable);
	luaL_unref(luaState, -1, reference);

	RestoreStack(luaState);
}

void Shader::Shade(SMap& m)
{
	SaveStack(luaState);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, reference);

	for (int x = 0; x < m.Get_Width(); x++)
		for (int y = 0; y < m.Get_Height(); y++)
		{
			lua_getfield(luaState, -1, "Shade");
			FLua::ToLua(luaState, &m.Get_TileAtXY(x, y), true, "SMapTile");

			if (lua_pcall(luaState, 1, 0, 0) != 0)
				throw Exception(lua_tostring(luaState, -1), "Syntax error?");
		}

	RestoreStack(luaState);
}
