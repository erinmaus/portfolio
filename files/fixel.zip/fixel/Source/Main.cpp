#include <allegro.h>
#include <exception>
#include <string>
#include <sstream>
#include <vector>

#include "Exception.h"
#include "Game.h"
#include "Loggy.h"

int main(int argumentTotal, char ** arguments)
{
	std::vector<std::string> args;
	Game * game;

	for (int i = 0; i < argumentTotal; i++)
		args.push_back(arguments[i]);

	game = new Game(args);

	try
	{
		game->Initialize();
	}
	catch (const DeadlyException& e)
	{
		set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
		allegro_message("Fixel could not be initialized!\nReason: %s [%s]", e.Get_Reason().c_str(), e.Get_Sub().c_str());

		return -1;
	}
	catch (const Exception& e)
	{
		std::stringstream ss;

		ss << "Couldn't initialize game.\n" << e.Get_Reason() << " (" << e.Get_Sub() << ")\n";

		game->Get_Loggy()->Write(0, ss.str());

		return 1;
	}
	catch (const std::exception& e)
	{
		game->Get_Loggy()->Write(0, e.what());

		return 1;
	}

	game->Get_Loggy()->Write(0, "Game initialized.\nRunning game...\n");

	try
	{
		game->Run();
	}
	catch (const Exception& e)
	{
		std::stringstream ss;

		ss << "Couldn't run game.\n" << e.Get_Reason() << " (" << e.Get_Sub() << ")\n";

		game->Get_Loggy()->Write(0, ss.str());

		return 1;
	}
	catch (const std::exception& e)
	{
		game->Get_Loggy()->Write(0, e.what());

		return 1;
	}

	game->Get_Loggy()->Write(0, "Game finished.\n");

	delete game;

	return 0;
}
END_OF_MAIN()
