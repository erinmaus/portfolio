#include <exception>

#include "Exception.h"
#include "FLua.h"
#include "Map.h"
#include "Shader.h"
#include "Stage.h"
#include "State.h"
#include "TileSheet.h"

namespace FLua
{
	namespace FStage
	{
		int Create(lua_State * l)
		{
			Stage * s;
			LuaObject * o = FromLua(l, 1, false, "State");

			try
			{
				s = new Stage(l, (State *)o->Data, luaL_checkstring(l, 2));
			}
			catch (const Exception& e)
			{
				luaL_error(l, e.what());
			}

			ToLua(l, s, false, "Stage");

			return 1;
		}

		const luaL_Reg stageLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Stage");

			if (!(o->Shared))
				delete (Stage *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			Stage * s = (Stage *)FromLua(l, 1, false, "Stage")->Data;
			std::string key = luaL_checkstring(l, -1);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;
			
			if (key == "Objector")
				ToLua(l, s->Get_Objector(), true, "Objector");
			else if (key == "TileWidth")
				lua_pushinteger(l, s->Get_TileWidth());
			else if (key == "TileHeight")
				lua_pushinteger(l, s->Get_TileHeight());
			else if (key == "Camera")
			{
				ToLua(l, new Rectangle(s->Get_CameraXY().X, s->Get_CameraXY().Y, s->Get_CameraWidth(), s->Get_CameraHeight()), false, "Rectangle");
			}
			else if (key == "CameraXY")
			{
				Point * p = new Point(s->Get_CameraXY());

				ToLua(l, p, false, "Point");
			}
			else if (key == "CameraWidth")
				lua_pushinteger(l, s->Get_CameraWidth());
			else if (key == "CameraHeight")
				lua_pushinteger(l, s->Get_CameraHeight());
			else if (key == "Map")
				ToLua(l, s->Get_Map(), true, "Map");
			else if (key == "State")
				ToLua(l, s->Get_State(), true, "State");
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		/* Functions. */
		int Update(lua_State * l)
		{
			Stage * s = (Stage *)FromLua(l, 1, false, "Stage")->Data;

			try
			{
				s->Update(luaL_checknumber(l, 2));
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		int Draw(lua_State * l)
		{
			Stage * s = (Stage *)FromLua(l, 1, false, "Stage")->Data;
			Bitmap * b = (Bitmap *)FromLua(l, 2, false, "Bitmap")->Data;
			Point * p = (Point *)FromLua(l, 3, false, "Point")->Data;

			try
			{
				s->Draw(*b, *p);
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		int AddShader(lua_State * l)
		{
			Stage * s = (Stage *)FromLua(l, 1, false, "Stage")->Data;
			Shader * sh = new Shader(l, luaL_checkstring(l, 2));

			s->AddShader(sh);

			return 0;
		}

		int RemoveShader(lua_State * l)
		{
			Stage * s = (Stage *)FromLua(l, 1, false, "Stage")->Data;

			try
			{
				s->RemoveShader(luaL_checkinteger(l, 2));
			}
			catch (const std::exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		int MoveCamera(lua_State * l)
		{
			Stage * s = (Stage *)FromLua(l, 1, false, "Stage")->Data;

			s->MoveCamera(luaL_checkinteger(l, 2), luaL_checkinteger(l, 3));

			return 0;
		}

		int SetCameraXY(lua_State * l)
		{
			Stage * s = (Stage *)FromLua(l, 1, false, "Stage")->Data;

			s->Set_CameraXY(*((Point *)FromLua(l, 2, false, "Point")->Data));

			return 0;
		}

		int Synchronize(lua_State * l)
		{
			Stage * s = (Stage *)FromLua(l, 1, false, "Stage")->Data;

			s->Synchronize();

			return 0;
		}

		const luaL_Reg stage[] =
		{
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "Update", &Update },
			{ "Draw", &Draw },
			{ "AddShader", &AddShader },
			{ "RemoveShader", &RemoveShader },
			{ "MoveCamera", &MoveCamera },
			{ "SetCameraXY", &SetCameraXY },
			{ "Synchronize", &Synchronize },
			{ 0, 0 }
		};
	}

	namespace FTileSheet
	{
		int Create(lua_State * l)
		{
			TileSheet * t;

			if (lua_gettop(l) > 0)
			{
				try
				{
					t = new TileSheet(luaL_checkstring(l, 1));
				}
				catch (const Exception& e)
				{
					luaL_error(l, "%s", e.what());
				}
			}
			else
				t = new TileSheet();

			ToLua(l, t, false, "TileSheet");

			return 1;
		}

		const luaL_Reg tsLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "TileSheet");

			if (!(o->Shared))
				delete (TileSheet *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			TileSheet * t = (TileSheet *)FromLua(l, 1, false, "TileSheet")->Data;

			if (lua_type(l, 1) == LUA_TNUMBER)
			{
				int index = luaL_checkinteger(l, 2);

				try
				{
					ToLua(l, t->Get_TileAtAsPointer((index < 0) ? 0 : index), true, "TileSheetTile");
				}
				catch (const Exception& e)
				{
					luaL_error(l, "%s", e.what());
				}
			}
			else
			{
				std::string key = luaL_checkstring(l, 2);

				lua_getmetatable(l, 1);
				lua_getfield(l, -1, key.c_str());

				if (!lua_isnil(l, -1))
					return 1;
				
				if(key == "Total")
					lua_pushinteger(l, t->Get_Total());
				else
					luaL_error(l, "%s is an invalid index", key.c_str());
			}

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			TileSheet * t = (TileSheet *)FromLua(l, 1, false, "TileSheet")->Data;
			int index = luaL_checkinteger(l, 2);

			if (lua_isnil(l, 3))
			{
				try
				{
					t->RemoveTileAt((index < 0) ? 0 : index);
				}
				catch (const Exception& e)
				{
					luaL_error(l, "%s", e.what());
				}
			}
			else
			{
				TileSheet::Tile * tile = (TileSheet::Tile *)FromLua(l, 3, false, "TileSheet")->Data;

				t->Set_TileAt((index < 0) ? 0 : index, new TileSheet::Tile(*tile));
			}

			return 0;
		}

		int Add(lua_State * l)
		{
			TileSheet * t = (TileSheet *)FromLua(l, 1, false, "TileSheet")->Data;
			TileSheet::Tile * tile = (TileSheet::Tile *)FromLua(l, 2, false, "TileSheetTile")->Data;

			t->AddTile(*tile);

			return 0;
		}

		int SaveToFile(lua_State * l)
		{
			TileSheet * t = (TileSheet *)FromLua(l, 1, false, "TileSheet")->Data;

			try
			{
				t->SaveToFile(luaL_checkstring(l, 2));
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		const luaL_Reg ts[] =
		{
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "Add", &Add },
			{ "SaveToFile", &SaveToFile },
			{ 0, 0 }
		};
	}

	namespace FTileSheetTile
	{
		int Create(lua_State * l)
		{
			TileSheet::Tile * t = new TileSheet::Tile();

			if (lua_gettop(l) > 1)
			{
				t->Border = luaL_checkinteger(l, 1);
				t->Inner = luaL_checkinteger(l, 2);
			}
			
			if (lua_gettop(l) > 2)
			{
				int i = luaL_checkinteger(l, 3);

				t->Next = (i < 0) ? 0 : i;
			}

			if (lua_gettop(l) > 3)
			{
				t->Speed = luaL_checknumber(l, 4);
			}

			ToLua(l, t, false, "TileSheetTile");

			return 1;
		}

		const luaL_Reg tsTileLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "TileSheetTile");

			if (!(o->Shared))
				delete (TileSheet::Tile *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			TileSheet::Tile * t = (TileSheet::Tile *)FromLua(l, 1, false, "TileSheetTile")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Border")
				lua_pushinteger(l, t->Border);
			else if (key == "Inner")
				lua_pushinteger(l, t->Inner);
			else if (key == "Next")
				lua_pushinteger(l, t->Next);
			else if (key == "Speed")
				lua_pushnumber(l, t->Speed);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			TileSheet::Tile * t = (TileSheet::Tile *)FromLua(l, 1, false, "TileSheetTile")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "Border")
				t->Border = luaL_checkinteger(l, 3);
			else if (key == "Inner")
				t->Inner = luaL_checkinteger(l, 3);
			else if (key == "Next")
			{
				int n = luaL_checkinteger(l, 3);

				t->Next = (n < 0) ? 0 : n;
			}
			else if (key == "Speed")
				t->Speed = luaL_checknumber(l, 3);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 0;
		}

		const luaL_Reg tsTile[] =
		{
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ 0, 0 }
		};
	}

	namespace FSMapTile
	{
		int Index(lua_State * l)
		{
			SMap::Tile * t = (SMap::Tile *)FromLua(l, 1, false, "SMapTile")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Border")
				lua_pushinteger(l, t->Border);
			else if (key == "Inner")
				lua_pushinteger(l, t->Inner);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			SMap::Tile * t = (SMap::Tile *)FromLua(l, 1, false, "SMapTile")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "Border")
				t->Border = luaL_checkinteger(l, 3);
			else if (key == "Inner")
				t->Inner = luaL_checkinteger(l, 3);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 0;
		}

		const luaL_Reg smTile[] =
		{
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ 0, 0 }
		};
	}

	namespace FMapTile
	{
		int Index(lua_State * l)
		{
			Map::Tile * t = (Map::Tile *)FromLua(l, 1, false, "MapTile")->Data;
			std::string key = luaL_checkstring(l, 2);

			/* Incase we ever decide to add a function or two. */
			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Index")
				lua_pushinteger(l, t->Index);
			else if (key == "Impassable")
				lua_pushboolean(l, t->Flags & TileImpassable);
			else if (key == "Water")
				lua_pushboolean(l, t->Flags & TileWater);
			else if (key == "Special")
				lua_pushboolean(l, t->Flags & TileSpecial);
			else if (key == "Wall")
				lua_pushboolean(l, t->Flags & TileWall);
			else if (key == "Floor")
				lua_pushboolean(l, t->Flags & TileFloor);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			Map::Tile * t = (Map::Tile *)FromLua(l, 1, false, "MapTile")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "Index")
			{
				int i = luaL_checkinteger(l, 3);
				t->Index = (i < 0) ? 0 : i;
			}
			else if (key == "Impassable")
			{
				if (lua_toboolean(l, 3))
					t->Flags |= TileImpassable;
				else if (t->Flags & TileImpassable)
					t->Flags ^= TileImpassable;
			}
			else if (key == "Water")
			{
				if (lua_toboolean(l, 3))
					t->Flags |= TileWater;
				else if (t->Flags & TileWater)
					t->Flags ^= TileWater;
			}
			else if (key == "Special")
			{
				if (lua_toboolean(l, 3))
					t->Flags |= TileSpecial;
				else if (t->Flags & TileSpecial)
					t->Flags ^= TileSpecial;
			}
			else if (key == "Wall")
			{
				if (lua_toboolean(l, 3))
					t->Flags |= TileWall;
				else if (t->Flags & TileWall)
					t->Flags ^= TileWall;
			}
			else if (key == "Floor")
			{
				if (lua_toboolean(l, 3))
					t->Flags |= TileFloor;
				else if (t->Flags & TileFloor)
					t->Flags ^= TileFloor;
			}
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 0;
		}

		const luaL_Reg mapTile[] =
		{
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ 0, 0 }
		};
	}

	namespace FMap
	{
		int Create(lua_State * l)
		{
			Map * m;

			if (lua_type(l, 1) == LUA_TSTRING)
			{
				try
				{
					m = new Map(luaL_checkstring(l, 1));
				}
				catch (const Exception& e)
				{
					luaL_error(l, "%s", e.what());
				}
			}
			else
			{
				int w = luaL_checkinteger(l, 1), h = luaL_checkinteger(l, 2);
				m = new Map((w < 0) ? 0 : w, (h < 0) ? 0 : h);
			}

			ToLua(l, m, false, "Map");

			return 1;
		}

		const luaL_Reg mapLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Map");

			if (!(o->Shared))
				delete (Map *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			Map * m = (Map *)FromLua(l, 1, false, "Map")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Width")
				lua_pushinteger(l, m->Get_Width());
			else if (key == "Height")
				lua_pushinteger(l, m->Get_Height());
			else if (key == "Version")
				lua_pushinteger(l, Map::Version);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		int GetTileAtXY(lua_State * l)
		{
			Map * m = (Map *)FromLua(l, 1, false, "Map")->Data;
			Point * p = (Point *)FromLua(l, 2, false, "Point")->Data;

			try
			{
				ToLua(l, m->Get_TileAtXYAsPointer(p->X, p->Y), true, "MapTile");
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 1;
		}

		int SaveToFile(lua_State * l)
		{
			Map * m = (Map *)FromLua(l, 1, false, "Map")->Data;

			try
			{
				m->SaveToFile(luaL_checkstring(l, 2));
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 1;
		}

		const luaL_Reg map[] =
		{
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "GetTileAtXY", &GetTileAtXY },
			{ "SaveToFile", &SaveToFile },
			{ 0, 0 }
		};
	}
}
