#include <exception>
#include <sstream>
#include <string>

#include "Bitmap.h"
#include "Exception.h"
#include "Font.h"
#include "FLua.h"
#include "Game.h"
#include "Input.h"
#include "Screeny.h"

namespace FLua
{
	namespace FGame
	{
		/* Metatable! */
		int ToString(lua_State * l)
		{
			std::stringstream ss;

			ss << "Fixel, version " << Game::MajorVersion << "." << Game::MinorVersion << "." << Game::ImportantRevision;

			lua_pushstring(l, ss.str().c_str());

			return 1;
		}

		int Index(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Version")
			{
				std::stringstream ss;

				ss << Game::MajorVersion << "." << Game::MinorVersion << "." << Game::ImportantRevision;

				lua_pushstring(l, ss.str().c_str());
			}
			else if (key == "Loggy")
				ToLua(l, g->Get_Loggy(), true, "Loggy");
			else if (key == "Screeny")
				ToLua(l, g->Get_Screeny(), true, "Screeny");
			else if (key == "Input")
				ToLua(l, g->Get_Input(), true, "Input");
			else if (key == "ScreenWidth")
				lua_pushinteger(l, SCREEN_W);
			else if (key == "ScreenHeight")
				lua_pushinteger(l, SCREEN_H);
			else if (key == "AbsolutePath")
				lua_pushstring(l, g->Get_AbsolutePath().c_str());
			else if (key == "ArgumentTotal")
				lua_pushinteger(l, g->Get_ArgumentTotal());
			else if (key == "Font")
				ToLua(l, g->Get_Font(), true, "Font");
			else if (key == "ShowMouse")
				lua_pushboolean(l, g->Get_ShowMouse());
			else if (key == "IsPaused")
				lua_pushboolean(l, g->Get_IsPaused());
			else if (key == "Controls")
				ToLua(l, g->Get_Controls(), true, "Controls");
			else if (key == "CurrentTime")
				lua_pushnumber(l, g->Get_CurrentTime());
			else if (key == "ElapsedTime")
				lua_pushnumber(l, g->Get_ElapsedTime());
			else if (key == "Options")
				ToLua(l, g->Get_Options(), true, "State");
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "ShowMouse")
				g->Set_ShowMouse(lua_toboolean(l, 3));
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 0;
		}

		/* Functions. */
		int Quit(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;

			g->Quit();

			return 0;
		}

		int GetArgument(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;

			try
			{
				lua_pushstring(l, g->Get_Argument(luaL_checkinteger(l, 2)).c_str());
			}
			catch (const std::exception& e)
			{
				luaL_error(l, "invalid index: %s", e.what());
			}

			return 1;
		}

		int Pause(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;

			g->Pause();

			return 0;
		}

		int Continue(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;

			g->Continue();

			return 0;
		}

		int RegisterObject(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;

			g->RegisterObject(luaL_checkstring(l, 2), luaL_checkstring(l, 3));

			return 0;
		}

		int UnregisterObject(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;

			g->UnregisterObject(luaL_checkstring(l, 2));

			return 0;
		}

		int GetObjectRegisteredPath(lua_State * l)
		{
			Game * g = (Game *)FromLua(l, 1, false, "Game")->Data;

			lua_pushstring(l, g->Get_RegisteredObjectPath(luaL_checkstring(l, 2)).c_str());

			return 1;
		}

		const luaL_Reg game[] =
		{
			{ "__tostring", &ToString },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "Quit", &Quit },
			{ "Argument", &GetArgument },
			{ "Pause", &Pause },
			{ "Continue", &Continue },
			{ "RegisterObject", &RegisterObject },
			{ "UnregisterObject", &UnregisterObject },
			{ "GetObjectRegisteredPath", &GetObjectRegisteredPath },
			{ 0, 0 }
		};
	}
}
