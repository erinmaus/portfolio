#include <allegro.h>
#include <cstdlib>
#include <ctime>
#include <sstream>
#include <vector>

#ifdef ALLEGRO_WINDOWS
	#ifndef WIN32_LEAN_AND_MEAN
		#define WIN32_LEAN_AND_MEAN
	#endif
	#ifndef NOGDI
		#define NOGDI
	#endif
	#include <winalleg.h>
#else
	#include <sys/time.h>
#endif

#include "Bitmap.h"
#include "Exception.h"
#include "Game.h"
#include "Input.h"
#include "FLua.h"
#include "Font.h"
#include "IManager.h"
#include "Loggy.h"
#include "Screeny.h"
#include "State.h"
#include "timer.h"

volatile static int fps = 0; /* To show the FPS. */
volatile static int frames = 0;

static void FramesCounter(void); /* See `fps'. */

volatile bool closeButton = false; /* If the close button was pressed. */

static void CloseButtonCallback(void); /* To quit the game when the close button is pressed. */

Game::Game(std::vector<std::string> args)
	: arguments(args), showMouse(true), controls(0)
{
	/* Maybe I'll do other stuff here.  Maybe not. */
}

Game::~Game(void)
{
	delete input;
	delete screeny;

	/* Delete the bitmaps and fonts. */
	delete buffer;
	delete screen;
	delete defFont;

	lua_close(luaState);

	/* Always free Loggy last. */
	delete loggy;

	/* Save the state. */
	options->SaveToFile(absolutePath + "Data/Game/Options.state");
	delete options;
}

void Game::Initialize(void)
{
	if (allegro_init() != 0)
		throw DeadlyException("Allegro couldn't be initialized.", allegro_error);

	/* Get the executable name. */
	{
		char absPath[1024];

		get_executable_name(absPath, sizeof(absPath));
		replace_filename(absPath, absPath, "", sizeof(absPath));

		absolutePath = absPath;
	}

	loggy = new Loggy(absolutePath);

	/* Add the logs. */
	{
		time_t t = time(0);
		std::stringstream ss;

		ss << "Fixel, version " << MajorVersion << "." << MinorVersion << "." << ImportantRevision << " -- " << ctime(&t);

		loggy->AddLog("Fixel", ss.str() + "---\n");
		loggy->AddLog("Debug", ss.str() + "Debug Logging File\n---\n");
		loggy->AddLog("Script", ss.str() + "Script Logging File\n---\n");
	}

	loggy->Write(0, std::string("Allegro initialized (version ") + allegro_id + ").\n");

	/* Operation system version. */
	{
		std::stringstream ss;

		ss << "Operation system version: " << os_version << "." << os_revision << "\n";

		loggy->Write(0, ss.str());
	}

	if (install_timer() != 0)
		throw Exception("Couldn't initialize timers.");
	loggy->Write(0, "Timers initialized.\n");

	if (install_mouse() < 0)
		throw Exception("Couldn't initialize mouse.");
	loggy->Write(0, "Mouse initialized.\n");

	if (install_keyboard() != 0)
		throw Exception("Couldn't initialize keyboard.");
	loggy->Write(0, "Keyboard initialized.\n");

	if (install_joystick(JOY_TYPE_AUTODETECT) != 0)
		throw Exception("Couldn't initialize joystick.");
	loggy->Write(0, "Joystick initialized.\n");

	if (install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, 0) != 0)
		throw Exception("Couldn't initialize sound.");
	loggy->Write(0, "Sound initialized.");

	set_color_depth(desktop_color_depth());
	if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0) != 0)
		throw Exception("Couldn't set graphics mode.", allegro_error);
	loggy->Write(0, "Set graphics mode.\n");

	set_color_conversion(COLORCONV_KEEP_ALPHA);

	if (timer_init(15) != 0)
		throw Exception("Couldn't initialize game timer.");
	loggy->Write(0, "Game timer initialized.\n");

	buffer = new Bitmap(SCREEN_W, SCREEN_H);
	loggy->Write(0, "Double buffer initialized.\n");

	screen = new Bitmap(::screen);
	loggy->Write(0, "Bitmap `screen' copied to class `Bitmap'.\n");

	defFont = new Font(absolutePath + "Content/Fonts/Font.pcx");
	loggy->Write(0, "Default font loaded.\n");

	LOCK_FUNCTION(CloseButtonCallback);
	set_close_button_callback(&CloseButtonCallback);

	set_window_title("Fixel");

	LOCK_VARIABLE(fps);
	LOCK_VARIABLE(frames);
	LOCK_FUNCTION(FramesCounter);

	install_int(&FramesCounter, 1000);

	input = new Input(this);
	managers.push_back(input);

	screeny = new Screeny(this);
	managers.push_back(screeny);

	for (std::vector<IManager *>::iterator i = managers.begin(); i != managers.end(); i++)
		(*i)->Initialize();

	luaState = luaL_newstate();

	if (!luaState)
		throw Exception("The Lua state couldn't be allocated.", "Out of memory?");

	options = new State();
	options->RegisterSerializer(new NumberSerializer, "Number");
	options->RegisterSerializer(new StringSerializer, "String");
	options->RegisterSerializer(new TableSerializer, "Table");
	options->RegisterSerializer(new BooleanSerializer, "Boolean");
	options->LoadFromFile(absolutePath + "Data/Game/Options.state");

	SaveStack(luaState);

	FLua::Initialize(luaState);

	FLua::ToLua(luaState, this, true, "Game"); /* Add the game to the Lua state... */
	lua_setglobal(luaState, "Game");

	/* ...and execute the script initialization function. */
	{
		std::string str = absolutePath + "Content/Lua/Game/Game.lua";

		if (luaL_dofile(luaState, str.c_str()) != 0)
			throw Exception(lua_tostring(luaState, -1), "Syntax error?");
	}

	lua_getglobal(luaState, "Core");
	lua_getfield(luaState, -1, "Initialize");
	lua_pushvalue(luaState, -2);
	
	if (lua_pcall(luaState, 1, 0, 0) != 0)
		throw Exception(lua_tostring(luaState, -1), "Syntax error?");

	RestoreStack(luaState);

	/* Loads some player stuff. */
	controls = new Controls(absolutePath + "Data/Game/Controls.xml");

	/* Initialize the windows timer. */
	#ifdef ALLEGRO_WINDOWS
		QueryPerformanceFrequency(&freq);
	#endif
}

void Game::Run(void)
{
	running = true;
	paused = false;

	while (running)
	{
		timer_wait();

		UpdateTime();
		
		/* Update. */
		{
			for (std::vector<IManager *>::iterator i = managers.begin(); i != managers.end(); i++)
				(*i)->Update(true);

			if (closeButton || input->Get_KeyState(KEY_ESC) != ButtonNotHeld)
				running = false;

			/* Lua update function. */
			{
				SaveStack(luaState);

				lua_getglobal(luaState, "Core");
				lua_getfield(luaState, -1, "Update");
				
				if (!lua_isnil(luaState, -1))
				{
					lua_pushvalue(luaState, -2);

					if (lua_pcall(luaState, 1, 0, 0) != 0)
						throw Exception(lua_tostring(luaState, -1), "Syntax error?");
				}

				RestoreStack(luaState);
			}
		}

		/* Draw. */
		Draw();

		frames++;
	}
}

void Game::Draw(void)
{
	buffer->Clear();

	for (std::vector<IManager *>::iterator i = managers.begin(); i != managers.end(); i++)
		(*i)->Draw(*buffer);

	SaveStack(luaState);

	lua_getglobal(luaState, "Core");
	lua_getfield(luaState, -1, "Draw");

	if (!lua_isnil(luaState, -1))
	{
		lua_pushvalue(luaState, -2);
		FLua::ToLua(luaState, buffer, true, "Bitmap");

		if (lua_pcall(luaState, 2, 0, 0) != 0)
			throw Exception(lua_tostring(luaState, -1), "Syntax error?");
	}

	RestoreStack(luaState);

	/* Draws the FPS. */
	{
		std::stringstream ss;

		ss << "FPS: " << fps;

		defFont->Draw(FontDrawCentered, *buffer, SCREEN_W / 2, 0, makecol(255, 255, 255), ss.str());
	}

	buffer->BlitTo(*screen);
}

void Game::UpdateTime(void)
{
	double t = 0.0;

	#ifdef ALLEGRO_WINDOWS
		LARGE_INTEGER cur;

		QueryPerformanceCounter(&cur);

		t = (double)cur.QuadPart / (double)freq.QuadPart;
	#else
		timeval cur;

		gettimeofday(&cur, 0);

		t = cur.tv_sec + (double)current.tv_usc / 1000000.0;
	#endif

	elapsedTime = t - currentTime;
	currentTime = t;
}

static void FramesCounter(void)
{
	fps = frames;
	frames = 0;
}
END_OF_STATIC_FUNCTION(FramesCounter)

static void CloseButtonCallback(void)
{
	closeButton = true;
}
END_OF_STATIC_FUNCTION(CloseButtonCallback)
