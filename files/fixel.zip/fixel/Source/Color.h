#ifndef F_COLOR_H_
#define F_COLOR_H_

#include <allegro.h>

struct Color
{
	public:
		int Red, Green, Blue, Alpha;

		Color(void) : Red(0), Green(0), Blue(0), Alpha(255) { }
		Color(const struct Color& c) : Red(c.Red), Green(c.Green), Blue(c.Blue), Alpha(c.Alpha) { }
		Color(int c) : Red(getr(c)), Green(getg(c)), Blue(getb(c)), Alpha(255) { }
		Color(int r, int g, int b) : Red(r), Green(g), Blue(b), Alpha(255) { }
		Color(int r, int g, int b, int a) : Red(r), Green(g), Blue(b), Alpha(a) { }

		int ToAllegroColor(void) const { return makeacol32(Red, Green, Blue, Alpha); }

		struct Color& operator=(int c) { Red = getr(c); Green = getg(c); Blue = getb(c); Alpha = geta(c); return *this; }
		struct Color& operator=(const struct Color& c) { Red = c.Red; Green = c.Green; Blue = c.Blue; Alpha = c.Alpha; return *this; }
		operator int(void) const { return ToAllegroColor(); }
};

#endif
