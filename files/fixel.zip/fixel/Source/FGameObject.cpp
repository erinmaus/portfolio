#include <string>
#include <vector>

#include "Exception.h"
#include "FLua.h"
#include "Game.h"
#include "GameObject.h"
#include "Objector.h"

namespace FLua
{
	namespace FGameObject
	{
		int Index(lua_State * l)
		{
			GameObject * o = (GameObject *)FromLua(l, 1, false, "GameObject")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "Uid")
				lua_pushinteger(l, o->Get_Uid());
			else if (key == "Name")
				lua_pushstring(l, o->Get_Name().c_str());
			else if (key == "Objector")
				ToLua(l, o->Get_Objector(), true, "Objector");
			else if (key == "Stage")
				ToLua(l, o->Get_Objector()->Get_Stage(), true, "Stage");
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		int Remove(lua_State * l)
		{
			GameObject * o = (GameObject *)FromLua(l, 1, false, "GameObject")->Data;

			o->Remove();

			return 0;
		}

		int Synchronize(lua_State * l)
		{
			GameObject * o = (GameObject *)FromLua(l, 1, false, "GameObject")->Data;

			o->Synchronize();

			return 0;
		}

		const luaL_Reg go[] =
		{
			{ "__index", &Index },
			{ "__call", &Remove },
			{ "Remove", &Remove },
			{ "Synchronize", &Synchronize },
			{ 0, 0 }
		};
	}

	namespace FObjector
	{
		int Index(lua_State * l)
		{
			Objector * o = (Objector *)FromLua(l, 1, false, "Objector")->Data;
			const char * key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key);

			if (!lua_isnil(l, -1))
				return 1;
			else
				luaL_error(l, "%s is an invalid index", key);

			return 0;
		}

		/* Adds a game object. */
		int AddObject(lua_State * l)
		{
			Objector * o = (Objector *)FromLua(l, 1, false, "Objector")->Data;
			GameObject * go;
			
			try
			{
				Game * g;

				lua_getglobal(l, "Game");
				g = (Game *)FromLua(l, -1, false, "Game")->Data;

				go = new GameObject(o, l, g->Get_RegisteredObjectPath(luaL_checkstring(l, 2)),
					(lua_gettop(l) > 3) ? 3 : -1);
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			o->AddObject(go, lua_toboolean(l, 3));

			lua_getglobal(l, GlobalTable);
			lua_rawgeti(l, -1, go->Get_Uid());
			lua_getfield(l, -1, go->Get_Name().c_str());

			return 1;
		}

		/* Gets an object. */
		int GetObject(lua_State * l)
		{
			Objector * o = (Objector *)FromLua(l, 1, false, "Objector")->Data;
			GameObject * go;

			if (lua_gettop(l) > 2)
				go = o->Get_Object(luaL_checkstring(l, 2), luaL_checkinteger(l, 3));
			else
				go = o->Get_Object(luaL_checkstring(l, 2));

			if (!go)
				lua_pushnil(l);
			else
			{
				lua_getglobal(l, GlobalTable);
				lua_rawgeti(l, -1, go->Get_Uid());
				lua_getfield(l, -1, go->Get_Name().c_str());
			}

			return 1;
		}

		int Broadcast(lua_State * l)
		{
			Objector * o = (Objector *)FromLua(l, 1, false, "Objector")->Data;

			try
			{
				o->Broadcast(luaL_checkstring(l, 2), (lua_gettop(l) > 2) ? 3 : -1);
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		int BroadcastToTeam(lua_State * l)
		{
			Objector * o = (Objector *)FromLua(l, 1, false, "Objector")->Data;

			try
			{
				if (lua_gettop(l) > 4)
					o->BroadcastToTeam(luaL_checkstring(l, 2), 3, luaL_checkinteger(l, 4), luaL_checkinteger(l, 5));
				else
					o->BroadcastToTeam(luaL_checkstring(l, 2), 3, luaL_checkinteger(l, 4));
			}
			catch (const Exception& e)
			{
				luaL_error(l, "%s", e.what());
			}

			return 0;
		}

		int GetObjectAtXY(lua_State * l)
		{
			Objector * o = (Objector *)FromLua(l, 1, false, "Objector")->Data;
			Point * p = (Point *)FromLua(l, 2, false, "Point")->Data;
			GameObject * go = o->Get_ObjectAtPosition(*p);

			if (go)
			{
				lua_getglobal(l, GlobalTable);
				lua_rawgeti(l, -1, go->Get_Uid());
				lua_getfield(l, -1, go->Get_Name().c_str());
			}
			else
				lua_pushnil(l);

			return 1;
		}

		int GetObjectsAtXY(lua_State * l)
		{
			Objector * o = (Objector *)FromLua(l, 1, false, "Objector")->Data;
			Point * p = (Point *)FromLua(l, 2, false, "Point")->Data;
			GameObject * go = 0;

			lua_newtable(l);

			int i = 0;
			while((go = o->Get_ObjectAtPosition(*p, i)))
			{
				SaveStack(l);

				lua_getglobal(l, GlobalTable);
				lua_rawgeti(l, -1, go->Get_Uid());
				lua_getfield(l, -1, go->Get_Name().c_str());

				luaL_ref(l, -4);

				RestoreStack(l);

				i++;
			}

			return 1;
		}

		const luaL_Reg objector[] =
		{
			{ "__index", &Index },
			{ "Add", &AddObject },
			{ "Get", &GetObject },
			{ "Broadcast", &Broadcast },
			{ "BroadcastToTeam", &BroadcastToTeam },
			{ "GetObjectAtXY", &GetObjectAtXY },
			{ "GetObjectsAtXY", &GetObjectsAtXY },
			{ 0, 0 }
		};
	}
}
