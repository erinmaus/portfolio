#ifndef F_EXCEPTION_H_
#define F_EXCEPTION_H_

#include <exception>
#include <string>

class Exception : public std::exception
{
	private:
		std::string reason;
		std::string sub;
		std::string complete;

	public:
		/* Constructors and destructor. */
		Exception(void) : reason("none"), sub("none") { complete = reason + "\n" + sub; }
		Exception(const std::string& reason) : reason(reason), sub("none") { complete = reason + "\n" + sub; }
		Exception(const std::string& reason, const std::string& sub) : reason(reason), sub(sub) { complete = reason + "\n" + sub; }
		~Exception(void) throw() { };

		/* Getting. This should always be used over what(). */
		inline std::string Get_Reason(void) const { return reason; }
		inline std::string Get_Sub(void) const { return sub; }

		/* This is to play nice with LuaBind. */
		inline const char * what(void) const throw() { return complete.c_str(); }
};

/* This is a special exception because it means we can't use the game's log file to report the error. */
class DeadlyException : public Exception
{
	public:
		DeadlyException(void) : Exception() { }
		DeadlyException(const std::string r) : Exception(r) { }
		DeadlyException(const std::string& r, const std::string& s) : Exception(r, s) { }
};


#endif
