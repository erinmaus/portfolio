#include <allegro.h>
#include <string>

#include "Bitmap.h"
#include "Exception.h"
#include "Font.h"

Font::Font(const std::string& filename)
	: shared(false)
{
	font = load_font(filename.c_str(), 0, 0);

	if (!font)
		throw Exception(filename + " could not be loaded.", "Out of memory or file doesn't exist?");
}

Font::Font(FONT * font, bool share)
	: font(font), shared(share)
{
	if (!font)
		throw Exception("The font was 0.", "Logic error?");
}

void Font::Draw(FontDrawType type, Bitmap& bitmap, int x, int y, int color, int bg, const std::string& text)
{
	switch(type)
	{
		case FontDrawLeft:
			textout_ex(bitmap.Get_Bitmap(), font, text.c_str(), x, y, color, bg);
			break;

		case FontDrawRight:
			textout_right_ex(bitmap.Get_Bitmap(), font, text.c_str(), x, y, color, bg);
			break;

		case FontDrawCentered:
			textout_centre_ex(bitmap.Get_Bitmap(), font, text.c_str(), x, y, color, bg);
			break;

		default:
			throw Exception("Invalid font type given.", "Logic error?");
	}
}

/* Draws the font justified. */
void Font::DrawJustified(Bitmap& bitmap, int x, int x2, int y, int diff, int color, int bg, const std::string& text)
{
	textout_justify_ex(bitmap.Get_Bitmap(), font, text.c_str(), x, x2, y, diff, color, bg);
}
