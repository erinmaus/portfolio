#include <allegro.h>

#include "FLua.h"

namespace FLua
{
	namespace FGraphics
	{
		int MakeColor(lua_State * l)
		{
			switch(lua_gettop(l))
			{
				case 3:
					lua_pushinteger(l, makecol(luaL_checkinteger(l, 1), luaL_checkinteger(l, 2), luaL_checkinteger(l, 3)));
					break;

				case 4:
					lua_pushinteger(l, makeacol32(luaL_checkinteger(l, 1), luaL_checkinteger(l, 2), luaL_checkinteger(l, 3), luaL_checkinteger(l, 4)));
					break;

				default:
					luaL_error(l, "invalid arguments");
			}

			return 1;
		}

		int GetRed(lua_State * l)
		{
			lua_pushinteger(l, getr(luaL_checkinteger(l, 1)));

			return 1;
		}

		int GetGreen(lua_State * l)
		{
			lua_pushinteger(l, getg(luaL_checkinteger(l, 1)));

			return 1;
		}

		int GetBlue(lua_State * l)
		{
			lua_pushinteger(l, getb(luaL_checkinteger(l, 1)));

			return 1;
		}

		int GetAlpha(lua_State * l)
		{
			lua_pushinteger(l, geta(luaL_checkinteger(l, 1)));

			return 1;
		}

		int SetAdditiveBlender(lua_State * l)
		{
			SaveStack(l);

			lua_getglobal(l, "Game");
			lua_getfield(l, -1, "Options");
			lua_getfield(l, -1, "EnableAdditiveBlending");

			if (lua_toboolean(l, -1))
			{
				RestoreStack(l);

				drawing_mode(DRAW_MODE_TRANS, 0, 0, 0);

				if (lua_gettop(l) == 1)
					set_add_blender(0, 0, 0, luaL_checkinteger(l, 1));
				else
					set_add_blender(luaL_checkinteger(l, 1), luaL_checkinteger(l, 2), luaL_checkinteger(l, 3), luaL_checkinteger(l, 4));
			}
			else
				set_add_blender(0, 0, 0, 255);

			return 0;
		}

		int SetAlphaBlender(lua_State * l)
		{
			drawing_mode(DRAW_MODE_TRANS, 0, 0, 0);

			set_alpha_blender();

			return 0;
		}

		int SetTranslucentBlender(lua_State * l)
		{
			SaveStack(l);

			lua_getglobal(l, "Game");
			lua_getfield(l, -1, "Options");
			lua_getfield(l, -1, "EnableTranslucentBlending");

			if (lua_toboolean(l, -1))
			{
				RestoreStack(l);

				drawing_mode(DRAW_MODE_TRANS, 0, 0, 0);

				set_trans_blender(0, 0, 0, luaL_checkinteger(l, 1));
			}
			else
				set_trans_blender(0, 0, 0, 255);

			return 0;
		}

		int SetSolidMode(lua_State * l)
		{
			solid_mode();

			return 0;
		}

		const luaL_Reg graphics[] =
		{
			{ "MakeColor", &MakeColor },
			{ "GetRed", &GetRed },
			{ "GetGreen", &GetGreen },
			{ "GetBlue", &GetBlue },
			{ "GetAlpha", &GetAlpha },
			{ "SetAdditiveBlender", &SetAdditiveBlender },
			{ "SetAlphaBlender", &SetAlphaBlender },
			{ "SetTranslucentBlender", &SetTranslucentBlender },
			{ "SetSolidMode", &SetSolidMode },
			{ 0, 0 }
		};
	}
}
