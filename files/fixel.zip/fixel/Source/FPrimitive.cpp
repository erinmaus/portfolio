#include "FLua.h"
#include "Point.h"
#include "Rectangle.h"

namespace FLua
{
	namespace FRectangle
	{
		/* Library functions. */
		int Create(lua_State * l)
		{
			Rectangle * r = new Rectangle(0, 0, 0, 0);

			if (lua_gettop(l) > 1)
			{
				r->X = luaL_checkinteger(l, 1);
				r->Y = luaL_checkinteger(l, 2);
			}

			if (lua_gettop(l) > 3)
			{
				r->Width = luaL_checkinteger(l, 3);
				r->Height = luaL_checkinteger(l, 4);
			}

			ToLua(l, r, false, "Rectangle");

			return 1;
		}

		const luaL_Reg rectLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		/* Metatable functions. */
		int ToString(lua_State * l)
		{
			Rectangle * r = (Rectangle *)FromLua(l, 1, false, "Rectangle")->Data;

			lua_pushfstring(l, "(%d, %d) [%d x %d]", r->X, r->Y, r->Width, r->Height);

			return 1;
		}

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Rectangle");

			if (!(o->Shared))
				delete (Rectangle *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			Rectangle * r = (Rectangle *)FromLua(l, 1, false, "Rectangle")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "X")
				lua_pushinteger(l, r->X);
			else if (key == "Y")
				lua_pushinteger(l, r->Y);
			else if (key == "XY")
			{
				Point * p = new Point(r->X, r->Y);
				ToLua(l, p, false, "Point");
			}
			else if (key == "Width")
				lua_pushinteger(l, r->Width);
			else if (key == "Height")
				lua_pushinteger(l, r->Height);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			Rectangle * r = (Rectangle *)FromLua(l, 1, false, "Rectangle")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "X")
				r->X = luaL_checkinteger(l, 3);
			else if (key == "Y")
				r->Y = luaL_checkinteger(l, 3);
			else if (key == "XY")
			{
				Point * p = (Point *)FromLua(l, 3, false, "Point")->Data;

				r->X = p->X;
				r->Y = p->Y;
			}
			else if (key == "Width")
				r->Width = luaL_checkinteger(l, 3);
			else if (key == "Height")
				r->Height = luaL_checkinteger(l, 3);
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		/* Standard fanfare. */
		int Collision(lua_State * l)
		{
			Rectangle * a = (Rectangle *)FromLua(l, 1, false, "Rectangle")->Data;
			Rectangle * b = (Rectangle *)FromLua(l, 2, false, "Rectangle")->Data;

			lua_pushboolean(l, a->Collision(*b));

			return 1;
		}

		int Inside(lua_State * l)
		{
			Rectangle * a = (Rectangle *)FromLua(l, 1, false, "Rectangle")->Data;
			Rectangle * b = (Rectangle *)FromLua(l, 2, false, "Rectangle")->Data;

			lua_pushboolean(l, a->Inside(*b));

			return 1;
		}

		const luaL_Reg rect[] =
		{
			{ "__tostring", &ToString },
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "Collision", &Collision },
			{ "Inside", &Inside },
			{ 0, 0 }
		};
	}

	namespace FPoint
	{
		/* Library functions. */
		int Create(lua_State * l)
		{
			Point * p = new Point(0, 0);

			if (lua_gettop(l) > 0)
				p->X = luaL_checkinteger(l, 1);
			if (lua_gettop(l) > 1)
				p->Y = luaL_checkinteger(l, 2);

			ToLua(l, p, false, "Point");

			return 1;
		}

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Point");

			if (!(o->Shared))
				delete (Point *)o->Data;

			return 0;
		}

		const luaL_Reg pointLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		/* Metatable functions. */
		int ToString(lua_State * l)
		{
			Point * p = (Point *)FromLua(l, 1, false, "Point")->Data;

			lua_pushfstring(l, "(%d, %d)", p->X, p->Y);

			return 1;
		}

		int Index(lua_State * l)
		{
			Point * p = (Point *)FromLua(l, 1, false, "Point")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());

			if (!lua_isnil(l, -1))
				return 1;

			if (key == "X")
				lua_pushinteger(l, p->X);
			else if (key == "Y")
				lua_pushinteger(l, p->Y);
			else
				luaL_error(l, "%s is not a valid index", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			Point * p = (Point *)FromLua(l, 1, false, "Point")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "X")
				p->X = luaL_checkinteger(l, 3);
			else if (key == "Y")
				p->Y = luaL_checkinteger(l, 3);
			else
				luaL_error(l, "%s is not a valid index", key.c_str());

			return 0;
		}

		int Add(lua_State * l)
		{
			Point * a = (Point *)FromLua(l, 1, false, "Point")->Data;
			Point * b = (Point *)FromLua(l, 2, false, "Point")->Data;
			Point * c = new Point((*a) + (*b));

			ToLua(l, c, false, "Point");

			return 1;
		}

		int Subtract(lua_State * l)
		{
			Point * a = (Point *)FromLua(l, 1, false, "Point")->Data;
			Point * b = (Point *)FromLua(l, 2, false, "Point")->Data;
			Point * c = new Point((*a) - (*b));

			ToLua(l, c, false, "Point");

			return 1;
		}

		int Multiply(lua_State * l)
		{
			Point * a = (Point *)FromLua(l, 1, false, "Point")->Data;
			Point * b = (Point *)FromLua(l, 2, false, "Point")->Data;
			Point * c = new Point((*a) * (*b));

			ToLua(l, c, false, "Point");

			return 1;
		}

		int Divide(lua_State * l)
		{
			Point * a = (Point *)FromLua(l, 1, false, "Point")->Data;
			Point * b = (Point *)FromLua(l, 2, false, "Point")->Data;
			Point * c = new Point((*a) / (*b));

			ToLua(l, c, false, "Point");

			return 1;
		}

		int Equal(lua_State * l)
		{
			Point * a = (Point *)FromLua(l, 1, false, "Point")->Data;
			Point * b = (Point *)FromLua(l, 2, false, "Point")->Data;

			lua_pushboolean(l, (*a) == (*b));

			return 1;
		}

		int LessThan(lua_State * l)
		{
			Point * a = (Point *)FromLua(l, 1, false, "Point")->Data;
			Point * b = (Point *)FromLua(l, 2, false, "Point")->Data;

			lua_pushboolean(l, (*a) < (*b));

			return 1;
		}

		int LessThanOrEqualTo(lua_State * l)
		{
			Point * a = (Point *)FromLua(l, 1, false, "Point")->Data;
			Point * b = (Point *)FromLua(l, 2, false, "Point")->Data;

			lua_pushboolean(l, (*a) <= (*b));

			return 1;
		}

		const luaL_Reg point[] =
		{
			{ "__tostring", &ToString },
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "__add", &Add },
			{ "__sub", &Subtract },
			{ "__mul", &Multiply },
			{ "__div", &Divide },
			{ "__eq", &Equal },
			{ "__lt", &LessThan },
			{ "__le", &LessThanOrEqualTo },
			{ 0, 0 }
		};
	}
}
