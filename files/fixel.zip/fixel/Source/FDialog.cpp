#include <allegro.h>
#include <cstdlib>
#include <string>
#include <vector>

#include "Bitmap.h"
#include "Exception.h"
#include "FLua.h"
#include "Font.h"
#include "Point.h"

namespace FLua
{
	namespace FDialog
	{
		struct DBitmap
		{
			BITMAP * BitmapAllegro;
			Bitmap * BitmapClass;
		};

		int d_button_ex_proc(int m, DIALOG * d, int c)
		{
			int ret = d_button_proc(m, d, c);

			if (ret == D_CLOSE && d->d2 != LUA_NOREF)
			{
				lua_State * l = (lua_State *)d->dp2;
				int ref = d->d2;

				lua_rawgeti(l, LUA_REGISTRYINDEX, ref);
				ToLua(l, d, true, "Dialog");

				if (lua_pcall(l, 1, 1, 0) != 0)
					lua_error(l);

				return luaL_checkinteger(l, -1);
			}

			return ret;
		}

		void Delete(DIALOG * d, bool self = true)
		{
			if (d->proc == d_clear_proc || d->proc == d_box_proc || d->proc == d_check_proc
				|| d->proc == d_radio_proc) /* The check and radio procedures can't be scripted to have text. */
			{
				/* Do nothing at the moment. */
			}
			else if (d->proc == d_bitmap_proc)
			{
				delete (Bitmap *)d->dp2; /* Delete the actual Bitmap class, which will destroy the bitmap. */
			}
			else if (d->proc == d_text_proc || d->proc == d_ctext_proc || d->proc == d_rtext_proc || d->proc == d_textbox_proc)
			{
				free(d->dp);
			}
			else if (d->proc == d_button_ex_proc)
			{
				if (!d->d1 && d->d2 != LUA_NOREF)
					luaL_unref((lua_State *)d->dp2, LUA_REGISTRYINDEX, d->d2);

				free(d->dp); /* ustrdup() */
			}
			/*else if (d->proc == d_icon_proc)
			{
				const unsigned int dpTotal = 3;
				FDialog::DBitmap * bmps[dpTotal] =
				{
					(DBitmap *)d->dp,
					(DBitmap *)d->dp2,
					(DBitmap *)d->dp3
				};

				for (unsigned int i = 0; i < dpTotal; i++)
				{
					delete bmps[i]->BitmapClass;
					delete bmps[i];
				}

				delete d;
			}*/
			else if (d->proc == d_edit_proc)
			{
				delete (char *)d->dp;
			}
			else
				throw Exception("unknown dialog");

			if (self)
				delete d;
		}

		#define InitializeText() \
		d->dp = malloc(sizeof(char) * 2); \
		uszprintf((char *)d->dp, 2, "%c", 0);

		int Create(lua_State * l)
		{
			DialogType t = (DialogType)luaL_checkinteger(l, 1);
			DIALOG * d = new DIALOG;

			memset(d, 0, sizeof(DIALOG));

			if (t == DialogClear)
				d->proc = d_clear_proc;
			else if (t == DialogBox)
				d->proc = d_box_proc;
			else if (t == DialogBitmap)
			{
				d->proc = d_bitmap_proc;
				InitializeText();
			}
			else if (t == DialogLeftText)
			{
				d->proc = d_text_proc;
				InitializeText();
			}
			else if (t == DialogCenterText)
			{
				d->proc = d_ctext_proc;
				InitializeText();
			}
			else if (t == DialogRightText)
			{
				d->proc = d_rtext_proc;
				InitializeText();
			}
			else if (t == DialogButton)
			{
				d->proc = d_button_ex_proc;
				d->flags |= D_EXIT;
				d->d1 = false;
				d->d2 = LUA_NOREF;

				InitializeText();
			}
			else if (t == DialogCheck)
				d->proc = d_check_proc;
			else if (t == DialogRadio)
				d->proc = d_radio_proc;
			else if (t == DialogIcon)
				/*d->proc = d_icon_proc;*/
				luaL_error(l, "icon is not supported yet");
			else if (t == DialogEdit)
			{
				d->proc = d_edit_proc;
				d->d1 = 0;
			}
			else if (t == DialogTextbox)
			{
				d->proc = d_textbox_proc;
				InitializeText();
			}
			else
				luaL_error(l, "invalid procedure");

			ToLua(l, d, false, "Dialog");

			return 1;
		}

		const luaL_Reg dialogLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		int ToString(lua_State * l)
		{
			DIALOG * d = (DIALOG *)FromLua(l, 1, false, "Dialog")->Data;

			if (d->proc == d_clear_proc)
				lua_pushstring(l, "d_clear_proc");
			else if (d->proc == d_box_proc)
				lua_pushstring(l, "d_box_proc");
			else if (d->proc == d_bitmap_proc)
				lua_pushstring(l, "d_bitmap_proc");
			else if (d->proc == d_text_proc)
				lua_pushstring(l, "d_text_proc");
			else if (d->proc == d_ctext_proc)
				lua_pushstring(l, "d_ctext_proc");
			else if (d->proc == d_rtext_proc)
				lua_pushstring(l, "d_rtext_proc");
			else if (d->proc == d_button_ex_proc)
				lua_pushstring(l, "d_button_ex_proc");
			else if (d->proc == d_check_proc)
				lua_pushstring(l, "d_check_proc");
			else if (d->proc == d_radio_proc)
				lua_pushstring(l, "d_radio_proc");
			else if (d->proc == d_icon_proc)
				lua_pushstring(l, "d_icon_proc");
			else if (d->proc == d_edit_proc)
				lua_pushstring(l, "d_edit_proc");
			else if (d->proc == d_textbox_proc)
				lua_pushstring(l, "d_textbox_proc");
			else
				lua_pushstring(l, "unknown procedure");

			return 1;
		}

		/* Notes about garbage collection:
			~ For the d_bitmap_proc, the bitmap must be a copy.  It will be deleted upon
				being finalized.  The same goes for d_icon_proc and its three bitmaps.
		*/
		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "Dialog");
			DIALOG * d = (DIALOG *)o->Data;

			if (!(o->Shared))
				Delete(d);

			return 0;
		}

		int Index(lua_State * l)
		{
			DIALOG * d = (DIALOG *)FromLua(l, 1, false, "Dialog")->Data;
			std::string key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key.c_str());
			
			if (!lua_isnil(l, -1))
				return 1;

			if (key == "X")
				lua_pushinteger(l, d->x);
			else if (key == "Y")
				lua_pushinteger(l, d->y);
			else if (key == "XY")
			{
				Point * p = new Point(d->x, d->y);
				ToLua(l, p, false, "Point");
			}
			else if (key == "Width")
				lua_pushinteger(l, d->w);
			else if (key == "Height")
				lua_pushinteger(l, d->h);
			else if (key == "Exit")
				lua_pushboolean(l, d->flags & D_EXIT);
			else if (key == "Selected")
				lua_pushboolean(l, d->flags & D_SELECTED);
			else if (key == "GotFocus")
				lua_pushboolean(l, d->flags & D_GOTFOCUS);
			else if (key == "GotMouse")
				lua_pushboolean(l, d->flags & D_GOTMOUSE);
			else if (key == "Hidden")
				lua_pushboolean(l, d->flags & D_HIDDEN);
			else if (key == "Disabled")
				lua_pushboolean(l, d->flags & D_DISABLED);
			else if (key == "Dirty")
				lua_pushboolean(l, d->flags & D_DIRTY);
			else if (key == "Foreground")
				lua_pushinteger(l, d->fg);
			else if (key == "Background")
				lua_pushinteger(l, d->bg);
			else if (key == "Key")
			{
				/* To-do: Fix this. */
				lua_pushinteger(l, d->key + 1 - 'A');
			}
			/* Text procedures. */
			else if (key == "Text")
			{
				if (d->proc == d_text_proc || d->proc == d_ctext_proc || d->proc == d_rtext_proc ||
					d->proc == d_textbox_proc || d->proc == d_edit_proc || d->proc == d_button_ex_proc)
				{
					lua_pushstring(l, (const char *)d->dp);
				}
				else
					luaL_error(l, "doesn't have text");
			}
			else if (key == "TextLength")
			{
				if (d->proc == d_edit_proc)
					lua_pushinteger(l, d->d1);
				else
					luaL_error(l, "doesn't have text");
			}
			/* Bitmap/icon procedures. */
			else if (key == "Bitmap")
			{
				if (d->proc == d_icon_proc)
				{
					DBitmap * db = (DBitmap *)d->dp;
					ToLua(l, db->BitmapClass, true, "Bitmap");
				}
				else if (d->proc == d_bitmap_proc)
				{
					Bitmap * b = (Bitmap *)d->dp2;
					ToLua(l, b, true, "Bitmap");
				}
				else
					luaL_error(l, "doesn't have bitmap");
			}
			/* Icon procedures. */
			/*else if (key == "SelectedIcon")
			{
				if (d->proc == d_icon_proc)
				{
					DBitmap * db = (DBitmap *)d->dp2;
					ToLua(l, db->BitmapClass, true, "Bitmap");
				}
				else
					luaL_error(l, "doesn't have selected icon");
			}
			else if (key == "DisabledIcon")
			{
				if (d->proc == d_icon_proc)
				{
					DBitmap * db = (DBitmap *)d->dp2;
					ToLua(l, db->BitmapClass, true, "Bitmap");
				}
				else
					luaL_error(l, "doesn't have disabled icon");
			}*/
			else if (key == "Push")
				lua_pushinteger(l, d->d1);
			else if (key == "Indent")
				lua_pushinteger(l, d->d2);
			/* Button procedures. */
			else if (key == "OnClick")
			{
				lua_rawgeti((lua_State *)d->dp2, LUA_REGISTRYINDEX, d->d2);
			}
			/* Typos! */
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			DIALOG * d = (DIALOG *)FromLua(l, 1, false, "Dialog")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "X")
				d->x = luaL_checkinteger(l, 3);
			else if (key == "Y")
				d->y = luaL_checkinteger(l, 3);
			else if (key == "XY")
			{
				Point * p = (Point *)FromLua(l, 3, false, "Point")->Data;
				
				d->x = p->X;
				d->y = p->Y;
			}
			else if (key == "Width")
				d->w = luaL_checkinteger(l, 3);
			else if (key == "Height")
				d->h = luaL_checkinteger(l, 3);
			else if (key == "Exit")
			{
				if (lua_toboolean(l, 3))
					d->flags |= D_EXIT;
				else if (d->flags & D_EXIT)
					d->flags ^= D_EXIT;
			}
			else if (key == "Selected")
			{
				if (lua_toboolean(l, 3))
					d->flags |= D_SELECTED;
				else if (d->flags & D_SELECTED)
					d->flags ^= D_SELECTED;
			}
			else if (key == "Hidden")
			{
				if (lua_toboolean(l, 3))
					d->flags |= D_HIDDEN;
				else if (d->flags & D_HIDDEN)
					d->flags ^= D_HIDDEN;
			}
			else if (key == "Disabled")
			{
				if (lua_toboolean(l, 3))
					d->flags |= D_DISABLED;
				else if (d->flags & D_DISABLED)
					d->flags ^= D_DISABLED;
			}
			else if (key == "Dirty")
			{
				if (lua_toboolean(l, 3))
					d->flags |= D_DIRTY;
				else if (d->flags & D_DIRTY)
					d->flags ^= D_DIRTY;
			}
			else if (key == "Foreground")
				d->fg = luaL_checkinteger(l, 3);
			else if (key == "Background")
				d->bg = luaL_checkinteger(l, 3);
			else if (key == "Key")
			{
				int key = luaL_checkinteger(l, 3);

				if (key <= KEY_Z)
					d->key = luaL_checkinteger(l, 3) - 1 + 'A';
				else if (key == KEY_ENTER)
					d->key = 13;
				else
					d->key = key;
			}
			/* Text routines. */
			else if (key == "Text")
			{
				if (d->proc == d_edit_proc)
				{
					if (d->d1 > 0)
						uszprintf((char *)d->dp, d->d1, "%s", luaL_checkstring(l, 3));
					else
						luaL_error(l, "text field hasn't been initialized");
				}
				else if (d->proc == d_text_proc || d->proc == d_ctext_proc || d->proc == d_rtext_proc ||
					d->proc == d_textbox_proc || d->proc == d_button_ex_proc)
				{
					if (d->dp)
						free(d->dp); /* ustrdup() uses malloc() interally. */

					d->dp = ustrdup(luaL_checkstring(l, 3));
				}
				else
					luaL_error(l, "doesn't have text");
			}
			else if (key == "TextLength")
			{
				if (d->proc == d_edit_proc)
				{
					int length = luaL_checkinteger(l, 3);

					if (length > 0)
					{
						char * c = new char[length];
						memset(c, 0, sizeof(char) * length);

						if (d->d1 > 0)
						{
							uszprintf(c, length, "%s", (char *)d->dp);
							
							delete[] (char *)d->dp; /* No memory leaks. */
						}

						d->d1 = length;
						d->dp = c;
					}
					else
						luaL_error(l, "%d is an invalid length", length);
				}
				else
					luaL_error(l, "doesn't have text length");
			}
			/* Radio button. */
			else if (key == "Group")
			{
				if (d->proc == d_radio_proc)
					d->d1 = luaL_checkinteger(l, 3);
				else
					luaL_error(l, "doesn't have group");
			}
			else if (key == "Style")
			{
				if (d->proc == d_radio_proc)
					d->d1 = luaL_checkinteger(l, 3);
				else
					luaL_error(l, "doesn't have style");
			}
			/* Bitmap/icon. */
			else if (key == "Bitmap")
			{
				if (d->proc == d_icon_proc)
				{
					DBitmap * b = new DBitmap();

					b->BitmapClass = (Bitmap *)FromLua(l, 3, false, "Bitmap")->Data;
					b->BitmapAllegro = b->BitmapClass->Get_Bitmap();

					FromLua(l, 3, false, "Bitmap")->Shared = true;

					if (d->dp)
					{
						DBitmap * b2 = (DBitmap *)d->dp;
						delete b2->BitmapClass;
						delete b2;
					}

					d->dp = b;
				}
				else if (d->proc == d_bitmap_proc)
				{
					Bitmap * b = (Bitmap *)FromLua(l, 3, false, "Bitmap")->Data;

					FromLua(l, 3, false, "Bitmap")->Shared = true;

					d->dp = b->Get_Bitmap();
					d->dp2 = b;
				}
				else
					luaL_error(l, "doesn't have bitmap");
			}
			/* Icon. */
			else if (key == "SelectedIcon")
			{
				if (d->proc == d_icon_proc)
				{
					DBitmap * b = new DBitmap();

					b->BitmapClass = (Bitmap *)FromLua(l, 3, false, "Bitmap")->Data;
					b->BitmapAllegro = b->BitmapClass->Get_Bitmap();

					FromLua(l, 3, false, "Bitmap")->Shared = true;

					if (d->dp2)
					{
						DBitmap * b2 = (DBitmap *)d->dp2;
						delete b2->BitmapClass;
						delete b2;
					}

					d->dp = b;
				}
				else
					luaL_error(l, "doesn't have selected icon");
			}
			else if (key == "DisabledIcon")
			{
				if (d->proc == d_icon_proc)
				{
					DBitmap * b = new DBitmap();

					b->BitmapClass = (Bitmap *)FromLua(l, 3, false, "Bitmap")->Data;
					b->BitmapAllegro = b->BitmapClass->Get_Bitmap();

					FromLua(l, 3, false, "Bitmap")->Shared = true;

					if (d->dp3)
					{
						DBitmap * d2 = (DBitmap *)d->dp3;
						delete d2->BitmapClass;
						delete d2;
					}

					d->dp3 = b;
				}
				else
					luaL_error(l, "doesn't have disabled icon");
			}
			else if (key == "Push")
				d->d1 = luaL_checkinteger(l, 3);
			else if (key == "Indent")
				d->d2 = luaL_checkinteger(l, 3);
			/* Button procedures. */
			else if (key == "OnClick")
			{
				if (d->proc == d_button_ex_proc)
				{
					if (lua_type(l, 3) == LUA_TFUNCTION)
					{
						d->d1 = false;
						d->d2 = luaL_ref(l, LUA_REGISTRYINDEX);
						d->dp2 = l;
					}
					else
						luaL_error(l, "function expected");
				}
				else
					luaL_error(l, "doesn't have onclick event");
			}
			/* Uh-oh. */
			else
				luaL_error(l, "%s is an invalid index", key.c_str());

			return 0;
		}

		const luaL_Reg dialog[] =
		{
			{ "__tostring", &ToString },
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ 0, 0 }
		};
	}

	namespace FDialogArray
	{
		class DialogArray
		{
			private:
				DIALOG * dialog;
				DIALOG_PLAYER * player;

				unsigned int size;

				int foregroundColor, backgroundColor;

				Font * dialogFont;
				Bitmap * buffer;

				bool deleteFont;

			public:
				DialogArray(DIALOG * d, unsigned int s)
					: dialog(d), size(s), foregroundColor(0), backgroundColor(0), dialogFont(0), buffer(0)
				{
					player = init_dialog(d, -1);
				}

				~DialogArray(void)
				{
					shutdown_dialog(player);

					for (DIALOG * d = dialog; d->proc; d++)
						FDialog::Delete(d, false);

					delete[] dialog;
				}

				void ReInitialize(void)
				{
					shutdown_dialog(player);
					player = init_dialog(dialog, -1);
				}

				#define StoreOldState() int fg = gui_fg_color, bg = gui_bg_color; \
					FONT * f = font; \
					BITMAP * b = gui_get_screen(); \
					gui_fg_color = foregroundColor; \
					gui_bg_color = backgroundColor; \
					if (dialogFont) font = dialogFont->Get_Font(); \
					if (buffer) gui_set_screen(buffer->Get_Bitmap());

				#define RestoreOldState() gui_fg_color = fg; \
					gui_bg_color = bg; \
					font = f; \
					gui_set_screen(b);

				/* Updates the dialog player. */
				bool Update(void)
				{
					StoreOldState();

					bool ret = update_dialog(player);

					RestoreOldState();

					return ret;
				}

				int DoDialog(void)
				{
					StoreOldState();

					int ret = do_dialog(dialog, -1);

					RestoreOldState();

					return ret;
				}

				int Popup(void)
				{
					StoreOldState();

					int ret = popup_dialog(dialog, -1);

					RestoreOldState();
					show_mouse(0);

					return ret;
				}

				void Broadcast(int message, int character)
				{
					int dummy = 0;
					
					StoreOldState();
					
					dialog_message(dialog, message, character, &dummy);

					RestoreOldState();
				}
				
				#undef StoreOldState
				#undef RestoreOldState

				void Set_Colors(int fg, int bg) { set_dialog_color(dialog, fg, bg); foregroundColor = fg; backgroundColor = bg; }
				void Center(void) { centre_dialog(dialog); }

				/* Sets and gets the colors. */
				int Get_ForegroundColor(void) const { return foregroundColor; }
				void Set_ForegroundColor(int c) { foregroundColor = c; }

				int Get_BackgroundColor(void) const { return backgroundColor; }
				void Set_BackgroundColor(int c) { backgroundColor = c; }

				/* Gets and sets the font and buffer. */
				Font * Get_Font(void) const { return dialogFont; }
				void Set_Font(Font * f, bool d) { if (deleteFont && dialogFont) delete dialogFont; dialogFont = f; deleteFont = d; }

				Bitmap * Get_Buffer(void) const { return buffer; }
				void Set_Buffer(Bitmap * b) { buffer = b; }

				DIALOG * Get_Dialog(unsigned int index) const { if (index < size) return &dialog[index]; else throw Exception("Invalid index.", "Logic error?"); }
				unsigned int Get_Total(void) const { return size; }
		};

		int ToString(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			lua_pushfstring(l, "Dialog Array [%d elements] (%p)", d->Get_Total(), FromLua(l, 1, false, "DialogArray"));

			return 1;
		}

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "DialogArray");

			if (!(o->Shared))
				delete (DialogArray *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			if (lua_type(l, 2) == LUA_TSTRING)
			{
				std::string key = luaL_checkstring(l, 2);

				lua_getmetatable(l, 1);
				lua_getfield(l, -1, key.c_str());

				if (!lua_isnil(l, -1))
					return 1;

				if (key == "Foreground")
					lua_pushinteger(l, d->Get_ForegroundColor());
				else if (key == "Background")
					lua_pushinteger(l, d->Get_BackgroundColor());
				else if (key == "Font")
					ToLua(l, d->Get_Font(), true, "Font");
				else if (key == "Buffer")
					ToLua(l, d->Get_Buffer(), true, "Bitmap");
				else
					luaL_error(l, "%s is an invalid index", key.c_str());
			}
			else
			{
				int index = luaL_checkinteger(l, 2);

				try
				{
					ToLua(l, d->Get_Dialog(index), true, "Dialog");
				}
				catch (const Exception& e)
				{
					luaL_error(l, "%d is out o' bounds: %s", index, e.what());
				}
			}

			return 1;
		}

		int NewIndex(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;
			std::string key = luaL_checkstring(l, 2);

			if (key == "ForegroundColor")
				d->Set_ForegroundColor(luaL_checkinteger(l, 3));
			else if (key == "BackgroundColor")
				d->Set_BackgroundColor(luaL_checkinteger(l, 3));
			else if (key == "Buffer")
			{
				Bitmap * b = (Bitmap *)FromLua(l, 3, false, "Bitmap")->Data;
				d->Set_Buffer(b);
			}
			else
				luaL_error(l, "%s is an invalid key", key.c_str());

			return 0;
		}

		int SetFont(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;
			LuaObject * o = FromLua(l, 2, false, "Font");
			bool del = lua_toboolean(l, 3);

			if (del)
				o->Shared = true;

			d->Set_Font((Font *)o->Data, del);

			return 0;
		}

		int Update(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			lua_pushboolean(l, d->Update());

			return 1;			
		}

		int DoDialog(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			lua_pushinteger(l, d->DoDialog());

			return 1;
		}

		int Popup(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			lua_pushinteger(l, d->Popup());

			return 1;
		}

		int ReInitialize(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			d->ReInitialize();

			return 0;
		}

		int Redraw(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			d->Broadcast(MSG_DRAW, 0);

			return 0;
		}

		int SetColors(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			d->Set_Colors(luaL_checkinteger(l, 2), luaL_checkinteger(l, 3));

			return 0;
		}

		int Center(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;

			d->Center();

			return 0;
		}
		
		#define StoreOldState() \
		int fg = gui_fg_color, bg = gui_bg_color; \
		FONT * f = font; \
		BITMAP * b = gui_get_screen(); \
		gui_fg_color = d->Get_ForegroundColor(); \
		gui_bg_color = d->Get_BackgroundColor(); \
		if (d->Get_Font()) font = d->Get_Font()->Get_Font(); \
		gui_set_screen(screen);
		
		#define RestoreOldState() \
		gui_fg_color = fg; \
		gui_bg_color = bg; \
		font = f; \
		gui_set_screen(b);
		
		int Alert(lua_State * l)
		{
			DialogArray * d = (DialogArray *)FromLua(l, 1, false, "DialogArray")->Data;
			
			StoreOldState();
			
			switch(lua_gettop(l))
			{
				case 4: /* Message and one button (plus shortcut key). */
					lua_pushinteger(l, alert(luaL_checkstring(l, 2), 0, 0, luaL_checkstring(l, 3), 0, luaL_checkinteger(l, 4) + 'A' - 1, 0));
					break;
					
				case 6: /* Message with two buttons (plus two shortcuts). */
					lua_pushinteger(l, alert(luaL_checkstring(l, 2), 0, 0, luaL_checkstring(l, 3), luaL_checkstring(l, 4), luaL_checkinteger(l, 5) + 'A' - 1, luaL_checkinteger(l, 6)+'A'));
					break;
				
				default:
					luaL_error(l, "invalid argument total");
			}
			
			RestoreOldState();
			show_mouse(0);
			
			return 1;
		}
		
		#undef StoreOldState
		#undef RestoreOldState

		const luaL_Reg dlgArray[] =
		{
			{ "__tostring", &ToString },
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "__newindex", &NewIndex },
			{ "SetFont", &SetFont },
			{ "Update", &Update },
			{ "DoDialog", &DoDialog },
			{ "Popup", &Popup },
			{ "ReInitialize", &ReInitialize },
			{ "Redraw", &Redraw },
			{ "SetColors", &SetColors },
			{ "Center", &Center },
			{ "Alert", &Alert },
			{ 0, 0 }
		};
	}

	namespace FDialogBuilder
	{
		void CopyDialog(DIALOG * to, DIALOG * from)
		{
			to->proc = from->proc;
			to->x = from->x;
			to->y = from->y;
			to->w = from->w;
			to->h = from->h;
			to->fg = from->fg;
			to->bg = from->bg;
			to->key = from->key;
			to->flags = from->flags;
			to->d1 = from->d1;
			to->d2 = from->d2;
			to->dp = from->dp;
			to->dp2 = from->dp2;
			to->dp3 = from->dp3;
			
			if (to->proc == d_text_proc || to->proc == d_ctext_proc || to->proc == d_rtext_proc ||
				to->proc == d_textbox_proc || to->proc == FDialog::d_button_ex_proc)
			{
				to->dp = ustrdup((char *)from->dp);

				if (to->proc == FDialog::d_button_ex_proc)
				{
					to->d1 = false;
					from->d1 = true;
				}
			}
			else if (to->proc == d_edit_proc)
			{
				to->dp = new char[from->d1];

				uszprintf((char *)to->dp, to->d1, "%s", (char *)from->dp);
			}
			else if (to->proc == d_bitmap_proc)
			{
				to->dp2 = new Bitmap((BITMAP *)from->dp, false);
				to->dp = ((Bitmap *)to)->Get_Bitmap();
			}
			/*else if (to->proc == d_icon_proc)
			{
				const unsigned int dpTotal = 3;
				FDialog::DBitmap * bmps[dpTotal] =
				{
					(FDialog::DBitmap *)from->dp,
					(FDialog::DBitmap *)from->dp2,
					(FDialog::DBitmap *)from->dp3
				};

				FDialog::DBitmap * toBmps[dpTotal] =
				{
					(FDialog::DBitmap *)to->dp,
					(FDialog::DBitmap *)to->dp2,
					(FDialog::DBitmap *)to->dp3
				};

				for (unsigned int i = 0; i < dpTotal; i++)
				{
					if (bmps[i]->BitmapClass)
					{
						Bitmap * b = new Bitmap(bmps[i]->BitmapAllegro, false);
						toBmps[i] = new FDialog::DBitmap();
						toBmps[i]->BitmapClass = b;
						toBmps[i]->BitmapAllegro = b->Get_Bitmap();
					}
					else
						bmps[i] = 0;
				}
			}*/
		}

		class DialogBuilder
		{
			private:
				std::vector<DIALOG *> dialogs;

			public:
				~DialogBuilder(void)
				{
					while (dialogs.size() > 0)
					{
						FDialog::Delete(dialogs.back());

						dialogs.pop_back();
					}
				}

				/* Adds a dialog to the list. When a dialog is added, all ownership is claimed by the
					dialog builder, and *not* whatever sent it here.  It *will* be deleted if removed. */
				void AddDialog(DIALOG * d)
				{
					dialogs.push_back(d);
				}

				/* Removes a dialog.  It will be deleted from the list. */
				void RemoveDialog(unsigned int index)
				{
					DIALOG * d = dialogs.at(index);

					FDialog::Delete(d);

					delete d;

					dialogs.erase(dialogs.begin() + index);
				}

				/* Returns the amount of dialogs in the list. */
				int Total(void) const { return dialogs.size(); }

				/* `Compiles' all the dialogs into one. */
				DIALOG * Compile(void)
				{
					DIALOG * dlgs = new DIALOG[dialogs.size() + 1]; /* The extra is for the ending nothingness. */

					for (unsigned int i = 0; i < dialogs.size(); i++)
						CopyDialog(&dlgs[i], dialogs[i]);

					DIALOG empty;
					memset(&empty, 0, sizeof(DIALOG));

					CopyDialog(&dlgs[dialogs.size()], &empty);

					return dlgs;
				}
		};

		/* Creates a new dialog builder. */
		int Create(lua_State * l)
		{
			DialogBuilder * d = new DialogBuilder();

			ToLua(l, d, false, "DialogBuilder");

			return 1;
		}

		const luaL_Reg dlgBuilderLib[] =
		{
			{ "Create", &Create },
			{ 0, 0 }
		};

		/* Index a dialog builder. */
		int ToString(lua_State * l)
		{
			DialogBuilder * d = (DialogBuilder *)FromLua(l, 1, false, "DialogBuilder")->Data;

			lua_pushfstring(l, "DialogBuilder [%d]", d->Total());

			return 1;
		}

		int Gc(lua_State * l)
		{
			LuaObject * o = FromLua(l, 1, false, "DialogBuilder");

			if (!(o->Shared))
				delete (DialogBuilder *)o->Data;

			return 0;
		}

		int Index(lua_State * l)
		{
			const char * key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key);

			if (!lua_isnil(l, -1))
				return 1;
			else
				luaL_error(l, "%s is an invalid index", key);

			return 0;
		}

		/* Actual functions! */
		int Add(lua_State * l)
		{
			DialogBuilder * d = (DialogBuilder *)FromLua(l, 1, false, "DialogBuilder")->Data;
			DIALOG * dlg = (DIALOG *)FromLua(l, 2, false, "Dialog")->Data;
			DIALOG * dlg2 = new DIALOG;

			CopyDialog(dlg2, dlg);

			d->AddDialog(dlg2);

			return 0;
		}

		int Remove(lua_State * l)
		{
			DialogBuilder * d = (DialogBuilder *)FromLua(l, 1, false, "DialogBuilder")->Data;

			try
			{
				d->RemoveDialog(luaL_checkinteger(l, 2));
			}
			catch (const std::exception& e)
			{
				luaL_error(l, e.what());
			}

			return 0;
		}

		int Compile(lua_State * l)
		{
			DialogBuilder * d = (DialogBuilder *)FromLua(l, 1, false, "DialogBuilder")->Data;
			DIALOG * dlg = d->Compile();
			FDialogArray::DialogArray * da = new FDialogArray::DialogArray(dlg, d->Total());

			ToLua(l, da, false, "DialogArray"); /* "DialogArray" is special. */

			return 1;
		}

		const luaL_Reg dlgBuilder[] =
		{
			{ "__tostring", &ToString },
			{ "__gc", &Gc },
			{ "__index", &Index },
			{ "Add", &Add },
			{ "Remove", &Remove },
			{ "Compile", &Compile },
			{ 0, 0 }
		};
	}
}
