#include <allegro.h>
#include <cstdio>
#include <string>
#include <vector>

#include "File.h"
#include "FLua.h"

namespace FLua
{
	namespace FFile
	{
		namespace FForEach
		{
			struct ForEach
			{
				public:
					std::string Name;
					int RequiredFlags, IgnoredFlags;

					std::vector<std::string> Files;

					ForEach(const std::string& n, int r = 0, int i = 0)
						: Name(n), RequiredFlags(r), IgnoredFlags(i)
					{
					}
			};

			int Create(lua_State * l)
			{
				ForEach * f = new ForEach(luaL_checkstring(l, 1));

				ToLua(l, f, false, "ForEach");

				return 1;
			}

			const luaL_Reg feLib[] =
			{
				{ "Create", &Create },
				{ 0, 0 }
			};

			int Gc(lua_State * l)
			{
				LuaObject * o = FromLua(l, 1, false, "ForEach");

				if (!(o->Shared))
					delete (ForEach *)o->Data;

				return 0;
			}

			int Index(lua_State *l)
			{
				ForEach * f = (ForEach *)FromLua(l, 1, false, "ForEach")->Data;
				std::string key = luaL_checkstring(l, 2);

				lua_getmetatable(l, 1);
				lua_getfield(l, -1, key.c_str());

				if (!lua_isnil(l, -1))
					return 1;

				if (key == "RequiredNone")
					lua_pushboolean(l, f->RequiredFlags & FA_NONE);
				else if (key == "IgnoredNone")
					lua_pushboolean(l, f->IgnoredFlags & FA_NONE);
				else if (key == "RequiredReadOnly")
					lua_pushboolean(l, f->RequiredFlags & FA_RDONLY);
				else if (key == "IgnoredReadOnly")
					lua_pushboolean(l, f->IgnoredFlags & FA_RDONLY);
				else if (key == "RequiredHidden")
					lua_pushboolean(l, f->RequiredFlags & FA_HIDDEN);
				else if (key == "IgnoredHidden")
					lua_pushboolean(l, f->IgnoredFlags & FA_HIDDEN);
				else if (key == "RequiredDirectories")
					lua_pushboolean(l, f->RequiredFlags & FA_DIREC);
				else if (key == "IgnoredDirectories")
					lua_pushboolean(l, f->IgnoredFlags & FA_DIREC);
				else
					luaL_error(l, "%s is an invalid index", key.c_str());

				return 1;
			}

			#define Toggle(v, f, i) { if (lua_toboolean(l, (i))) v |= f; else if ((v) & (f)) v ^= f; }

			int NewIndex(lua_State * l)
			{
				ForEach * f = (ForEach *)FromLua(l, 1, false, "ForEach")->Data;
				std::string key = luaL_checkstring(l, 2);

				if (key == "RequiredNone")
					Toggle(f->RequiredFlags, FA_NONE, 3)
				else if (key == "IgnoredNone")
					Toggle(f->IgnoredFlags, FA_NONE, 3)
				else if (key == "RequiredReadOnly")
					Toggle(f->RequiredFlags, FA_RDONLY, 3)
				else if (key == "IgnoredReadOnly")
					Toggle(f->IgnoredFlags, FA_RDONLY, 3)
				else if (key == "RequiredHidden")
					Toggle(f->RequiredFlags, FA_HIDDEN, 3)
				else if (key == "IgnoredHidden")
					Toggle(f->IgnoredFlags, FA_HIDDEN, 3)
				else if (key == "RequiredDirectories")
					Toggle(f->RequiredFlags, FA_DIREC, 3)
				else if (key == "IgnoredDirectories")
					Toggle(f->IgnoredFlags, FA_DIREC, 3)
				else
					luaL_error(l, "%s is an invalid index", key.c_str());

				return 0;
			}

			#undef Toggle

			int SearchCallback(const char * filename, int a, void * fp)
			{
				ForEach * f = (ForEach *)fp;

				f->Files.push_back(filename);

				return 0;
			}

			int Search(lua_State * l)
			{
				ForEach * f = (ForEach *)FromLua(l, 1, false, "ForEach")->Data;

				for_each_file_ex(f->Name.c_str(), f->RequiredFlags, f->IgnoredFlags, &SearchCallback, f);

				lua_newtable(l);

				for (std::vector<std::string>::iterator i = f->Files.begin(); i != f->Files.end(); i++)
				{
					lua_pushstring(l, (*i).c_str());
					luaL_ref(l, -2);
				}

				return 1;
			}

			const luaL_Reg fe[] =
			{
				{ "__gc", &Gc },
				{ "__index", &Index },
				{ "__newindex", &NewIndex },
				{ "Search", &Search },
				{ 0, 0 }
			};
		}
	}
}
