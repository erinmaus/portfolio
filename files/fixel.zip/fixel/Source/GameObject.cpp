#include <string>
#include <map>

#include "Bitmap.h"
#include "Exception.h"
#include "FLua.h"
#include "GameObject.h"
#include "Skill.h"
#include "Objector.h"
#include "Point.h"

GameObject::GameObject(Objector * o, lua_State * l, const std::string& f, int index)
	: objector(o), luaState(l), name(FLua::GetTableNameFromFilename(f))
{
	SaveStack(luaState);

	uid = FLua::DoFile(luaState, f);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, uid);
	lua_getfield(luaState, -1, name.c_str());
	lua_getfield(luaState, -1, "Initialize");

	if (!lua_isnil(luaState, -1))
	{
		lua_pushvalue(luaState, -2);
		FLua::ToLua(luaState, this, true, "GameObject");

		if (index > -1)
			lua_pushvalue(luaState, index);

		if (lua_pcall(luaState, (index > -1) ? 3 : 2, 0, 0) != 0)
			throw Exception(lua_tostring(luaState, -1), "Syntax error?");
	}

	RestoreStack(luaState);

	Synchronize();
}

GameObject::~GameObject(void)
{
	{
		SaveStack(luaState);

		lua_getglobal(luaState, FLua::GlobalTable);
		lua_rawgeti(luaState, -1, uid);
		lua_getfield(luaState, -1, name.c_str());
		lua_getfield(luaState, -1, "Destroy");

		if (!lua_isnil(luaState, -1))
		{
			lua_pushvalue(luaState, -2);

			if (lua_pcall(luaState, 1, 0, 0) != 0)
				throw Exception(lua_tostring(luaState, -1), "Syntax error?");
		}

		RestoreStack(luaState);
	}

	{
		SaveStack(luaState);

		lua_getglobal(luaState, FLua::GlobalTable);
		luaL_unref(luaState, -1, uid);

		RestoreStack(luaState);
	}
}

void GameObject::Synchronize(void)
{
	SaveStack(luaState);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, uid);
	lua_getfield(luaState, -1, name.c_str());

	/* Get the location. */
	lua_getfield(luaState, -1, "Location");

	if (!lua_isnil(luaState, -1))
	{
		Point * p = (Point *)FLua::FromLua(luaState, -1, false, "Point")->Data;

		location = *p;
	}
	else
	{
		location.X = 0;
		location.Y = 0;
	}

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "Width");

	if (!lua_isnil(luaState, -1))
		width = luaL_checkinteger(luaState, -1);
	else
		width = 1;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "Height");

	if (!lua_isnil(luaState, -1))
		height = luaL_checkinteger(luaState, -1);
	else
		height = 1;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "DrawOrder");

	if (!lua_isnil(luaState, -1))
		drawOrder = (DrawOrder)luaL_checkinteger(luaState, -1);
	else
		drawOrder = DrawNormal;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "YSortValue");

	if (!lua_isnil(luaState, -1))
		ySortValue = luaL_checkinteger(luaState, -1);
	else
		ySortValue = 0;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "AlwaysDraw");

	if (!lua_isnil(luaState, -1))
		alwaysDraw = lua_toboolean(luaState, -1);
	else
		alwaysDraw = false;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "CanMove");

	if (!lua_isnil(luaState, -1))
		canMove = lua_toboolean(luaState, -1);
	else
		canMove = false;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "IsInvincible");

	if (!lua_isnil(luaState, -1))
		isInvincible = lua_toboolean(luaState, -1);
	else
		isInvincible = true;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "IsDead");

	if (!lua_isnil(luaState, -1))
		isDead = lua_toboolean(luaState, -1);
	else
		isDead = false;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "IsSolid");

	if (!lua_isnil(luaState, -1))
		isSolid = lua_toboolean(luaState, -1);
	else
		isSolid = true;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "HasSpawned");

	if (!lua_isnil(luaState, -1))
		hasSpawned = lua_toboolean(luaState, -1);
	else
		hasSpawned = false;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "Team");

	if (!lua_isnil(luaState, -1))
		team = luaL_checkinteger(luaState, -1);
	else
		team = 0;

	lua_pop(luaState, 1);

	lua_getfield(luaState, -1, "TeamRank");

	if (!lua_isnil(luaState, -1))
		teamRank = luaL_checkinteger(luaState, -1);
	else
		teamRank = 0;

	lua_pop(luaState, 1);

	RestoreStack(luaState);
}

void GameObject::OnEvent(const std::string& e, int index)
{
	std::string s = "On";
	s += e;

	SaveStack(luaState);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, uid);
	lua_getfield(luaState, -1, name.c_str());
	lua_getfield(luaState, -1, s.c_str());

	if (!lua_isnil(luaState, -1))
	{
		lua_pushvalue(luaState, -2);

		if (index > -1)
			lua_pushvalue(luaState, index);

		if (lua_pcall(luaState, (index > -1) ? 2 : 1, 0, 0) != 0)
			throw Exception(lua_tostring(luaState, -1), "Syntax error?");
	}

	RestoreStack(luaState);

	Synchronize();
}

void GameObject::Update(void)
{
	SaveStack(luaState);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, uid);
	lua_getfield(luaState, -1, name.c_str());
	lua_getfield(luaState, -1, "Update");

	if (!lua_isnil(luaState, -1))
	{
		lua_pushvalue(luaState, -2);

		if (lua_pcall(luaState, 1, 0, 0) != 0)
			throw Exception(lua_tostring(luaState, -1), "Syntax error?");
	}

	RestoreStack(luaState);

	Synchronize();
}

void GameObject::Draw(Bitmap& buffer, Rectangle& cam)
{
	SaveStack(luaState);

	lua_getglobal(luaState, FLua::GlobalTable);
	lua_rawgeti(luaState, -1, uid);
	lua_getfield(luaState, -1, name.c_str());
	lua_getfield(luaState, -1, "Draw");

	if (!lua_isnil(luaState, -1))
	{
		lua_pushvalue(luaState, -2);
		FLua::ToLua(luaState, &buffer, true, "Bitmap");
		FLua::ToLua(luaState, &cam, true, "Rectangle");

		if (lua_pcall(luaState, 3, 0, 0) != 0)
			throw Exception(lua_tostring(luaState, -1), "Syntax error?");
	}

	RestoreStack(luaState);

	Synchronize();
}

bool GameObject::operator <(const GameObject& o)
{
	if (drawOrder == o.drawOrder)
	{
		if (location.Y - ySortValue < o.location.Y - o.ySortValue)
			return true;
		else if (location.Y - ySortValue > o.location.Y - ySortValue)
			return false;

		else
		{
			if (uid < o.uid)
				return true;
			else
				return false;
		}
	}
	else if (drawOrder == DrawNormal)
	{
		if (o.drawOrder == DrawLast)
			return true;
		else
			return false;
	}
	else if (drawOrder == DrawLast)
		return false;
	else if (drawOrder == DrawFirst)
		return true;
	else
		return false;

}

void GameObject::Remove(void) 
{ 
	objector->RemoveObject(this); 
}
