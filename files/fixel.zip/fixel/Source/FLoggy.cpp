#include "Exception.h"
#include "FLua.h"
#include "Loggy.h"

namespace FLua
{
	namespace FLoggy
	{
		int Index(lua_State * l)
		{
			const char * key = luaL_checkstring(l, 2);

			lua_getmetatable(l, 1);
			lua_getfield(l, -1, key);

			if (!lua_isnil(l, -1))
				return 1;

			luaL_error(l, "%s is an invalid index", key);

			return 0;
		}

		int Write(lua_State * l)
		{
			Loggy * loggy = (Loggy *)FromLua(l, 1, false, "Loggy")->Data;

			if (lua_type(l, 2) == LUA_TNUMBER)
				loggy->Write(luaL_checkinteger(l, 2), luaL_checkstring(l, 3));
			else if (lua_type(l, 2) == LUA_TSTRING && lua_gettop(l) > 2)
				loggy->Write(luaL_checkstring(l, 2), luaL_checkstring(l, 3));
			else
				loggy->Write("Script", luaL_checkstring(l, 2));

			return 0;
		}

		const luaL_Reg loggy[] =
		{
			{ "__index", &Index },
			{ "Write", &Write },
			{ 0, 0 }
		};
	}
}
