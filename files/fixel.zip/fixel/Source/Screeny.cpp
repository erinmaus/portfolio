#include <allegro.h>
#include <string>
#include <vector>

#include "Bitmap.h"
#include "Exception.h"
#include "Game.h"
#include "IManager.h"
#include "Screen.h"
#include "Screeny.h"

/* This removes every screen. A screen should only be allocated with new and never, ever should a screen
	be a local variable passed by address. */
Screeny::~Screeny(void)
{
	while(screens.size() > 0)
	{
		delete screens[screens.size() - 1];
		screens.pop_back();
	}

	screens.clear();
	toRemove.clear();
}

/* Updates every screen, and removes dead ones. */
void Screeny::Update(bool firstLogicRun)
{
	std::vector<Screen *> scr(screens);

	if (firstLogicRun)
	{
		bool covered = false, inFocus = true;

		for (unsigned int i = 1; i <= scr.size(); i++)
		{
			Screen * s = screens[scr.size() - i];

			/* Handle input if we aren't covered and are in focus. */
			if (inFocus && !covered)
				s->HandleInput(*(Get_Game()->Get_Input()));

			s->Update(covered, inFocus);

			if (!s->Get_IsPopup())
				covered = true;

			inFocus = false;
		}
	}

	while (toRemove.size() > 0)
	{
		Screen * s = toRemove.back();
		unsigned int index = 0;

		while (index < screens.size())
		{
			if (screens[index] == toRemove.back())
				break;

			index++;
		}

		screens.erase(screens.begin() + index);

		delete s;

		toRemove.pop_back();
	}

	toRemove.clear();
}

/* Draws each non-covered screen. */
void Screeny::Draw(Bitmap& bitmap)
{
	bool covered = false;

	for (unsigned int i = 1; i <= screens.size(); i++)
	{
		if (!covered)
			screens[screens.size() - i]->Draw(bitmap);

		if (!screens[screens.size() - i]->Get_IsPopup())
			covered = true;
	}
}

/* Gets a screen. */
Screen& Screeny::Get_Screen(const std::string& name, unsigned int index)
{
	for (unsigned int i = 0, f = 0; i < screens.size(); i++)
		if (screens[i]->Get_Name() == name)
		{
			f++;

			if (f >= index)
				return *screens[i];
		}

	throw Exception(std::string("Screen, ") + name + " not found.", "Logic error?");
}

/* Adds a screen. */
void Screeny::AddScreen(Screen * screen)
{
	screens.push_back(screen);

	screen->Initialize();
}

/* Removes a screen. */
void Screeny::RemoveScreen(Screen * screen)
{
	toRemove.push_back(screen);
}
