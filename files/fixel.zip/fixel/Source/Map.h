#ifndef F_MAP_H_
#define F_MAP_H_

#include <string>

#include "Exception.h"

enum TileFlags
{
	TileImpassable = 0x01,
	TileWater = 0x02,
	TileWall = 0x04,
	TileFloor = 0x08,
	TileSpecial = 0x10
};

class Map
{
	public: /* Sad that there has to be two of 'em. */
		struct Tile
		{
			public:
				int Index;
				int Flags;
				
				Tile(void) : Index(0), Flags(0) { }
				Tile(int i, int f) : Index(i), Flags(f) { }
		};

	private:
		int width, height; /* The width and height of the map. */
		Tile * tiles; /* The tile list. */

	public:
		Map(int w, int h);
		Map(const std::string& filename);
		~Map(void);

		/* Some constants. */
		static const int MagicNumber = 0x132231D0; /* 132 Ditto! */
		static const int Version = 1;
		
		/* Returns the tile at the given index. */
		inline Tile& Get_TileAtXY(int x, int y) const { if (x >= width || y >= height) throw Exception("Index is out o' bounds.", "Logic error?"); return tiles[y * width + x]; }
		inline Tile * Get_TileAtXYAsPointer(int x, int y) const { if (x >= width || y >= height) throw Exception("Index is out o' bounds.", "Logic error?"); return &tiles[y * width + x]; }
		
		inline int Get_Width(void) const { return width; }
		inline int Get_Height(void) const { return height; }
		
		/* Saves the map to a file. */
		void SaveToFile(const std::string& filename) const;
};

#endif
