#include <map>
#include <string>

#include "Exception.h"
#include "File.h"
#include "FLua.h"
#include "State.h"

STable::~STable(void)
{
	while(!table.empty())
	{
		delete (*table.begin()).second;
		table.erase(table.begin());
	}
}

void STable::ToFile(File& f) const
{
	for (std::map<std::string, IStateObject *>::const_iterator i = table.begin(); i != table.end(); i++)
	{
		f.Write((*i).second->Get_Id());
		(*i).second->ToFile(f);
		f.Write((*i).first);
	}

	f.Write(TableEnd);
}

void STable::FromFile(File& f)
{
	std::string id = "";

	while(!f.Get_IsEndOfFile() && id != TableEnd)
	{
		id = f.ReadString();
		std::map<std::string, ISerializer *>::iterator serializer = serializers.find(id);
		IStateObject * o;

		if (serializer != serializers.end())
			o = (*serializer).second->Get_Object();
		else if (id != TableEnd)
			throw Exception("Invalid ID: " + id, "Invalid file?");

		if (id != TableEnd)
		{
			for (std::map<std::string, ISerializer *>::iterator i = serializers.begin(); i != serializers.end(); i++)
				o->RegisterSerializer((*i).second, (*i).first);

			o->FromFile(f);

			table[f.ReadString()] = o;
		}
	}

	if (id != TableEnd)
		throw Exception("Invalid table.", "Invalid file?");
}

void STable::FromLua(lua_State * l, int index, bool recursive)
{
	std::string serializer = "";

	SaveStack(l);

	lua_pushnil(l);

	while (lua_next(l, (index < 0) ? index - 1 : index))
	{
		if (lua_type(l, -2) != LUA_TSTRING)
			throw Exception("That ain't no stinkin' string!", "Logic error?");

		switch(lua_type(l, -1))
		{
			case LUA_TNUMBER:
				if (serializers.find("Number") != serializers.end())
					serializer = "Number";
				break;

			case LUA_TSTRING:
				if (serializers.find("String") != serializers.end())
					serializer = "String";
				break;

			case LUA_TTABLE:
				if (serializers.find("Table") != serializers.end())
				{
					if (recursive)
						serializer = "Table";
					else
						throw Exception("No recursion allowed.", "Uh-oh.");
				}
				break;

			case LUA_TBOOLEAN:
				if (serializers.find("Boolean") != serializers.end())
					serializer = "Boolean";
				break;

			default:
				{
					SaveStack(l);

					luaL_getmetafield(l, -1, "__name");

					std::string s = luaL_checkstring(l, -1);

					if (serializers.find(s.c_str()) != serializers.end())
						serializer = s;
					else
						throw Exception("Blabla no valid serializer found.", "Logic error?");

					RestoreStack(l);
				}
				break;
		}

		IStateObject * n = serializers[serializer]->Get_Object();

		n->FromLua(l, -1, false);

		table[lua_tostring(l, -2)] = n;

		lua_pop(l, 1);
	}

	RestoreStack(l);
}

void STable::ObjectFromLua(lua_State * l, int index, const std::string& name)
{
	std::string serializer = "";

	SaveStack(l);

	switch(lua_type(l, index))
	{
		case LUA_TNUMBER:
			if (serializers.find("Number") != serializers.end())
				serializer = "Number";
			break;

		case LUA_TSTRING:
			if (serializers.find("String") != serializers.end())
				serializer = "String";
			break;

		case LUA_TTABLE:
			if (serializers.find("Table") != serializers.end())
				serializer = "Table";
			break;

		case LUA_TBOOLEAN:
			if (serializers.find("Boolean") != serializers.end())
				serializer = "Boolean";
			break;

		default:
			{
				SaveStack(l);

				luaL_getmetafield(l, index, "__name");

				std::string s = luaL_checkstring(l, index);

				if (serializers.find(s.c_str()) != serializers.end())
					serializer = s;
				else
					throw Exception("Blabla no valid serializer found.", "Logic error?");

				RestoreStack(l);
			}
			break;
	}

	if (serializer == "")
		throw Exception("No serializer found.", "Uh-oh.");

	IStateObject * o = serializers[serializer]->Get_Object();

	RestoreStack(l);

	for(std::map<std::string, ISerializer *>::iterator i = serializers.begin(); i != serializers.end(); i++)
		o->RegisterSerializer((*i).second, (*i).first);

	o->FromLua(l, index, false);

	table[name] = o;
}

void STable::ToTable(lua_State * l)
{
	lua_newtable(l);

	for (std::map<std::string, IStateObject *>::iterator i = table.begin(); i != table.end(); i++)
	{
		(*i).second->ToLua(l);
		lua_setfield(l, -2, (*i).first.c_str());
	}
}

IStateObject * STable::Get_Object(const std::string& n) const
{
	std::map<std::string, IStateObject *>::const_iterator obj = table.find(n);

	if (obj == table.end())
		throw Exception("Invalid index, `" + n + "'.", "Logic error?");

	return (*obj).second;
}

void STable::Set_Object(const std::string& n, IStateObject * o)
{
	table[n] = o;

	for (std::map<std::string, ISerializer *>::iterator i = serializers.begin(); i != serializers.end(); i++)
		o->RegisterSerializer((*i).second, (*i).first);
}

void STable::RegisterSerializer(ISerializer * serializer, const std::string& id)
{
	serializers[id] = serializer;

	for (std::map<std::string, IStateObject *>::iterator i = table.begin(); i != table.end(); i++)
		(*i).second->RegisterSerializer(serializer, id);
}

State::~State(void)
{
	std::map<std::string, ISerializer *> s = Get_Serializers();

	while(!s.empty())
	{
		delete (*s.begin()).second;
		s.erase(s.begin());
	}
}

void State::SaveToFile(const std::string& filename)
{
	File f(filename, FileModeWrite, true);

	f.Write(TableStart);

	ToFile(f);
}

void State::LoadFromFile(const std::string& filename)
{
	File f(filename, FileModeRead, true);

	if (f.ReadString() != "Table")
		throw Exception("Invalid file.", "No header `Table'");

	FromFile(f);
}
