#ifndef F_LOGGY_H_
#define F_LOGGY_H_

#include <cstdio>
#include <map>
#include <vector>

#include "Exception.h"
#include "IManager.h"

class Loggy
{
	private:
		std::map<std::string, FILE *> logsByName;
		std::vector<FILE *> logsByIndex;
		std::string absolutePath;

	public:
		Loggy(std::string ap) : absolutePath(ap) { std::string s = ap + "Logs/stderr.log"; if (!freopen(s.c_str(), "w", stderr)) throw DeadlyException("stderr refused to be rerouted!", "Invalid write permissions?"); }
		~Loggy(void);

		/* This adds a new log to the log dictionary and vector, and then returns its position in the
			vector.  It will throw an exception if the file couldn't be opened. Note: do not append a
			directory to the log--the file will automatically be opened in the `Logs' directory. */
		int AddLog(const std::string& filename, const std::string& header);

		/* This writes to the specified log file (by dictionary name). */
		void Write(const std::string& log, const std::string& message);
		
		/* This writes to the specified log file (by vector index). */
		void Write(unsigned int log, const std::string& message);
};

#endif
