#include <algorithm>
#include <string>
#include <vector>

#include "Game.h"
#include "GameObject.h"
#include "IManager.h"
#include "Loggy.h"
#include "Objector.h"

static bool Compare(GameObject * a, GameObject * b)
{
	return *a < * b;
}

Objector::~Objector(void)
{
	while (objects.size() > 0)
	{
		delete objects.back();

		objects.pop_back();
	}

	important.clear();
}

void Objector::AddObject(GameObject * o, bool important)
{
	objects.push_back(o);
	
	if (important)
		this->important.push_back(o);
}

void Objector::RemoveObject(GameObject * o)
{
	for (std::vector<GameObject *>::iterator i = objects.begin(); i != objects.end(); i++)
	{
		if ((*i)->Get_Uid() == o->Get_Uid())
		{
			toDelete.push_back(*i);

			objects.erase(i);

			break;
		}
	}

	for (std::vector<GameObject *>::iterator i = objects.begin(); i != objects.end(); i++)
	{
		if ((*i)->Get_Uid() == o->Get_Uid())
		{
			toDelete.push_back(*i);

			objects.erase(i);

			break;
		}
	}
}

void Objector::Clear(void)
{
	for(std::vector<GameObject *>::iterator i = objects.begin(); i != objects.end(); i++)
	{
		bool remove = true;

		for(std::vector<GameObject *>::iterator j = important.begin(); j != important.end(); j++)
		{
			if ((*i)->Get_Uid() == (*j)->Get_Uid())
				remove = false;
		}

		if (remove)
		{
			toDelete.push_back(*i);

			i = objects.erase(i);
		}
	}
}

void Objector::Broadcast(const std::string& e, int index)
{
	for (std::vector<GameObject *>::iterator i = objects.begin(); i != objects.end(); i++)
		(*i)->OnEvent(e, index);
}

void Objector::BroadcastToTeam(const std::string& e, int index, int team, int rank)
{
	for (std::vector<GameObject *>::iterator i = objects.begin(); i != objects.end(); i++)
	{
		if ((*i)->Get_Team() == team && (*i)->Get_TeamRank() > rank)
			(*i)->OnEvent(e, index);
	}
}

GameObject * Objector::Get_Object(const std::string& name, int index)
{
	int curIndex = 0;

	for (std::vector<GameObject *>::iterator i = objects.begin(); i != objects.end(); i++)
	{
		if ((*i)->Get_Name() == name)
		{
			curIndex++;

			if (curIndex >= index)
				return (*i);
		}
	}

	return 0;
}

GameObject * Objector::Get_ObjectAtPosition(const Point& loc, int index)
{
	Rectangle locRectangle(loc.X, loc.Y, 1, 1);
	int in = 0;

	for (std::vector<GameObject *>::iterator i = objects.begin(); i != objects.end(); i++)
	{
		Rectangle objLocation((*i)->Get_Location().X, (*i)->Get_Location().Y, (*i)->Get_Width(), (*i)->Get_Height());

		if (objLocation.Collision(locRectangle))
		{
			if (in >= index)
				return *i;

			in++;
		}
	}

	return 0;
}

void Objector::Update(void)
{
	while (toDelete.size() > 0)
	{
		delete toDelete.back();

		toDelete.pop_back();
	}

	std::vector<GameObject *> objs(objects);

	for (std::vector<GameObject *>::iterator i = objs.begin(); i != objs.end(); i++)
		(*i)->Update();

	std::sort(objects.begin(), objects.end(), Compare);
}

void Objector::Draw(Bitmap& buffer, Rectangle& cam)
{
	for (std::vector<GameObject *>::iterator i = objects.begin(); i != objects.end(); i++)
	{
		Rectangle r((*i)->Get_Location().X, (*i)->Get_Location().Y, (*i)->Get_Width(), (*i)->Get_Height());

		if (cam.Collision(r) || (*i)->Get_AlwaysDraw())
			(*i)->Draw(buffer, cam);
	}
}
