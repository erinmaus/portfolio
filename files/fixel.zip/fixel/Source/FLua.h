#ifndef F_LUA_H_
#define F_LUA_H_

extern "C"
{
	#include <lauxlib.h>
	#include <lua.h>
	#include <lualib.h>
}

#include <string>

struct LuaObject
{
	void * Data;
	bool Shared;
};

#define SaveStack(l) int _FLua_before = lua_gettop((l));

#define RestoreStack(l) \
	int _FLua_after = lua_gettop((l)); \
	lua_pop(l, _FLua_after - _FLua_before);

namespace FLua
{
	/* Helper functions. */
	/* This will get a LuaObject from the lua_State.  If `canBe0' is false, it will cause a Lua Error. */
	LuaObject * FromLua(lua_State * l, int index, bool canBeNull, const std::string& name);

	/* This converts an object to a lua_State userdatum. */
	void ToLua(lua_State * l, void * o, bool shared, const std::string& type);

	/* Gets a table name from a filename. */
	std::string GetTableNameFromFilename(const std::string& filename);

	/* This simply opens the libraries provided. */
	void OpenLibrary(lua_State * l, const luaL_Reg * mt, const luaL_Reg * lib, const std::string& name);

	/* This function is like DoFile, except it dumps everything into the GlobalTable instead of the global environment. */
	int DoFile(lua_State * l, const std::string& filename);

	/* This opens all the game's provided libraries. */
	void Initialize(lua_State * l);

	/* This function tells if the object at the provided index is the given type. */
	bool IsType(lua_State * l, int index, const std::string& type);

	static const char * GlobalTable = "Fixel";
	static const char * UtilitiesTable = "Utilities";
	static const int MaxKeyName = 32;

	namespace FBitmap { extern const luaL_Reg bitmapLib[]; extern const luaL_Reg bitmap[]; }
	namespace FControl { extern const luaL_Reg contLib[]; extern const luaL_Reg cont[]; }
	namespace FControls { extern const luaL_Reg cont[]; }
	namespace FDialog
	{
		enum DialogType
		{
			DialogClear,
			DialogBox,
			DialogBitmap,
			DialogLeftText,
			DialogCenterText,
			DialogRightText,
			DialogButton,
			DialogCheck,
			DialogRadio,
			DialogIcon,
			DialogEdit,
			DialogTextbox
		};

		extern const luaL_Reg dialogLib[];
		extern const luaL_Reg dialog[];
	}
	namespace FDialogArray { extern const luaL_Reg dlgArray[]; }
	namespace FDialogBuilder { extern const luaL_Reg dlgBuilderLib[]; extern const luaL_Reg dlgBuilder[]; }
	namespace FFile
	{
		namespace FForEach { extern const luaL_Reg feLib[]; extern const luaL_Reg fe[]; }
	}
	namespace FFont { extern const luaL_Reg fontLib[]; extern const luaL_Reg font[]; }
	namespace FGame { extern const luaL_Reg game[]; }
	namespace FGameObject { extern const luaL_Reg go[]; }
	namespace FGraphics { extern const luaL_Reg graphics[]; }
	namespace FInput { extern const luaL_Reg input[]; }
	namespace FLoggy { extern const luaL_Reg loggy[]; }
	namespace FMap { extern const luaL_Reg mapLib[]; extern const luaL_Reg map[]; } /* New. */
	namespace FMapTile { extern const luaL_Reg mapTile[]; } /* New. */
	namespace FObjector { extern const luaL_Reg objector[]; }
	namespace FPoint { extern const luaL_Reg pointLib[]; extern const luaL_Reg point[]; }
	namespace FRectangle { extern const luaL_Reg rectLib[]; extern const luaL_Reg rect[]; }
	namespace FSample { extern const luaL_Reg sampleLib[]; extern const luaL_Reg sample[]; }
	namespace FScreen { extern const luaL_Reg screen[]; }
	namespace FScreeny { extern const luaL_Reg screeny[]; }
	namespace FSMapTile { extern const luaL_Reg smTile[]; } /* New. */
	namespace FSTable { extern const luaL_Reg st[]; }
	namespace FStage { extern const luaL_Reg stageLib[]; extern const luaL_Reg stage[]; } /* New. */
	namespace FState { extern const luaL_Reg stateLib[]; extern const luaL_Reg state[]; }
	namespace FTileSheet { extern const luaL_Reg tsLib[]; extern const luaL_Reg ts[]; } /* New. */
	namespace FTileSheetTile { extern const luaL_Reg tsTileLib[]; extern const luaL_Reg tsTile[]; } /* New. */
}

#endif
