#ifndef F_GAME_H_
#define F_GAME_H_

#include <allegro.h>
#include <string>
#include <vector>

#ifdef ALLEGRO_WINDOWS
	#ifndef WIN32_LEAN_AND_MEAN
		#define WIN32_LEAN_AND_MEAN
	#endif
	#ifndef NOGDI
		#define NOGDI
	#endif
	#include <winalleg.h>
#endif

#include "FLua.h"
#include "ManagerList.h"

class Bitmap;
class Font;
class IManager;
class Input;
class Loggy;
class Screeny;
class State;

struct Controls;

class Game
{
	private:
		/* The manager list. */
		std::vector<class IManager *> managers;
		std::vector<std::string> arguments;

		std::string absolutePath;

		/* Various managers. */
		class Input * input;
		class Loggy * loggy;
		class Screeny * screeny;

		ManagerList objects; /* The objects list. */

		class Bitmap * buffer; /* The double-buffer. */
		class Bitmap * screen; /* The screen. */
		class Font * defFont; /* Default font. */

		/* Player data. */
		struct Controls * controls;
		class State * options;

		/* Game control. */
		bool running;
		bool paused;

		/* The heart of the game. */
		lua_State * luaState;

		/* If the mouse is showing or not. */
		bool showMouse;

		#ifdef ALLEGRO_WINDOWS
			LARGE_INTEGER freq;
		#endif

		double currentTime;
		double elapsedTime;

		void UpdateTime(void);
	public:
		static const int MajorVersion = 0;
		static const int MinorVersion = 1;
		static const int ImportantRevision = 50408;

		Game(std::vector<std::string> args);
		~Game(void);

		void Initialize(void);

		/* Runs and draws the game, respectively. */
		void Run(void);
		void Draw(void);

		inline class Input * Get_Input(void) const { return input; }
		inline class Loggy * Get_Loggy(void) const { return loggy; }
		inline class Screeny * Get_Screeny(void) const { return screeny; }

		inline struct Controls * Get_Controls(void) const { return controls; }
		inline class State * Get_Options(void) const { return options; }

		inline const std::string& Get_AbsolutePath(void) const { return absolutePath; }

		inline class Font * Get_Font(void) const { return defFont; }

		inline void Quit(void) { running = false; }

		inline const std::string& Get_Argument(unsigned int index) const { return arguments.at(index); }
		inline unsigned int Get_ArgumentTotal(void) const { return arguments.size(); }

		inline bool Get_ShowMouse(void) const { return showMouse; }
		inline void Set_ShowMouse(bool show) { showMouse = show; }

		inline void Pause(void) { paused = true; }
		inline void Continue(void) { paused = false; }
		inline bool Get_IsPaused(void) { return paused; }

		/* Gets stuff. */
		inline void RegisterObject(const std::string& path, const std::string& name) { objects.Add(name, path); }
		inline void UnregisterObject(const std::string& name) { objects.Remove(name); }
		inline const std::string& Get_RegisteredObjectPath(const std::string& name) const { return objects.Find(name); }

		inline double Get_CurrentTime(void) const { return currentTime; }
		inline double Get_ElapsedTime(void) const { return elapsedTime; }
};

#endif
