#ifndef F_TILESHEET_H_
#define F_TILESHEET_H_

#include <string>
#include <vector>

#include "Exception.h"
#include "Color.h"

class TileSheet
{
	public:
		struct Tile
		{
			public:
				Color Border; /* The tile's border color. */
				Color Inner; /* The tile's inner color. */

				int Next; /* The next tile to go to when the tile's animation ends. */

				double Speed; /* The speed this tile changes to the next. */

				Tile(void) : Border(0), Inner(0), Next(0), Speed(0.0) { }
				Tile(const struct Tile& t) : Border(t.Border), Inner(t.Inner), Next(t.Next), Speed(t.Speed) { }
		};

	private:
		std::vector<Tile *> tiles;

	public:
		static const int MagicNumber = 0x132D1770; /* 132 Ditto! */
		static const int Version = 1;

		TileSheet(void) { }
		TileSheet(const std::string& filename);
		~TileSheet(void);

		Tile& Get_TileAt(int index) const { return *tiles.at(index); }
		Tile * Get_TileAtAsPointer(unsigned int index) const { return tiles.at(index); }
		void Set_TileAt(int index, Tile * t) { tiles.at(index) = t; }

		inline unsigned int Get_Total(void) const { return tiles.size(); }

		void AddTile(const Tile& t) { tiles.push_back(new Tile(t)); }
		void RemoveTileAt(int index);

		void SaveToFile(const std::string& filename) const;
};

#endif
