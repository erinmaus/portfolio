#include <allegro.h>
#include <cstring>

#include "FLua.h"

/* For enumerations. */
#include "Bitmap.h"
#include "Font.h"
#include "GameObject.h"
#include "Input.h"
#include "Sample.h"

/* For exceptions. */
#include "Exception.h"

namespace FLua
{
	LuaObject * FromLua(lua_State * l, int index, bool canBeNull, const std::string& name)
	{
		LuaObject * o = (LuaObject *)luaL_checkudata(l, index, name.c_str());

		if (!o || (!(o->Data) && !canBeNull))
			luaL_error(l, "at position %d in stack: expected valid %s, got null", index, name.c_str());

		return o;
	}

	void ToLua(lua_State * l, void * o, bool shared, const std::string& type)
	{
		LuaObject * lo = (LuaObject *)lua_newuserdata(l, sizeof(LuaObject));

		if (!lo)
			luaL_error(l, "out of memory");

		lo->Data = o;
		lo->Shared = shared;

		luaL_getmetatable(l, type.c_str());

		lua_setmetatable(l, -2);
	}

	std::string GetTableNameFromFilename(const std::string& filename)
	{
		std::string table;

		char * name = new char[filename.size()];
		strncpy(name, filename.c_str(), filename.size());

		name[filename.size() - 1] = '\0';

		*(get_extension(get_filename(name)) - 1) = '\0';

		table = get_filename(name);

		delete[] name;

		return table;
	}

	void OpenLibrary(lua_State * l, const luaL_Reg * mt, const luaL_Reg * lib, const std::string& name)
	{
		if (mt)
		{
			luaL_newmetatable(l, name.c_str());
			luaL_register(l, 0, mt);

			lua_pushstring(l, name.c_str());
			lua_setfield(l, -2, "__name");
		}

		if (lib)
		{
			lua_newtable(l);
			luaL_register(l, 0, lib);
			lua_setglobal(l, name.c_str());
		}
	}

	int DoFile(lua_State * l, const std::string& filename)
	{
		SaveStack(l);

		/* We get the global environment table to store the chunk. */
		lua_getglobal(l, "getfenv");

		/* Make sure it exists.  Need I comment this again? */
		if (lua_isnil(l, -1))
			luaL_error(l, "getfenv is nil");

		lua_pushinteger(l, 0);

		/* Call getfenv(0) to get the global environment. */
		if (lua_pcall(l, 1, 1, 0) != 0)
			lua_error(l);

		/* Get `GlobalTable' and make sure it exists... */
		lua_getfield(l, -1, GlobalTable);

		if (lua_isnil(l, -1))
			luaL_error(l, "the global table is nil");

		/* We load the chunk. */
		if (luaL_loadfile(l, filename.c_str()) != 0)
			lua_error(l);

		/* ...and store the baby in the global table. */
		int ref = luaL_ref(l, -2);

		/* Check to make sure there are no stinkin' errors. */
		if (ref == LUA_NOREF)
			luaL_error(l, "no space left in global table");

		/* Get it back. */
		lua_rawgeti(l, -1, ref);

		/* The global environment is 3 stack positions behind us (<chunk>, <global table>, <global environment>). */
		lua_getfield(l, -3, UtilitiesTable);

		if (lua_isnil(l, -1))
			luaL_error(l, "utilities table is nil");

		/* Get the duplicate-table-function. */
		lua_getfield(l, -1, "DuplicateGlobalTable");

		if (lua_isnil(l, -1))
			luaL_error(l, "`DuplicateGlobalTable' is nil");

		/* Call DuplicateGlobalTable now. */
		if (lua_pcall(l, 0, 1, 0) != 0)
			lua_error(l);

		/* Make a copy of the environment for later. */
		lua_pushvalue(l, -1);

		/* Set the environment for the chunk. */
		lua_setfenv(l, -4);

		/* Now push it and then call it. */
		lua_pushvalue(l, -3);

		if (lua_pcall(l, 0, 0, 0) != 0)
			lua_error(l);

		/* Now get back the global environment. */
		lua_getglobal(l, "getfenv");
		lua_pushinteger(l, 0);

		if (lua_pcall(l, 1, 1, 0) != 0)
			lua_error(l);

		/* Get the global table. */
		lua_getfield(l, -1, GlobalTable);

		/* Add the environment to the table and we're done! */
		lua_pushvalue(l, -3);

		lua_rawseti(l, -2, ref);

		RestoreStack(l);

		return ref;
	}

	void Initialize(lua_State * l)
	{
		OpenLibrary(l, FBitmap::bitmap, FBitmap::bitmapLib, "Bitmap");
		OpenLibrary(l, FControl::cont, FControl::contLib, "Control");
		OpenLibrary(l, FControls::cont, 0, "Controls");
		OpenLibrary(l, FDialog::dialog, FDialog::dialogLib, "Dialog");
		OpenLibrary(l, FDialogArray::dlgArray, 0, "DialogArray");
		OpenLibrary(l, FDialogBuilder::dlgBuilder, FDialogBuilder::dlgBuilderLib, "DialogBuilder");
		OpenLibrary(l, FFile::FForEach::fe, FFile::FForEach::feLib, "ForEach");
		OpenLibrary(l, FFont::font, FFont::fontLib, "Font");
		OpenLibrary(l, FGame::game, 0, "Game");
		OpenLibrary(l, FGameObject::go, 0, "GameObject");
		OpenLibrary(l, 0, FGraphics::graphics, "Graphics");
		OpenLibrary(l, FInput::input, 0, "Input");
		OpenLibrary(l, FLoggy::loggy, 0, "Loggy");
		OpenLibrary(l, FMap::map, FMap::mapLib, "Map");
		OpenLibrary(l, FMapTile::mapTile, 0, "MapTile");
		OpenLibrary(l, FObjector::objector, 0, "Objector");
		OpenLibrary(l, FPoint::point, FPoint::pointLib, "Point");
		OpenLibrary(l, FRectangle::rect, FRectangle::rectLib, "Rectangle");
		OpenLibrary(l, FSample::sample, FSample::sampleLib, "Sample");
		OpenLibrary(l, FScreen::screen, 0, "Screen");
		OpenLibrary(l, FScreeny::screeny, 0, "Screeny");
		OpenLibrary(l, FSMapTile::smTile, 0, "SMapTile");
		OpenLibrary(l, FSTable::st, 0, "STable");
		OpenLibrary(l, FStage::stage, FStage::stageLib, "Stage");
		OpenLibrary(l, FState::state, FState::stateLib, "State");
		OpenLibrary(l, FTileSheet::ts, FTileSheet::tsLib, "TileSheet");
		OpenLibrary(l, FTileSheetTile::tsTile, FTileSheetTile::tsTileLib, "TileSheetTile");

		lua_newtable(l);
			lua_pushinteger(l, DrawFirst);
			lua_setfield(l, -2, "First");

			lua_pushinteger(l, DrawLast);
			lua_setfield(l, -2, "Last");

			lua_pushinteger(l, DrawNormal);
			lua_setfield(l, -2, "Normal");

			lua_pushinteger(l, DrawMax);
			lua_setfield(l, -2, "Max");
		lua_setglobal(l, "DrawOrder");

		lua_newtable(l);
			lua_pushinteger(l, SampleSquareWave);
			lua_setfield(l, -2, "Square");

			lua_pushinteger(l, SampleSineWave);
			lua_setfield(l, -2, "Sine");

			lua_pushinteger(l, SampleTriangleWave);
			lua_setfield(l, -2, "Triangle");
		lua_setglobal(l, "SampleWave");

		/* Dialog type stuff. */
		lua_newtable(l);
		{
			using namespace FDialog;

			lua_pushinteger(l, DialogClear);
			lua_setfield(l, -2, "Clear");

			lua_pushinteger(l, DialogBox);
			lua_setfield(l, -2, "Box");

			lua_pushinteger(l, DialogBitmap);
			lua_setfield(l, -2, "Bitmap");

			lua_pushinteger(l, DialogLeftText);
			lua_setfield(l, -2, "LeftLabel");

			lua_pushinteger(l, DialogCenterText);
			lua_setfield(l, -2, "CenterLabel");

			lua_pushinteger(l, DialogRightText);
			lua_setfield(l, -2, "RightLabel");

			lua_pushinteger(l, DialogButton);
			lua_setfield(l, -2, "Button");

			lua_pushinteger(l, DialogCheck);
			lua_setfield(l, -2, "Check");

			lua_pushinteger(l, DialogRadio);
			lua_setfield(l, -2, "RadioButton");

			lua_pushinteger(l, DialogIcon);
			lua_setfield(l, -2, "IconButton");

			lua_pushinteger(l, DialogEdit);
			lua_setfield(l, -2, "EditBox");

			lua_pushinteger(l, DialogTextbox);
			lua_setfield(l, -2, "Textbox");
		}
		lua_setglobal(l, "DialogType");

		/* Dialog messages. */
		lua_newtable(l);
			lua_pushinteger(l, D_O_K);
			lua_setfield(l, -2, "Ok");

			lua_pushinteger(l, D_CLOSE);
			lua_setfield(l, -2, "Close");

			lua_pushinteger(l, D_REDRAW);
			lua_setfield(l, -2, "Redraw");

			lua_pushinteger(l, D_REDRAWME);
			lua_setfield(l, -2, "RedrawSelf");

			lua_pushinteger(l, D_WANTFOCUS);
			lua_setfield(l, -2, "RequestFocus");

			lua_pushinteger(l, D_USED_CHAR);
			lua_setfield(l, -2, "UsedCharacter");

			lua_pushinteger(l, D_REDRAW_ALL);
			lua_setfield(l, -2, "RedrawAll");

			lua_pushinteger(l, D_DONTWANTMOUSE);
			lua_setfield(l, -2, "IgnoreMouse");
		lua_setglobal(l, "DialogReturn");

		/* PrimitiveMode enumeration. */
		lua_newtable(l);
			lua_pushinteger(l, PrimitiveModeLined);
			lua_setfield(l, -2, "Lined");

			lua_pushinteger(l, PrimitiveModeFilled);
			lua_setfield(l, -2, "Filled");
		lua_setglobal(l, "PrimitiveMode");

		/* FontDrawType enumeration. */
		lua_newtable(l);
			lua_pushinteger(l, FontDrawLeft);
			lua_setfield(l, -2, "Left");

			lua_pushinteger(l, FontDrawRight);
			lua_setfield(l, -2, "Right");

			lua_pushinteger(l, FontDrawCentered);
			lua_setfield(l, -2, "Centered");

			lua_pushinteger(l, FontDrawMax);
			lua_setfield(l, -2, "Max");
		lua_setglobal(l, "FontDrawType");

		/* ButtonState enumeration. */
		lua_newtable(l);
			lua_pushinteger(l, ButtonPressed);
			lua_setfield(l, -2, "JustPressed");

			lua_pushinteger(l, ButtonReleased);
			lua_setfield(l, -2, "JustReleased");

			lua_pushinteger(l, ButtonNotHeld);
			lua_setfield(l, -2, "Released");

			lua_pushinteger(l, ButtonHeld);
			lua_setfield(l, -2, "Pressed");
		lua_setglobal(l, "ButtonState");

		/* Mouse button fun. */
		lua_newtable(l);
			lua_pushinteger(l, MouseButtonLeft);
			lua_setfield(l, -2, "Left");

			lua_pushinteger(l, MouseButtonRight);
			lua_setfield(l, -2, "Right");

			lua_pushinteger(l, MouseButtonMiddle);
			lua_setfield(l, -2, "Middle");
		lua_setglobal(l, "MouseButton");

		/* Control type enumeration. */
		lua_newtable(l);
			lua_pushinteger(l, ControlKeyboard);
			lua_setfield(l, -2, "Keyboard");

			lua_pushinteger(l, ControlJoystick);
			lua_setfield(l, -2, "Joystick");
		lua_setglobal(l, "ControlType");

		/* Direction enumeration. */
		lua_newtable(l);
			lua_pushinteger(l, DirectionUp);
			lua_setfield(l, -2, "Up");

			lua_pushinteger(l, DirectionDown);
			lua_setfield(l, -2, "Down");

			lua_pushinteger(l, DirectionLeft);
			lua_setfield(l, -2, "Left");

			lua_pushinteger(l, DirectionRight);
			lua_setfield(l, -2, "Right");

			lua_pushinteger(l, DirectionMax);
			lua_setfield(l, -2, "Max");
		lua_setglobal(l, "Direction");

		/* Key codes. */
		lua_newtable(l);
		{
			const char keys[KEY_MAX][MaxKeyName] =
			{
				{ "A" }, { "B" }, { "C" }, { "D" }, { "E" }, { "F" }, { "G" }, { "H" }, { "I" }, { "J" }, { "K" }, { "L" }, { "M" }, { "N" }, { "O" }, { "P" }, { "Q" }, { "R" }, { "S" }, { "T" }, { "U" }, { "V" }, { "W" }, { "X" }, { "Y" }, { "Z"},
				{ "Number0" }, { "Number1" }, { "Number2" }, { "Number3" }, { "Number4" }, { "Number5" }, { "Number6" }, { "Number7" }, { "Number8" }, { "Number9" }, { "Pad0" }, { "Pad1" }, { "Pad2" }, { "Pad3" }, { "Pad4" }, { "Pad5" }, { "Pad6" }, { "Pad7" }, { "Pad8" }, { "Pad9" },
				{ "F1" }, { "F2" }, { "F3" }, { "F4" }, { "F5" }, { "F6" }, { "F7" }, { "F8" }, { "F9" }, { "F10" }, { "F11" }, { "F12" },
				{ "Esc" }, { "Tilde" }, { "Minus" }, { "Equals" }, { "Backspace" }, { "Tab" }, { "OpenBrace" }, { "CloseBrace" }, { "Enter" }, { "Colon" }, { "Quote" },
				{ "Backslash" }, { "Backslash2" }, { "Comma" }, { "Stop" }, { "Slash" }, { "Space" }, { "Insert" }, { "Delete" }, { "Home" }, { "End" }, { "PageUp" }, { "PageDown" },
				{ "ArrowLeft" }, { "ArrowRight" }, { "ArrowUp" }, { "ArrowDown" },
				{ "PadSlash" }, { "PadMinus" }, { "PadPlus" }, { "PadDelete" }, { "PadEnter" },
				{ "PrintScreen" }, { "Pause" }, { "AbntC1" }, { "Yen" }, { "Kana" }, { "Convert" }, { "NoConvert" }, { "At" }, { "Circumflex" }, { "Colon2" }, { "Kanji" }, { "PadEquals" },
				{ "Backquote" }, { "Semicolon" }, { "Command" },
				{ "Modifiers" } /* Don't use it. */, { "LeftShift" }, { "RightShift" }, { "LeftControl" }, { "RightControl" }, { "Alt" }, { "AltGr" }, { "LeftWindows" }, { "RightWindows" }, { "Menu" }, { "ScrollLock" }, { "NumLock" }, { "CapsLock" }, 
				{ "Unknown1" }, { "Unknown2" }, { "Unknown3" }, { "Unknown4" }, { "Unknown5" }, { "Unknown6" }, { "Unknown7" }, { "Unknown8" },
				{ "Max" }
			};

			for (int i = 0; i < KEY_MAX; i++)
			{
				lua_pushinteger(l, i + 1);
				lua_setfield(l, -2, keys[i]);
			}
		}
		lua_setglobal(l, "Key");

		{
			const luaL_Reg libs[] =
			{
				{ "package", &luaopen_package },
				{ "", &luaopen_base },
				{ "table", &luaopen_table },
				{ "os", &luaopen_os },
				{ "string", &luaopen_string },
				{ "math", &luaopen_math },
				{ "debug", &luaopen_debug },
				{ 0, 0 }
			};


			for (int i = 0; libs[i].func; i++)
			{				
				lua_pushcfunction(l, libs[i].func);
				lua_pushstring(l, libs[i].name);

				if (lua_pcall(l, 1, 0, 0) != 0)
					throw Exception(lua_tostring(l, -1), "Eeek!");
			}
		}
	}

	bool IsType(lua_State * l, int index, const std::string& type)
	{
		bool eq = false;

		luaL_getmetatable(l, type.c_str());
		
		if (lua_getmetatable(l, index) != 0)
		{

			if (lua_rawequal(l, -1, -2))
				eq = true;

			lua_pop(l, 2);
		}

		return eq;
	}
}
