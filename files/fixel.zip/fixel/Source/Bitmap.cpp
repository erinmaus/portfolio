#include <allegro.h>

#include "Bitmap.h"
#include "Exception.h"

Bitmap::Bitmap(BITMAP * b, bool share)
	: shared(share)
{
	if (!b)
		throw Exception("The passed bitmap was 0.", "Logic error?");

	if (!share)
	{
		bitmap = create_bitmap(b->w, b->h);

		if (!bitmap)
			throw Exception("Couldn't allocate bitmap.", "Out of memory?");

		blit(b, bitmap, 0, 0, 0, 0, bitmap->w, bitmap->h);
	}
	else
		bitmap = b;

	InitializeClippingRegion();
}

Bitmap::Bitmap(int w, int h, int color)
	: shared(false)
{
	bitmap = create_bitmap(w, h);

	if (!bitmap)
		throw Exception("Couldn't allocate bitmap.", "Out of memory?");

	clear_to_color(bitmap, color);

	InitializeClippingRegion();
}

Bitmap::Bitmap(const std::string& filename)
	: shared(false)
{
	bitmap = load_bitmap(filename.c_str(), 0);

	if (!bitmap)
	{
		std::string s = "Couldn't load bitmap: ";
		s += filename;

		throw Exception(s, "Out of memory? Invalid filename?");
	}

	InitializeClippingRegion();
}

void Bitmap::Clear(int color)
{
	clear_to_color(bitmap, color);
}

void Bitmap::DrawTrans(Bitmap& to, int x, int y)
{
	draw_trans_sprite(to.Get_Bitmap(), bitmap, x, y);
}

void Bitmap::DrawPrimitive(const Rectangle& r, PrimitiveMode m, int c)
{
	if (m == PrimitiveModeFilled)
		rectfill(bitmap, r.X, r.Y, r.X + r.Width, r.Y + r.Height, c);
	else if (m == PrimitiveModeLined)
		rect(bitmap, r.X, r.Y, r.X + r.Width, r.Y + r.Height, c);
	else
		throw Exception("Invalid primitive mode.", "Logic error?");
}

void Bitmap::Set_ClippingRegion(const Rectangle& r)
{
	set_clip_rect(bitmap, r.X, r.Y, r.Width + r.X, r.Height + r.Y);

	clipping = r;
}

void Bitmap::InitializeClippingRegion(void)
{
	get_clip_rect(bitmap, &clipping.X, &clipping.Y, &clipping.Width, &clipping.Height);

	clipping.Width -= clipping.X;
	clipping.Height -= clipping.Y;
}
