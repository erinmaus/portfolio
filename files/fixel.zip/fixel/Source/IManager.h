#ifndef F_IMANAGER_H_
#define F_IMANAGER_H_

class Bitmap;
class Game;

class IManager
{
	private:
		class Game * game;

		/* No copy constructor.  It could be dangerous... */
		IManager(const class IManager& m) { }

	public:
		IManager(class Game * g) : game(g) { }
		virtual ~IManager(void) { }

		/* Initializes the manager.  This is called by the game class *after* everything important is initialized.
			However, it can not be assumed that all managers have been initialized, so do not try and access another
			manager during initialization. */
		virtual void Initialize(void) { }

		/* Updates the manager.  Here, you can access other managers since they have all been initialized by now.
			This should operate as fast as possible.  This function is required to be overriden. */
		virtual void Update(bool firstRun) = 0;

		/* Draws the manager.  It should be fast and simply just draw the manager and do nothing else. */
		virtual void Draw(class Bitmap& buffer) { }

		/* Returns the game. */
		inline class Game * Get_Game(void) const { return game; }
};

#endif
