#ifndef F_SKILL_H_
#define F_SKILL_H_

#include <cmath>

class ISkill
{
	private:
		double xp; /* The skill's total XP. */
		double addXp; /* The additional XP. */

	public:
		ISkill(void) : xp(0.0) { }
		ISkill(double x) : xp(x) { }

		double Get_Xp(void) const { return xp; }
		void Set_Xp(double x) { xp = x; }

		void AddXp(double x) { xp += x; }

		int Get_Level(void) const { return Get_LevelForXp(xp); }
		int Get_CurrentLevel(void) const { return Get_LevelForXp(xp + addXp); }

		virtual double Get_XpForLevel(int level) const = 0;
		virtual int Get_LevelForXp(double xp) const = 0;
};

class StandardSkill
{
	public:
		double Get_XpForLevel(int level) const { return pow(level * 1.75, 3); }
		int Get_LevelForXp(double xp) const { return ceil(pow(xp, 1 / 3) / 1.75); }
};

#endif
