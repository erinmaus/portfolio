Fixel "ReadMe"
---------------
	Blabla, readme for Fixel.  Enable wordwrap...

Controls:
	~ W, S, A, D to move
	~ K, L to cycle spells
	~ <, > to cycle items
	~ M to use spells
	~ ? to use items
	~ (Right) Shift to change direction

Notes:
	If the game runs too slow when there are too many particles on the screen, adjust the blending settings by going to the Options screen, clicking the `>' arrow, and switching off additive (and then, if it is still too slow), translucent blending.

Other
-----------------
Visit the Fixel web page at the following address!
	- http://veivagames.googlepages.com/fixel.html