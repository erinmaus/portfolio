TitleTheme = {}

TitleTheme.Music =
{
	'e', 'e', 'e', 'e', 'b', 'b', 'e', 'e', 'b', 'e', 'b', 'b', 'e', 'e', 'e',
	'b', 'b', 'g', 'g', 'b', 'b', 'g', 'b', 'g', 'g', 'b', 'g', 'g', 'b', 'b',
	'b', 'b', 'g', 'g', 'b', 'b', 'g', 'g', 'a', 'a', 'e', 'e', 'b', 'b', 'b',
	'e', 'b', 'e', 'b', 'g', 'c', 'c', 'b', 'c', 'b', 'c', 'c', 'c', 'b', 'b',
	'c', 'c', 'b', 'b', 'g', 'g', 'e', 'e', 'e', 'g', 'b', 'e', 'e', 'e', 'b',
	'b', 'b', 'g', 'g', 'b', 'g', 'b', 'b', 'g', 'g', 'b', 'g', 'g', 'b', 'b',
	'c', 'c', 'b', 'b', 'c', 'c', 'b', 'b'
}

TitleTheme.Frequency = MusicBuilder.StandardFrequency
TitleTheme.Time = 24
TitleTheme.Length = TitleTheme.Time * TitleTheme.Frequency
TitleTheme.Start = 128
TitleTheme.Ending = 127
TitleTheme.Frequencies = MusicBuilder.Frequencies[4]
TitleTheme.Type = SampleWave.Square
