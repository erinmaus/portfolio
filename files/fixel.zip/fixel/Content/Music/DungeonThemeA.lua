DungeonTheme = {}

DungeonTheme.Music =
{
	'A', 'A', 'a', 'a', 'A', 'A', 'b', 'b', 'A', 'A', 'a', 'a',
	'A', 'A', 'a', 'a', 'A', 'A', 'a', 'a', 'A', 'A', 'G', 'G',
	'A', 'A', 'a', 'a', 'A', 'A', 'b', 'b', 0.0, 'b', 0.0
}

DungeonTheme.Frequency = MusicBuilder.StandardFrequency
DungeonTheme.Time = 12
DungeonTheme.Length = DungeonTheme.Time * DungeonTheme.Frequency
DungeonTheme.Start = 128
DungeonTheme.Ending = 127
DungeonTheme.Frequencies = MusicBuilder.Frequencies[4]
DungeonTheme.Type = SampleWave.Square
