BossTheme = {}

BossTheme.Music =
{
	'f', 'f', 'a', 'b', 'b', 0.0, 0.0, 'f', 'f', 'a', 'b', 'b',
	0.0, 0.0, 'c', 0.0, 'f', 0.0, 'f', 'e', 'e', 0.0, 'c', 'c',
	'd', 'G', 0.0, 0.0, 'A', 'A', 'a', 'a', 'A', 'A', 'b', 'b',
	'f', 'g', 'f', 'g', 'f', 'g', 'D', 0.0, 'D', 0.0, 'D', 'd',
	'D', 'D', 0.0, 0.0 
}

BossTheme.Frequency = MusicBuilder.StandardFrequency
BossTheme.Time = 13
BossTheme.Length = BossTheme.Time * BossTheme.Frequency
BossTheme.Start = 128
BossTheme.Ending = 127
BossTheme.Frequencies = MusicBuilder.Frequencies[4]
BossTheme.Type = SampleWave.Square
