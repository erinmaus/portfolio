PixvilleSong = {}

PixvilleSong.Music =
{
	'b', 'b', 'a', 'a', 'b', 'b', 'a', 'a', 'b', 'G', 'a',
	'G', 'b', 'G', 'a', 'G', 'a', 0.0, 'b', 'b', 'a', 'G',
	'G', 'G', 'b', 'b', 'a', 'G', 'G', 'G', 'f', 'D', 'c',
	'G', 'G', 'G', 'b', 'b', 'a', 'G', 'G', 'G', 0.0, 'b',
	0.0
}

PixvilleSong.Frequency = MusicBuilder.StandardFrequency
PixvilleSong.Time = 13
PixvilleSong.Length = PixvilleSong.Time * PixvilleSong.Frequency
PixvilleSong.Start = 128
PixvilleSong.Ending = 127
PixvilleSong.Frequencies = MusicBuilder.Frequencies[4]
PixvilleSong.Type = SampleWave.Square
