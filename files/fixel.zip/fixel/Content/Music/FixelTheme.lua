FixelTheme = {}

FixelTheme.Music =
{
	'b', 'a', 0.0, 'b', 'b', 'A', 0.0, 'A', 'A', 'b', 0.0, 'b',
	'b', 0.0, 'b', 'A', 'A', 0.0, 'A', 'b', 'b', 0.0, 'a', 'b',
	'a', 'b', 0.0, 'A', 'A', 'b', 0.0, 'b', 'b', 'A', 0.0, 'A'
}

FixelTheme.Frequency = MusicBuilder.StandardFrequency
FixelTheme.Time = 12
FixelTheme.Length = FixelTheme.Time * FixelTheme.Frequency
FixelTheme.Start = 128
FixelTheme.Ending = 127
FixelTheme.Frequencies = MusicBuilder.Frequencies[4]
FixelTheme.Type = SampleWave.Square
