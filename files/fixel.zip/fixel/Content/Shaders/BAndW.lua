function Shade(tile)
	red = Graphics.GetRed(tile.Inner)
	green = Graphics.GetGreen(tile.Inner)
	blue = Graphics.GetBlue(tile.Inner)
	
	gray = (red + green + blue) / 3
	
	tile.Inner = Graphics.MakeColor(gray, gray, gray)
	
	red = Graphics.GetRed(tile.Border)
	green = Graphics.GetGreen(tile.Border)
	blue = Graphics.GetBlue(tile.Border)
	
	gray = (red + green + blue) / 3
	
	tile.Border = Graphics.MakeColor(gray, gray, gray)
end
