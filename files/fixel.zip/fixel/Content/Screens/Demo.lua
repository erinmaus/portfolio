Demo = {}

function Demo:Initialize()
	self.State = State.Create()
	self.State.IsPlayerDead = false
	self.State.CurrentFloor = 1
	self.State.DemoWon = false
	
	self.State.HasSerializedPlayer = false
	self.State.Player = {}
	
	self.Stage = Stage.Create(self.State, Game.AbsolutePath .. "Content/Stages/Demo/Demo.lua")
	
	self.CurrentFloor = self.State.CurrentFloor
	self.MaxFloors = 5
end

function Demo:Update(covered, inFocus)
	if not Game.IsPaused and not covered and inFocus then
		self.Stage:Update(Game.ElapsedTime)
		
		if self.State.IsPlayerDead then
			Game.Screeny:Add("Title")
			self.Remove()
		elseif self.State.CurrentFloor ~= self.CurrentFloor then
			if self.State.CurrentFloor > self.MaxFloors then
				self.State.DemoWon = true
			else
				local p = self.Stage.Objector:Get("D132")
				p:Serialize(self.State.Player)
				
				self.State.HasSerializedPlayer = true
				
				self.Stage = Stage.Create(self.State, Game.AbsolutePath .. "Content/Stages/Demo/Demo.lua")
			end
			
			self.CurrentFloor = self.State.CurrentFloor
		end
	end
end

function Demo:Draw(buffer)
	self.Stage:Draw(buffer, Point.Create(0, 0))
end
