-- The main menu
MainMenu = 
{
	Gravity = 0.5,
	Floor = Game.ScreenHeight - 1
}

Flame =
{
	Initialize = function(self, arg)
		self.X = math.random(0, arg.Width)
		self.Y = arg.Floor
		self.Floor = arg.Floor
		self.YSpeed = -30 + math.random() * -30
		self.XSpeed = 0
		self.Color = 100 + math.random() * 155
		
		self.YSpeedDampening = 0.2
	end,
	
	Update = function(self)
		if self.Y > self.Floor then
			self.Dead = true
		end
	end,
	
	Draw = function(self, bitmap)
		if not self.Dead then
			bitmap:DrawPrimitive(Rectangle.Create(self.X, self.Y, 4, 4), PrimitiveMode.Filled, Graphics.MakeColor(self.Color, 0, 0))
		end
	end
}

function MainMenu:Initialize()
	self.Flames = {}
	
	self.FlameConstants =
	{
		Width = Game.ScreenWidth,
		Floor = Game.ScreenHeight
	}
	
	self.FlamePack = Particle.Utilities.CreatePack(300, 5, 0.7, Flame)
	
	local dbm = DialogBuilder.Create() -- The main dialog's dialog builder
	
	-- The window
	local window = Dialog.Create(DialogType.Box)
	window.X = 0
	window.Y = 0
	window.Width = 320
	window.Height = 240
	
	-- The title label
	local titleLabel = Dialog.Create(DialogType.CenterLabel)
	local titleString = "Main Menu"
	titleLabel.X = 160
	titleLabel.Y = 2
	titleLabel.Text = titleString
	
	-- The "load" button
	local loadButton = Dialog.Create(DialogType.Button)
	loadButton.X = 80
	loadButton.Y = 60
	loadButton.Width = 160
	loadButton.Height = 40
	--loadButton.Text = "&Load"
	loadButton.Text = "&Demo"
	--loadButton.Key = Key.L
	loadButton.Key = Key.D
	loadButton.OnClick = function(dialog)
		Game.Screeny:Add("Demo")
		
		self.Remove()
		
		return DialogReturn.Ok
	end
	
	-- The "new" button
	local newButton = Dialog.Create(DialogType.Button)
	newButton.X = 80
	newButton.Y = 120
	newButton.Width = 160
	newButton.Height = 40
	newButton.Text = "&New"
	newButton.Key = Key.N
	newButton.OnClick = function(dialog)
		self.MainDialog:Alert("This isn't done, either. :(", "&Ok", Key.O)
		
		return DialogReturn.Ok
	end
	
	-- The "options" button
	local optButton = Dialog.Create(DialogType.Button)
	optButton.X = 80
	optButton.Y = 180
	optButton.Width = 160
	optButton.Height = 40
	optButton.Text = "&Options"
	optButton.Key = Key.O
	optButton.OnClick = function(dialog)
		Game.Screeny:Add("Options")
		
		self.Remove()
		
		return DialogReturn.Ok
	end
	
	-- The "back" button
	local backButton = Dialog.Create(DialogType.Button)
	backButton.X = 0
	backButton.Y = 0
	backButton.Width = 32
	backButton.Height = 32
	backButton.Text = "<"
	backButton.Key = Key.B
	backButton.OnClick = function(dialog)
		Game.Screeny:Add("Title")
		
		self.Remove()
		
		return DialogReturn.Ok
	end
	
	dbm:Add(window)
	dbm:Add(titleLabel)
	dbm:Add(loadButton)
	dbm:Add(newButton)
	dbm:Add(optButton)
	dbm:Add(backButton)
	
	self.MainDialog = dbm:Compile()
	
	self.MainDialog:SetFont(Game.Font, false)
	self.MainDialog:Center()
	self.MainDialog:SetColors(Graphics.MakeColor(255, 0, 0), Graphics.MakeColor(0, 0, 0))
end

function MainMenu:Destroy()
	self.MainDialog = nil
end

function MainMenu:Update(covered, inFocus)
	if not Game.IsPaused and not covered and inFocus then
		Particle.Utilities.Update(self.FlamePack, self.Flames, self.FlameConstants)
		
		self.MainDialog:Update()
	end
end

function MainMenu:Draw(bitmap)
	Particle.Utilities.Draw(self.Flames, bitmap)
	
	self.MainDialog.Buffer = bitmap
	self.MainDialog:Redraw()
end
