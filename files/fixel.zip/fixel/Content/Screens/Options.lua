Options = 
{
	Controls =
	{
		"Up", "Down", "Left", "Right",
		"Change Direction",
		"Spell Cycle [Up]", "Spell Cycle [Down]", "Item Cycle [Up]", "Item Cycle [Down]",
		"Use Spell", "Use Item"
	},
	
	ControlsUgly =
	{
		"Up", "Down", "Left", "Right",
		"ChangeDirection", 
		"SpellCycleUp", "SpellCycleDown", "ItemCycleUp", "ItemCycleDown",
		"UseSpell", "UseItem"
	},
	
	Prefix =
	{
		"Player One", "Player Two"
	},
	
	PrefixUgly =
	{
		"P1", "P2"
	}
}

Node =
{
	Initialize = function(self, arg)
		self.X = math.random(0, arg.Width)
		self.Y = -5
		self.Floor = arg.Floor
		self.YSpeed = -30 + math.random() * -50
		self.Color = 100 + math.random() * 155
		self.PList = arg.PList
		self.Max = arg.Max
		self.Arguments = arg
		
		self.YSpeedDampening = 0.2
	end,
	
	Update = function(self)
		if self.Y > self.Floor then
			self.Dead = true
			
			for i=1, math.random(30) do
				local free = Particle.Utilities.FreeSpot(self.PList)
				
				self.Arguments.X = self.X
				
				if free == nil and #self.PList < self.Max then
					table.insert(self.PList, Particle.Create(-self.Gravity, Element, nil, self.Arguments))
				else
					Particle.Create(-self.Gravity, Element, self.PList[free], self.Arguments)
				end
				
				self.Arguments.X = nil
			end
		end
	end,
	
	Draw = function(self, bitmap)
		if not self.Dead then
			bitmap:DrawPrimitive(Rectangle.Create(self.X, self.Y, 6, 6), PrimitiveMode.Lined, Graphics.MakeColor(0, self.Color, 0))
		end
	end
}

Element =
{
	Initialize = function(self, arg)
		self.X = arg.X
		self.Y = arg.Floor
		
		if math.random() < 0.5 then
			self.XSpeed = 1.75 + math.random() * 2
		else
			self.XSpeed = -1.75 + math.random() * -2
		end
		
		self.YSpeed = 10 + math.random() * 20
		self.YSpeedDampening = -0.15
		
		self.Life = 50 + math.random() * 20
	end,
	
	Update = function(self)
		self.Life = self.Life - 1
		
		if self.Life <= 0 then
			self.Dead = true
		end
	end,
	
	Draw = function(self, bitmap)
		Graphics.SetAdditiveBlender(self.Life / 255 * 500)
		
		if not self.Dead then
			bitmap:DrawPrimitive(Rectangle.Create(self.X, self.Y, 4, 4), PrimitiveMode.Filled, Graphics.MakeColor(0, 255, 0))
		end
		
		Graphics.SetAdditiveBlender(255)
		Graphics.SetSolidMode()
	end
}

function Options:Initialize()
	self.Particles = {}
	
	self.ParticleConstants =
	{
		PList = self.Particles,
		Max = 500,
		Floor = Game.ScreenHeight,
		Width = Game.ScreenWidth
	}
	
	self.NodePack = Particle.Utilities.CreatePack(500, 1, 1, Node)
	
	local db = DialogBuilder.Create()
	
	-- The window
	local window = Dialog.Create(DialogType.Box)
	window.X = 0
	window.Y = 0
	window.Width = 320
	window.Height = 240
	
	-- The label
	local titleLabel = Dialog.Create(DialogType.CenterLabel)
	local titleString = "Options"
	titleLabel.X = 160
	titleLabel.Y = 2
	titleLabel.Text = titleString
	
	-- The "p1" button
	local p1Button = Dialog.Create(DialogType.Button)
	p1Button.X = 80
	p1Button.Y = 60
	p1Button.Width = 160
	p1Button.Height = 40
	p1Button.Text = "Player &One"
	p1Button.Key = Key.O
	p1Button.OnClick = function(dialog)
		self.Player = 1
		
		return DialogReturn.Ok
	end
	
	-- The "p2" button
	local p2Button = Dialog.Create(DialogType.Button)
	p2Button.X = 80
	p2Button.Y = 120
	p2Button.Width = 160
	p2Button.Height = 40
	p2Button.Text = "Player &Two"
	p2Button.Key = Key.T
	p2Button.OnClick = function(dialog)
		self.Player = 2
		
		return DialogReturn.Ok
	end
	
	-- The "view-controls" button
	local viewButtonA = Dialog.Create(DialogType.Button)
	viewButtonA.X = 80
	viewButtonA.Y = 180
	viewButtonA.Width = 80
	viewButtonA.Height = 40
	viewButtonA.Text = "O&ne"
	viewButtonA.Key = Key.N
	viewButtonA.OnClick = function(dialog)
		self.VAOpen = true
		self.VAInit = true
		
		return DialogReturn.Ok
	end
	
	-- The view buttons control #2
	local viewButtonB = Dialog.Create(DialogType.Button)
	viewButtonB.X = 160
	viewButtonB.Y = 180
	viewButtonB.Width = 80
	viewButtonB.Height = 40
	viewButtonB.Text = "T&wo"
	viewButtonB.Key = Key.W
	viewButtonB.OnClick = function(dialog)
		self.VBOpen = true
		self.VBInit = true
		
		return DialogReturn.Ok
	end
	
	-- The "back" button
	local backButton = Dialog.Create(DialogType.Button)
	backButton.X = 0
	backButton.Y = 0
	backButton.Width = 32
	backButton.Height = 32
	backButton.Text = "<"
	backButton.Key = Key.B
	backButton.OnClick = function(dialog)
		Game.Screeny:Add("MainMenu")
		
		self.Remove()
		
		return DialogReturn.Ok
	end
	
	-- The "more" button
	local moreButton = Dialog.Create(DialogType.Button)
	moreButton.X = 289
	moreButton.Y = 0
	moreButton.Width = 32
	moreButton.Height = 32
	moreButton.Text = ">"
	moreButton.Key = Key.M
	moreButton.OnClick = function(dialog)
		self.MoreOptionsOpen = true
		
		return DialogReturn.Ok
	end
	
	-- Edit label
	local editLabel = Dialog.Create(DialogType.LeftLabel)
	editLabel.X = 8
	editLabel.Y = 60
	editLabel.Text = "Edit"
	
	-- View label
	local viewLabel = Dialog.Create(DialogType.LeftLabel)
	viewLabel.X = 8
	viewLabel.Y = 180
	viewLabel.Text = "View"
	
	db:Add(window)
	db:Add(titleLabel)
	db:Add(p1Button)
	db:Add(p2Button)
	db:Add(viewButtonA)
	db:Add(viewButtonB)
	db:Add(backButton)
	db:Add(viewLabel)
	db:Add(editLabel)
	db:Add(moreButton)
	
	self.Dialog = db:Compile()
	
	self.Dialog:SetFont(Game.Font, false)
	self.Dialog:Center()
	self.Dialog:SetColors(Graphics.MakeColor(0, 255, 0), Graphics.MakeColor(0, 0, 0))
	
	self.Player = 0
	self.Mode = 1
	
	self.Opened = true
	self.Joystick = false
	
	local dbva = DialogBuilder.Create()
	local dbvb = DialogBuilder.Create()
	
	-- The window thing
	local vWindow = Dialog.Create(DialogType.Box)
	vWindow.X = 0
	vWindow.Y = 0
	vWindow.Width = 320
	vWindow.Height = 320
	
	-- The text label for the view window
	local vTitle = Dialog.Create(DialogType.CenterLabel)
	vTitle.X = 160
	vTitle.Y = 2
	vTitle.Text = "View Controls"
	
	-- The "X" button
	local closeButton = Dialog.Create(DialogType.Button)
	closeButton.X = 0
	closeButton.Y = 0
	closeButton.Width = 32
	closeButton.Height = 32
	closeButton.Text = "X"
	closeButton.Key = Key.X
	closeButton.OnClick = function(dialog)
		self.VAOpen = false
		
		return DialogReturn.Close
	end
	
	dbva:Add(vWindow)
	dbva:Add(vTitle)
	dbva:Add(closeButton)
	
	-- The text labels
	for i=1, #self.Controls do
		local label = Dialog.Create(DialogType.LeftLabel)
		label.X = 2
		label.Y = 32 +  (i * (Game.Font.Height + 2))
		label.Text = self.PrefixUgly[1] .. " " .. self.Controls[i]
		
		dbva:Add(label)
	end
	
	for i=1, #self.Controls do
		local cont = Dialog.Create(DialogType.RightLabel)
		cont.X = 318
		cont.Y = 32 + (i * (Game.Font.Height + 2))
		cont.Text = ""
		
		dbva:Add(cont)
	end
	
	closeButton.OnClick = function(dialog)
		self.VBOpen = false
		
		return DialogReturn.Close
	end
	
	dbvb:Add(vWindow)
	dbvb:Add(vTitle)
	dbvb:Add(closeButton)
	
	-- Text labels redux
	for i=1, #self.Controls do
		local label = Dialog.Create(DialogType.LeftLabel)
		label.X = 2
		label.Y = 32 + (i * (Game.Font.Height + 2))
		label.Text = self.PrefixUgly[2] .. " " .. self.Controls[i]
		
		dbvb:Add(label)
	end
	
	for i=1, #self.Controls do
		local cont = Dialog.Create(DialogType.RightLabel)
		cont.X = 318
		cont.Y = 32 + (i * (Game.Font.Height + 2))
		cont.Text = ""
		
		dbvb:Add(cont)
	end
	
	self.VADialog = dbva:Compile()
	self.VBDialog = dbvb:Compile()
	
	self.VADialog:SetFont(Game.Font, false)
	self.VADialog:Center()
	self.VADialog:SetColors(Graphics.MakeColor(0, 255, 0), Graphics.MakeColor(0, 0, 0))
	
	self.VBDialog:SetFont(Game.Font, false)
	self.VBDialog:Center()
	self.VBDialog:SetColors(Graphics.MakeColor(0, 255, 0), Graphics.MakeColor(0, 0, 0))
	
	-- Additive/translucent blenders...
	local dbm = DialogBuilder.Create()
	
	local okButton = Dialog.Create(DialogType.Button)
	okButton.X = 0
	okButton.Y = 0
	okButton.Width = 32
	okButton.Height = 32
	okButton.Text = "<"
	okButton.Key = Key.B
	okButton.OnClick = function(dialog)
		return DialogReturn.Close
	end
	
	local additiveButton = Dialog.Create(DialogType.Button)
	additiveButton.X = 50
	additiveButton.Y = 60
	additiveButton.Width = 210
	additiveButton.Height = 40
	additiveButton.Text = "&Add. Blending: " .. tostring(Game.Options.EnableAdditiveBlending)
	additiveButton.Key = Key.A
	additiveButton.OnClick = function(dialog)
		if Game.Options.EnableAdditiveBlending then
			Game.Options.EnableAdditiveBlending = false
		else
			Game.Options.EnableAdditiveBlending = true
		end
		
		dialog.Text = "&Add. Blending: " .. tostring(Game.Options.EnableAdditiveBlending)
		
		return DialogReturn.Ok
	end
	
	local transButton = Dialog.Create(DialogType.Button)
	transButton.X = 50
	transButton.Y = 120
	transButton.Width = 210
	transButton.Height = 40
	transButton.Text = "&Trns. Blending: " .. tostring(Game.Options.EnableTranslucentBlending)
	transButton.Key = Key.T
	transButton.OnClick = function(dialog)
		if Game.Options.EnableTranslucentBlending then
			Game.Options.EnableTranslucentBlending = false
		else
			Game.Options.EnableTranslucentBlending = true
		end
		
		dialog.Text = "&Trns. Blending: " .. tostring(Game.Options.EnableTranslucentBlending)
		
		return DialogReturn.Ok
	end
	
	dbm:Add(window)
	dbm:Add(titleLabel)
	dbm:Add(okButton)
	dbm:Add(additiveButton)
	dbm:Add(transButton)
	
	self.MoreOptions = dbm:Compile()
	
	self.MoreOptions:SetFont(Game.Font, false)
	self.MoreOptions:Center()
	self.MoreOptions:SetColors(Graphics.MakeColor(0, 255, 0), Graphics.MakeColor(0, 0, 0))
	
	self.MoreOptionsOpen = false
end

function Options:Destroy()
	self.Dialog = nil
	self.VADialog = nil
	self.VBDialog = nil
end

function Options:Update(covered, inFocus)
	if not Game.IsPaused and not covered and inFocus then
		Particle.Utilities.Update(self.NodePack, self.Particles, self.ParticleConstants, 0.1)
		
		if self.Opened and not self.Joystick and self.Player < 1 and not self.VAOpen and not self.VBOpen 
			and not self.MoreOptionsOpen then
			self.Dialog:Update()
			
			if self.Player > 0 then
				self.Mode = 1
			end
		elseif self.MoreOptionsOpen and not self.MoreOptions:Update() then
			self.MoreOptionsOpen = false
		elseif self.VAOpen then
			if self.VAInit then
				for i=1, #self.Controls do
					local d = self.VADialog[(3 + #self.Controls) + (i - 1)]
					local id = self.PrefixUgly[1] .. self.ControlsUgly[i]
					local cont = Game.Controls[id]
					
					if cont.Type == ControlType.Keyboard then
						for key, value in pairs(Key) do
							if value == cont.Button then
								d.Text = tostring(key)
							end
						end
					else
						if cont.Button < 0 then
							for key, value in pairs(Direction) do
								if value == -cont.Button - 1 then
									d.Text = "[Joy] " .. tostring(key)
								end
							end
						else
							d.Text = "[Joy] B" .. tostring(cont.Button)
						end
					end
				end
				self.VAInit = false
			end
			
			if not self.VADialog:Update() then
				self.VAOpen = false
			end
		elseif self.VBOpen then
			if self.VBInit then
				for i=1, #self.Controls do
					local d = self.VBDialog[(3 + #self.Controls) + (i - 1)]
					local id = self.PrefixUgly[2] .. self.ControlsUgly[i]
					local cont = Game.Controls[id]
					
					if cont.Type == ControlType.Keyboard then
						for key, value in pairs(Key) do
							if value == cont.Button then
								d.Text = tostring(key)
							end
						end
					else
						if cont.Button < 0 then
							for key, value in pairs(Direction) do
								if value == -(cont.Button + 1) then
									d.Text = "[Joy] " .. tostring(key)
								end
							end
						else
							d.Text = "[Joy] B" .. tostring(cont.Button)
						end
					end
				end
				self.VBInit = false
			end
			
			if not self.VBDialog:Update() then
				self.VBOpen = false
			end
		elseif self.Player > 0 and self.Mode > #self.Controls then
			self.Mode = 1
			self.Player = 0
			
			Game.Controls:SaveToFile(Game.AbsolutePath .. "Data/Game/Controls.xml")
		end
	end
end

function Options:Draw(bitmap)
	Particle.Utilities.Draw(self.Particles, bitmap)
	
	if self.Opened and not self.VAOpen and not self.VBOpen and self.Player < 1 and not self.MoreOptionsOpen then
		self.Dialog.Buffer = bitmap
		self.Dialog:Redraw()
	elseif self.MoreOptionsOpen then
		self.MoreOptions.Buffer = bitmap
		self.MoreOptions:Redraw()
	elseif self.VAOpen then
		self.VADialog.Buffer = bitmap
		self.VADialog:Redraw()
	elseif self.VBOpen then
		self.VBDialog.Buffer = bitmap
		self.VBDialog:Redraw()
	elseif self.Player > 0 then
		Game.Font:Draw(bitmap, FontDrawType.Centered, bitmap.Width / 2, bitmap.Height / 2 - Game.Font.Height / 2,
			Graphics.MakeColor(0, 255, 0), self.Prefix[self.Player] .. " " .. self.Controls[self.Mode])
		Game.Font:Draw(bitmap, FontDrawType.Centered, bitmap.Width / 2, bitmap.Height / 2 + Game.Font.Height * 2,
			Graphics.MakeColor(0, 255, 0), "Press the key or move the joystick")
	end
end

function Options:HandleInput(input)
	if self.Joystick and self.Player < 1 and (input:JoystickButton(0, 0) == ButtonState.Released and input:JoystickButton(0, 1) == ButtonState.Released) then
		self.Joystick = false
	end
	
	if self.Player > 0 and not Game.IsPaused then
		local key = input.LastKeyPressed
		
		if key > -1 then
			Game.Controls[self.PrefixUgly[self.Player] .. self.ControlsUgly[self.Mode]] = Control.Create(ControlType.Keyboard, key)
			self.Mode = self.Mode + 1
		elseif input.JoystickTotal > 0 then
			local da, db, sa, sb = input:JoystickDirection()
			
			if sa == ButtonState.JustPressed or sb == ButtonState.JustPressed then
				Game.Controls[self.PrefixUgly[self.Player] .. self.ControlsUgly[self.Mode]] = Control.Create(ControlType.Joystick, -(da or db) - 1)
				
				self.Mode = self.Mode + 1
			else
				local button = input:JoystickButton(0)
				
				if button > -1 then
					Game.Controls[self.PrefixUgly[self.Player] .. self.ControlsUgly[self.Mode]] = Control.Create(ControlType.Joystick, button)
					
					self.Joystick = true
					
					self.Mode = self.Mode + 1
				end
			end
		end
	end
end
