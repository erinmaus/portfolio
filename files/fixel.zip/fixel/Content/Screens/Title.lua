-- The title screen for Fixel.
Title = {}

Star =
{
	Initialize = function(self, arg)
		self.X = math.random(0, arg.Width)
		self.Y = -5 + math.random() * -100
		self.YSpeed = 2
		self.Bounce = 0.25 + math.random() * 0.1
		self.OnFloor = false
		self.Floor = arg.Floor
		
		self.YSpeedDampening = 0.15
		
		if math.random() < .5 then -- Move to the right
			self.XSpeed = 1.75 + math.random() * 2
		else
			self.XSpeed = -1.75 + math.random() * -2
		end
	end,
	
	Update = function(self)
		if self.Y > self.Floor then
			self.Y = self.Floor
			
			self.YSpeed = self.YSpeed * -self.Bounce
			
			if self.YSpeed < 0.01 and self.OnFloor then
				self.Dead = true
			end
			
			self.OnFloor = true
		else
			self.OnFloor = false
		end
	end,
	
	Draw = function(self, bitmap)
		bitmap:DrawPrimitive(Point.Create(self.X, self.Y), Graphics.MakeColor(255, 255, 255))
	end
}

function Title:Initialize()
	self.Stars = {}
	
	self.StarConstants =
	{
		Width = Game.ScreenWidth,
		Floor = Game.ScreenHeight
	}
	
	self.StarPack = Particle.Utilities.CreatePack(350, 1, 0.5, Star)
	
	local db = DialogBuilder.Create()
	
	-- The window
	local window = Dialog.Create(DialogType.Box)
	window.X = 0
	window.Y = 0
	window.Width = 320
	window.Height = 240
	
	-- The label
	local titleLabel = Dialog.Create(DialogType.CenterLabel)
	local titleString = "Start Menu"
	titleLabel.X = 160
	titleLabel.Y = 2
	titleLabel.Text = titleString
	
	-- The "play" button
	local playButton = Dialog.Create(DialogType.Button)
	playButton.X = 80
	playButton.Y = 60
	playButton.Width = 160
	playButton.Height = 40
	playButton.Text = "&Play Fixel"
	playButton.Key = Key.P
	playButton.OnClick = function(dialog)
		Game.Screeny:Add("MainMenu")
		
		self.Remove()
				
		return DialogReturn.Ok
	end
	
	-- The "edit" button
	local editButton = Dialog.Create(DialogType.Button)
	editButton.X = 80
	editButton.Y = 120
	editButton.Width = 160
	editButton.Height = 40
	editButton.Text = "&Edit Fixel"
	editButton.Key = Key.E
	editButton.OnClick = function(dialog)
		Game.Screeny:Add("EditMenu")
		
		self.Remove()
		
		return DialogReturn.Ok
	end
	
	-- The "quit" button
	local quitButton = Dialog.Create(DialogType.Button)
	quitButton.X = 80
	quitButton.Y = 180
	quitButton.Width = 160
	quitButton.Height = 40
	quitButton.Text = "&Quit Fixel"
	quitButton.Key = Key.Q
	quitButton.OnClick = function(dialog)
		Game:Quit()
		
		return DialogReturn.Ok
	end
	
	db:Add(window)
	db:Add(titleLabel)
	db:Add(playButton)
	db:Add(editButton)
	db:Add(quitButton)
	
	self.Dialog = db:Compile()
	
	self.Dialog:SetFont(Game.Font, false)
	self.Dialog:Center()
	self.Dialog:SetColors(Graphics.MakeColor(255, 255, 255), Graphics.MakeColor(0, 0, 0))
	
	self.DialogOpen = false
	
	self.LargeFont = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	self.XLargeFont = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-xlarge.pcx")
	
	self.TitleText = "Fixel"
	self.TitleBuffer = Bitmap.Create(self.XLargeFont:Measure(self.TitleText), self.XLargeFont.Height)
	self.TitleDown = true
	self.TitleAlpha = 250
	
	self.TitleBuffer:Clear(Graphics.MakeColor(255, 0, 255))
	self.XLargeFont:Draw(self.TitleBuffer, FontDrawType.Left, 0, 0, Graphics.MakeColor(255, 255, 255), self.TitleText)
	
	self.TitleTimer = Timer.Create(0.5, function()
		if self.TitleDown then
			self.TitleAlpha = self.TitleAlpha - 10
			
			if self.TitleAlpha < 150 then
				self.TitleDown = false
			end
		else
			self.TitleAlpha = self.TitleAlpha + 10
			
			if self.TitleAlpha > 245 then
				self.TitleDown = true
			end
		end
	end)
	
	dofile(Game.AbsolutePath .. "Content/Music/FixelTheme.lua")
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Click.lua")
	
	if not Concerto:Exists("MenuMusic") then
		Concerto:Add("MenuMusic", MusicBuilder.CreateFromTable(FixelTheme))
	end
	
	if not Concerto:IsPlaying("MenuMusic") then
		Concerto:StopAll()
		Concerto:Play("MenuMusic", 100, 128, 1000, true)
	end
	
	self.Click = MusicBuilder.CreateFromTable(ClickFx)
end

function Title:Destroy()
	self.Dialog = nil
end

function Title:Update(covered, inFocus)
	if not Game.IsPaused and not covered and inFocus then
		Particle.Utilities.Update(self.StarPack, self.Stars, self.StarConstants)
		
		if self.DialogOpen and not self.Dialog:Update() then
			self.DialogOpen = false
		else
			self.TitleTimer:Update()
		end
	end
end

function Title:Draw(bitmap)
	Particle.Utilities.Draw(self.Stars, bitmap)
	
	self.Dialog.Buffer = bitmap
	
	if self.DialogOpen then
		self.Dialog:Redraw()
	else
		self.LargeFont:Draw(bitmap, FontDrawType.Centered, Point.Create(Game.ScreenWidth / 2,
			Game.ScreenHeight - self.LargeFont.Height), Graphics.MakeColor(200, 200, 200), "Press `S' to start!")
		
		Graphics.SetTranslucentBlender(self.TitleAlpha)
		
		self.TitleBuffer:DrawTrans(bitmap, bitmap.Width / 2 - self.TitleBuffer.Width /2, bitmap.Height / 2 - self.TitleBuffer.Height / 2)
		
		Graphics.SetSolidMode()
		Graphics.SetTranslucentBlender(255)
	end
end

function Title:HandleInput(input)
	if not Game.IsPaused then
		if input:KeyState(Key.S) == ButtonState.JustReleased or (input.JoystickTotal > 0 and input:JoystickButton(0, 0) == ButtonState.JustReleased) then
			if not self.DialogOpen then
				self.Click:Play(255, 128, 1000, false)
			end
			
			input:ClearKeyBuffer()
			self.DialogOpen = true
		end
	end
end
