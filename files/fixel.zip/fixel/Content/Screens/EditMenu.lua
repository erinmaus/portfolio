EditMenu = {}

function EditMenu:Initialize()
	local db = DialogBuilder.Create()
	
	-- The window
	local window = Dialog.Create(DialogType.Box)
	window.X = 0
	window.Y = 0
	window.Width = 320
	window.Height = 240
	
	-- Title label
	local titleLabel = Dialog.Create(DialogType.CenterLabel)
	titleLabel.X = 160
	titleLabel.Y = 2
	titleLabel.Text = "Edit Menu"
	
	-- Create/edit map button
	local mapButton = Dialog.Create(DialogType.Button)
	mapButton.X = 80
	mapButton.Y = 60
	mapButton.Width = 160
	mapButton.Height = 40
	mapButton.Text = "&Map Editor"
	mapButton.OnClick = function(dialog)
		return DialogReturn.Ok
	end
	
	-- Create/edit tilesheet
	local tseButton = Dialog.Create(DialogType.Button)
	tseButton.X = 80
	tseButton.Y = 120
	tseButton.Width = 160
	tseButton.Height = 40
	tseButton.Text = "&TS Editor"
	tseButton.OnClick = function(dialog)
		return DialogReturn.Ok
	end
	
	-- Back button
	local backButton = Dialog.Create(DialogType.Button)
	backButton.X = 0
	backButton.Y = 0
	backButton.Width = 32
	backButton.Height = 32
	backButton.Text = "<"
	backButton.Key = Key.B
	backButton.OnClick = function(dialog)
		Game.Screeny:Add("Title")
		
		self.Remove()
		
		return DialogReturn.Ok
	end
	
	db:Add(window)
	db:Add(titleLabel)
	db:Add(mapButton)
	db:Add(tseButton)
	db:Add(backButton)
	
	self.Dialog = db:Compile()
	
	self.Dialog:SetFont(Game.Font, false)
	self.Dialog:Center()
	self.Dialog:SetColors(Graphics.MakeColor(0, 0, 255), Graphics.MakeColor(0, 0, 0))
end

function EditMenu:Destroy()
	self.Dialog = nil
end

function EditMenu:Update(covered, inFocus)
	if not Game.IsPaused and not covered and inFocus then
		self.Dialog:Update()
	end
end

function EditMenu:Draw(buffer)
	self.Dialog.Buffer = buffer
	self.Dialog:Redraw()
end
