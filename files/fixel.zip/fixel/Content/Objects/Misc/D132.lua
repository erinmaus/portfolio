D132 = {}

function D132:Initialize(obj)
	self.Location = Point.Create(0, 0)
	
	self.Object = obj
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Last
	
	self.IsSolid = true
	self.CanMove = true
	
	self.Name = "Ditto"
	
	self.IsDead = false
	self.DeathAlpha = 0
	self.DeathMessage = "You just voided your warranty"
	self.DeathBuffer = Bitmap.Create(self.Font:Measure(self.DeathMessage), self.Font.Height)
	
	self.DeathTimer = Timer.Create(0.15, function()
		self.DeathAlpha = self.DeathAlpha + 7.0
		
		if self.DeathAlpha > 255 then
			self.Object.Stage.State.IsPlayerDead = true
		end
	end)
		
	self.Movements =
	{
		P1Up = Point.Create(0, -1),
		P1Down = Point.Create(0, 1),
		P1Left = Point.Create(-1, 0),
		P1Right = Point.Create(1, 0)
	}
	
	self.Directions =
	{
		P1Up = Direction.Up,
		P1Down = Direction.Down,
		P1Left = Direction.Left,
		P1Right = Direction.Right
	}
	
	self.Direction = "P1Up"
	
	self.Skills =
	{
		HP = Skill.Create(),
		Attack = Skill.Create(),
		Defence = Skill.Create(),
		Magic = Skill.Create()
	}
	
	self.Skills.HP.Color = Graphics.MakeColor(255, 0, 0)
	self.Skills.HP.Xp = self.Skills.HP:XpForLevel(20)
	
	self.Skills.Attack.Color = Graphics.MakeColor(120, 120, 120)
	self.Skills.Attack.Xp = self.Skills.Attack:XpForLevel(5)
	
	self.Skills.Defence.Color = Graphics.MakeColor(0, 0, 255)
	self.Skills.Defence.Xp = self.Skills.Defence:XpForLevel(10)
	
	self.Skills.Magic.Color = Graphics.MakeColor(255, 100, 255)
	self.Skills.Magic.Xp = self.Skills.Magic:XpForLevel(5)
	
	self.Inventory = Inventory.Create()
	self.Inventory:Push(self.Object.Objector:Add("PunyDagger")):OnTake({ Owner = self })
	self.Inventory:Push(self.Object.Objector:Add("HollowedSword")):OnTake({ Owner = self })
	self.Inventory:Push(self.Object.Objector:Add("CryingMace")):OnTake({ Owner = self })
	self.Inventory:Push(self.Object.Objector:Add("SuperPotion")):OnTake({ Owner = self })
	self.Inventory:Push(self.Object.Objector:Add("SuperPotion")):OnTake({ Owner = self })
	
	self.Spells = Inventory.Create()
	self.Spells:Push(self.Object.Objector:Add("AstralMaelstrom")):OnSetOwner({ Owner = self })
	self.Spells:Push(self.Object.Objector:Add("DazyBlazy")):OnSetOwner({ Owner = self })
	
	self.InvAndSpellsBuffer = Bitmap.Create((Game.ScreenWidth / 6) + 70, Game.Font.Height)
	
	self.Armor = Armor.Create()
	self.Armor.Crush = 1.05
	self.Armor.Slash = 1.05
	
	self.InputTimer = Timer.Create(0.15, function()
		for key, value in pairs(self.Movements) do
			if GameObject.Input.MoveIt(key, self.Object.Stage.Map, self.Object.Objector, self.Location, self.Movements) == ButtonState.Pressed then
				self.Location = self.Location + value
				self.Direction = key
			end
		end
	end)
	
	self.CanUseITem = true
	self.ItemTimer = Timer.Create(0.25, function()
		self.CanUseItem = true
	end)
	
	self.CanCast = true
	self.SpellTimer = Timer.Create(4.0, function()
		self.CanCast = true
	end)
	
	self.Effects = {}
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Click.lua")
	self.Effects.PickUp = MusicBuilder.CreateFromTable(ClickFx)
end

function D132:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.HasSpawned = true
	
	if arg.SerializedData then
		for _, va in pairs(self.Inventory.Items) do
			for _, vb in pairs(va) do
				vb.Object:Remove()
			end
		end
		
		self.Inventory.Items = {}
		
		for _, va in pairs(self.Spells.Items) do
			for _, vb in pairs(va) do
				vb.Object:Remove()
			end
		end
		
		self.Spells.Items = {}
		
		local inva = State.ToTable(arg.SerializedData.Inventory)
		for _, va in pairs(inva) do
			local invb = State.ToTable(va)
			
			for _, vb in pairs(invb) do
				self.Inventory:Push(self.Object.Objector:Add(vb)):OnTake({ Owner = self })
			end
		end
		
		local spells = State.ToTable(arg.SerializedData.Spells)
		for _, value in pairs(spells) do
			self.Spells:Push(self.Object.Objector:Add(value))
			self.Spells:BackItem():OnSetOwner({ Owner = self })
		end
		
		local skills = State.ToTable(arg.SerializedData.Skills)
		for key, value in pairs(skills) do
			self.Skills[key].Xp = value
		end
	end
end

function D132:OnSetTarget(arg)
	self.Target = arg.Target
end

function D132:OnHit(arg)
	self.Skills.HP.AdditionalXp = self.Skills.HP.AdditionalXp - self.Armor:CalculateDamage(arg.Attack, arg.Level, self.Skills.Defence:CurrentLevel())
	
	if self.Skills.HP:CurrentLevel() < 1 then
		self.IsDead = true
		
		Messenger:Add("Dang it!")
	end
end

function D132:OnUsedUpItem()
	self.Inventory:Pop().Object:Remove()
end

function D132:Update()
	local upd = true
	
	if not self.IsDead then
		if Game.Controls["P1ChangeDirection"]:State(Game.Input) == ButtonState.Released then
			for key, value in pairs(self.Movements) do	
				if GameObject.Input.MoveIt(key, self.Object.Stage.Map, self.Object.Objector, self.Location, self.Movements) == ButtonState.JustPressed then
					self.Location = self.Location + value
					self.Direction = key
					upd = false
				elseif Game.Controls[key]:State(Game.Input) == ButtonState.JustPressed then
					self.Direction = key
				end
			end
			
			if upd then
				self.InputTimer:Update()
			else
				self.InputTimer:Restart()
			end
		elseif Game.Controls["P1ChangeDirection"]:State(Game.Input) == ButtonState.Pressed then
			for key, value in pairs(self.Movements) do
				if Game.Controls[key]:State(Game.Input) == ButtonState.Pressed then
					self.Direction = key
				end
			end
		end
		
		if Game.Controls["P1ItemCycleUp"]:State(Game.Input) == ButtonState.JustPressed then
			self.Inventory:CycleUp()
		end
		
		if Game.Controls["P1ItemCycleDown"]:State(Game.Input) == ButtonState.JustPressed then
			self.Inventory:CycleDown()
		end
		
		if Game.Controls["P1UseItem"]:State(Game.Input) == ButtonState.JustPressed then
			if #self.Inventory.Items > 0 and self.CanUseItem then
				self.Inventory:CurrentItem():OnUse({ Plus = self.Movements[self.Direction] })
				self.CanUseItem = false
			end
		end
		
		if Game.Controls["P1SpellCycleUp"]:State(Game.Input) == ButtonState.JustPressed then
			self.Spells:CycleUp()
		end
		
		if Game.Controls["P1SpellCycleDown"]:State(Game.Input) == ButtonState.JustPressed then
			self.Spells:CycleDown()
		end
		
		if self.CanCast then
			self.SpellTimer:Restart()
			
			if Game.Controls["P1UseSpell"]:State(Game.Input) == ButtonState.JustPressed then
				if #self.Spells.Items > 0 then
					local txy = self.Location + self.Movements[self.Direction]
					
					self.Spells:CurrentItem():OnCast({ TileX = txy.X, TileY = txy.Y, TileWidth = self.Object.Stage.TileWidth,
						TileHeight = self.Object.Stage.TileHeight, Direction = self.Directions[self.Direction] })
						
					self.CanCast = false
				end
			end
		else
			self.SpellTimer:Update()
		end
		
		local camera = self.Object.Stage.Camera
		
		camera.X = self.Location.X - (camera.Width / 2)
		
		if camera.Width % 2 ~= 0 then
			camera.Y = self.Location.Y - ((camera.Width - 3) / 2)
		else
			camera.Y = self.Location.Y - (camera.Width / 2)
		end
		
		self.Object.Stage:SetCameraXY(camera.XY)
		
		-- Pick up items
		local objs = self.Object.Objector:GetObjectsAtXY(self.Location)
		
		for _, value in pairs(objs) do
			if value.OnTake then
				local alreadyOwn = false
				
				for _, vb in pairs(self.Inventory.Items) do
					for _, vc in pairs(vb) do
						if vc.Object.Uid == value.Object.Uid then
							alreadyOwn = true
							break
						end
					end
				end
				
				if not alreadyOwn then
					value:OnTake({ Owner = self })
					self.Inventory:Push(value)
					
					Messenger:Add(self.Name .. " picked up a " .. value.Name .. ".")
					self.Effects.PickUp:Play(255, 128, 1000, false)
				end
			end
			
			if value.OnStep then
				value:OnStep({ Stepper = self })
			end
		end
		
		if not self.CanUseItem then
			self.ItemTimer:Update()
		else
			self.ItemTimer:Restart()
		end
		
		if self.Object.Stage.State.DemoWon then
			Messenger:Add("You've won this dungeon!")
		end
	else
		self.DeathTimer:Update()
	end
end

function D132:Draw(buffer, camera)
	GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(255, 96, 255), Graphics.MakeColor(205, 46, 205), "D")
	
	Graphics.SetTranslucentBlender(100)
	
	buffer:DrawPrimitive(Rectangle.Create(
		((self.Location.X + self.Movements[self.Direction].X) - camera.X) * self.Object.Stage.TileWidth,
		((self.Location.Y + self.Movements[self.Direction].Y) - camera.Y) * self.Object.Stage.TileHeight, 
		self.Object.Stage.TileWidth - 1, self.Object.Stage.TileHeight - 1),
		PrimitiveMode.Filled, Graphics.MakeColor(255, 255, 0))
	
	Graphics.SetSolidMode()
	Graphics.SetTranslucentBlender(255)
	
	if self.Target then
		Game.Font:Draw(buffer, FontDrawType.Left,  2, Game.Font.Height * 1 + 2, Graphics.MakeColor(255, 255, 255), "Target:")
		Game.Font:Draw(buffer, FontDrawType.Left, 12, Game.Font.Height * 2 + 2, Graphics.MakeColor(255, 255, 255), self.Target.Name)
			
		if self.Target.Skills.HP.Xp + self.Target.Skills.HP.AdditionalXp > 0 then
			buffer:DrawPrimitive(Rectangle.Create(12, Game.Font.Height * 3 + 2, 100, Game.Font.Height / 2),
				PrimitiveMode.Filled, Graphics.MakeColor(0, 200, 0))
			
			buffer:DrawPrimitive(Rectangle.Create(12, Game.Font.Height * 3 + 2, math.floor(100 / self.Target.Skills.HP.Xp * -self.Target.Skills.HP.AdditionalXp), Game.Font.Height / 2), 
			PrimitiveMode.Filled, Graphics.MakeColor(200, 0, 0))
		else
			buffer:DrawPrimitive(Rectangle.Create(12, Game.Font.Height * 3 + 2, 100, Game.Font.Height / 2),
				PrimitiveMode.Filled, Graphics.MakeColor(200, 0, 0))
		end
	end
	
	Game.Font:Draw(buffer, FontDrawType.Left, 2, Game.Font.Height * 5, Graphics.MakeColor(255, 255, 255), self.Object.Stage.State.StageName)
	Game.Font:Draw(buffer, FontDrawType.Left, 2, Game.Font.Height * 6 + 2, Graphics.MakeColor(255, 255, 255), "Floor " .. self.Object.Stage.State.CurrentFloor)
	
	local y = Game.ScreenHeight / 3 + 30
	local x = Game.ScreenWidth - (Game.ScreenWidth / 6) - 70
	
	Game.Font:Draw(buffer, FontDrawType.Left, x, Game.Font.Height * 1, Graphics.MakeColor(255, 255, 255), self.Name)
	
	if self.Skills.HP.Xp + self.Skills.HP.AdditionalXp > 0 then
		buffer:DrawPrimitive(Rectangle.Create(x, Game.Font.Height * 2, 100, Game.Font.Height / 2), PrimitiveMode.Filled, Graphics.MakeColor(0, 200, 0))
		buffer:DrawPrimitive(Rectangle.Create(x, Game.Font.Height * 2, math.floor(100 / self.Skills.HP.Xp * -self.Skills.HP.AdditionalXp),
			Game.Font.Height / 2), PrimitiveMode.Filled, Graphics.MakeColor(200, 0, 0))
	else
		buffer:DrawPrimitive(Rectangle.Create(x, Game.Font.Height * 2, 100, Game.Font.Height / 2), PrimitiveMode.Filled, Graphics.MakeColor(200, 0, 0))
	end
	
	-- Draw the next, prev items
	local text
	local tcolor
	
	if #self.Inventory.Items <= 1 then
		text = "none"
	else
		text = "<" .. self.Inventory:BackItem().Name .. " x" .. tostring(#self.Inventory:Back())
	end
	
	self.InvAndSpellsBuffer:Clear(Graphics.MakeColor(255, 0, 255))
	Game.Font:Draw(self.InvAndSpellsBuffer, FontDrawType.Left, 0, 0, Graphics.MakeColor(255, 255, 255), text)

	Graphics.SetTranslucentBlender(128)
	self.InvAndSpellsBuffer:DrawTrans(buffer, x, Game.Font.Height * 3)
	Graphics.SetTranslucentBlender(255)
	Graphics.SetSolidMode()
	
	if #self.Inventory.Items == 0 then
		text = "none"
	else
		text = self.Inventory:CurrentItem().Name .. " x" .. tostring(#self.Inventory:Current())
	end
	
	if self.CanUseItem then
		tcolor = Graphics.MakeColor(0, 200, 0)
	else
		tcolor = Graphics.MakeColor(200, 0, 0)
	end
	
	Game.Font:Draw(buffer, FontDrawType.Left, x, Game.Font.Height * 4, tcolor, text)
	
	if #self.Inventory.Items <= 1 then
		text = "none"
	else
		text = ">" .. self.Inventory.Items[2][1].Name .. " x" .. tostring(#self.Inventory.Items[2])
	end
	
	self.InvAndSpellsBuffer:Clear(Graphics.MakeColor(255, 0, 255))
	Game.Font:Draw(self.InvAndSpellsBuffer, FontDrawType.Left, 0, 0, Graphics.MakeColor(255, 255, 255), text)
	
	Graphics.SetTranslucentBlender(128)
	self.InvAndSpellsBuffer:DrawTrans(buffer, x, Game.Font.Height * 5)
	Graphics.SetTranslucentBlender(255)
	Graphics.SetSolidMode()
	
	if #self.Spells.Items <= 1 then
		text = "none"
	else
		text = "<" .. self.Spells:BackItem().Name
	end
	
	self.InvAndSpellsBuffer:Clear(Graphics.MakeColor(255, 0, 255))
	Game.Font:Draw(self.InvAndSpellsBuffer, FontDrawType.Left, 0, 0, Graphics.MakeColor(255, 255, 255), text)
	
	Graphics.SetTranslucentBlender(128)
	self.InvAndSpellsBuffer:DrawTrans(buffer, x, Game.Font.Height * 7)
	Graphics.SetTranslucentBlender(255)
	Graphics.SetSolidMode()
	
	if #self.Spells.Items == 0 then
		text = "none"
	else
		text = self.Spells:CurrentItem().Name
	end
	
	if self.CanCast then
		tcolor = Graphics.MakeColor(0, 200, 0)
	else
		tcolor = Graphics.MakeColor(200, 0, 0)
	end
	
	Game.Font:Draw(buffer, FontDrawType.Left, x, Game.Font.Height * 8, tcolor, text)
	
	if #self.Spells.Items <= 1 then
		text = "none"
	else
		text = ">" .. self.Spells.Items[2][1].Name
	end
	
	self.InvAndSpellsBuffer:Clear(Graphics.MakeColor(255, 0, 255))
	Game.Font:Draw(self.InvAndSpellsBuffer, FontDrawType.Left, 0, 0, Graphics.MakeColor(255, 255, 255), text)
	
	Graphics.SetTranslucentBlender(128)
	self.InvAndSpellsBuffer:DrawTrans(buffer, x, Game.Font.Height * 9)
	Graphics.SetTranslucentBlender(255)
	Graphics.SetSolidMode()
	
	for key, value in pairs(self.Skills) do
		text = key .. ": " .. value:CurrentLevel() .. "/" .. value:Level()
		Graphics.SetTranslucentBlender(128)
		
		buffer:DrawPrimitive(Rectangle.Create(x - Game.Font.Height, y, Game.Font.Height, Game.Font.Height),
			PrimitiveMode.Filled, value.Color)
		
		Graphics.SetSolidMode()
		
		Game.Font:Draw(buffer, FontDrawType.Left, x, y, Graphics.MakeColor(255, 255, 255), text)		
		y = y + Game.Font.Height + 2
		
		Game.Font:Draw(buffer, FontDrawType.Left, x, y, Graphics.MakeColor(255, 255, 255), string.format("%d: %d", value.Xp, value.AdditionalXp))
		y = y + Game.Font.Height + 2
	end
	
	if self.IsDead then		
		self.DeathBuffer:Clear(Graphics.MakeColor(255, 0, 255))
		self.Font:Draw(self.DeathBuffer, FontDrawType.Left, 0, 0, Graphics.MakeColor(255, 255, 255), self.DeathMessage)
		
		Graphics.SetTranslucentBlender(self.DeathAlpha)
		
		buffer:DrawPrimitive(Rectangle.Create(0, 0, buffer.Width, buffer.Height), PrimitiveMode.Filled, Graphics.MakeColor(200, 0, 0))
		self.DeathBuffer:DrawTrans(buffer, buffer.Width / 2 - self.DeathBuffer.Width / 2, buffer.Height / 2 - self.DeathBuffer.Height / 2)
		
		Graphics.SetSolidMode()
		Graphics.SetTranslucentBlender(255)
	end
end

function D132:Serialize(t)
	t.Inventory = {}
	
	for ka, va in pairs(self.Inventory.Items) do
		t.Inventory[ka] = {}
		
		for kb, vb in pairs(va) do
			t.Inventory[ka][kb] = vb.Object.Name
		end
	end
	
	t.Spells = {}
	
	for key, value in pairs(self.Spells.Items) do
		t.Spells[key] = value[1].Object.Name
	end
	
	t.Skills = {}
	
	for key, value in pairs(self.Skills) do
		t.Skills[key] = value.Xp
	end
end
