TBook = {}

function TBook:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Normal
	
	self.AlwaysDraw = true
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	self.Name = "Windi Book"
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
end

function TBook:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	
	self.IsOwned = false
end

function TBook:OnTake(arg)
	self.Owner = arg.Owner
	self.IsOwned = true
	
	self.Location = self.Owner.Location
end

function TBook:OnUse(arg)
	local magic = self.Owner.Skills.Magic
	local attack = self.Owner.Skills.Attack
	local alreadyHas = false
	
	for _, va in pairs(self.Owner.Spells.Items) do
		if va[1].Object.Name == "Tornado" then
			alreadyHas = true
			break
		end
	end
	
	if not alreadyHas then
		if magic then
			magic.Xp = magic:XpForLevel(magic:LevelForXp(magic.Xp) + 1)
			Messenger:Add(self.Owner.Name .. " learned how to operate more powerful magic!")
		end
		
		if self.Owner.Spells then
			self.Owner.Spells:Push(self.Object.Objector:Add("Tornado")):OnSetOwner({ Owner = self.Owner })
			Messenger:Add(self.Owner.Name .. " learned a powerful wind spell!")
		end
	else
		if attack then
			attack.Xp = attack:XpForLevel(magic:Level() + 1)
			Messenger:Add(self.Owner.Name .. " learned quite a bit on melee weaponry...")
			Messenger:Add("...in windi areas, with a longitude over 50 degrees!")
		end
	end
	
	if self.Owner.OnUsedUpItem then
		self.Owner:OnUsedUpItem({ Item = self })
	end
end

function TBook:Update(arg)
	if self.IsOwned then
		self.Location = self.Owner.Location
	end
end

function TBook:Draw(buffer, camera)
	if not self.IsOwned then
		GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(150, 150, 150), Graphics.MakeColor(150, 150, 50), "Bw")
	end
end
