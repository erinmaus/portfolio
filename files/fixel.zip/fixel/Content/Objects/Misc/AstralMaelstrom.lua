AstralMaelstrom = {}

function AstralMaelstrom:Initialize(obj)
	self.Object = obj
	
	self.Width = 1 -- These change later
	self.Height = 1 
	
	self.DrawOrder = DrawOrder.Normal
	self.AlwaysDraw = true
	
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	dofile(Game.AbsolutePath .. "Content/Particles/CircleZap.lua")
	
	self.ZapPack = Particle.Utilities.CreatePack(500, 0, 0, Particle.Particles.CircleZap)
	self.Zappers = {}
	
	self.Name = "Astral Maelstrom"
	
	self.Attack = { Power = 150, Type = "Astral" }
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/AstralSpell.lua")
	self.Effect = MusicBuilder.CreateFromTable(AstralSpellFx)
end

function AstralMaelstrom:OnSetOwner(arg)
	self.Owner = arg.Owner
end

function AstralMaelstrom:OnCast(arg)
	Messenger:Add(self.Owner.Name .. " asked Creator for the power to summon an...")
	Messenger:Add("...Astral Maelstrom!")
	
	for i=1, 200 do
		local free = Particle.Utilities.FreeSpot(self.Zappers)
		
		if free == nil and #self.Zappers < self.ZapPack.Max then
			table.insert(self.Zappers, Particle.Create(self.ZapPack.Gravity, self.ZapPack.VTable, nil, arg))
		else
			Particle.Create(self.ZapPack.Gravity, self.ZapPack.VTable, self.Zappers[free], arg)
		end
	end
	
	local objs = self.Object.Objector:GetObjectsAtXY(Point.Create(arg.TileX, arg.TileY))
	local o
	
	for key, value in pairs(objs) do
		if value.OnHit then
			o = value
		end
	end
	
	if not o then
		o = self.Object.Objector:GetObjectAtXY(Point.Create(arg.TileX, arg.TileY))
	end
	
	if o and o.OnHit then
		o:OnHit({ Attack = self.Attack, Level = self.Owner.Skills.Magic:CurrentLevel() })
		Messenger:Add(o.Name .. " got nailed with the maelstrom!")
		
		if self.Owner.OnSetTarget then
			if o.Skills and o.Skills.HP and o.Skills.HP:CurrentLevel() < 1 then
				self.Owner:OnSetTarget({})
			elseif o.Skills and o.Skills.HP then
				self.Owner:OnSetTarget({ Target = o })
			end
		end
	else
		Messenger:Add(self.Owner.Name .. " should really know when to use the Creator's power...")
	end
	
	self.Effect:Play(255, 128, 1000, false)
end

function AstralMaelstrom:Update()
	if self.Owner then
		self.Location = self.Owner.Location
	end
	
	Particle.Utilities.Update(self.ZapPack, self.Zappers, nil, -1)
end

function AstralMaelstrom:Draw(buffer, camera)
	Particle.Utilities.Draw(self.Zappers, buffer, { Camera = camera })
end
