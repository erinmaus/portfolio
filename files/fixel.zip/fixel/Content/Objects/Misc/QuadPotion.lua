QuadPotion = {}

function QuadPotion:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Normal
	
	self.AlwaysDraw = true
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	self.Name = "Quad Potion"
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
end

function QuadPotion:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.IsOwned = false
end

function QuadPotion:OnTake(arg)
	self.Owner = arg.Owner
	self.IsOwned = true
	
	self.Location = self.Owner.Location
end

function QuadPotion:OnUse(arg)
	local hp = self.Owner.Skills.HP
	
	if hp.AdditionalXp < 0 then
		hp.AdditionalXp = 0
	else
		Messenger:Add("Quad power, wasted amongst useless goals.")
	end
	
	if self.Owner.OnUsedUpItem then
		self.Owner:OnUsedUpItem({ Item = self })
	end
end

function QuadPotion:Update()
	if self.IsOwned then
		self.Location = self.Owner.Location
	end
end

function QuadPotion:Draw(buffer, camera)
	if not self.IsOwned then
		GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(200, 200, 100), Graphics.MakeColor(150, 150, 50), "QP")
	end
end
