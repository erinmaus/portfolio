Eggbert = {}

function Eggbert:Initialize(obj)
	self.Object = obj
	
	self.Width = 3
	self.Height = 4
	
	self.Skills =
	{
		HP = Skill.Create(),
		Defence = Skill.Create()
	}
	
	self.Skills.HP.Xp = self.Skills.HP:XpForLevel(20)
	self.Skills.Defence.Xp = self.Skills.Defence:XpForLevel(20)
	
	self.DrawOrder = DrawOrder.Normal
	
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = false
	self.IsDead = false
	self.IsSolid = true
	self.HasSpawned = false
	
	self.Armor = Armor.Create()
	self.Armor.Stab = 1.5
	self.Armor.Slash = 0.25
	self.Armor.Crush = 500
	self.Armor.Fire = 250
	
	self.RandomMessages =
	{
		"Hey, you aren't from my carton!",
		"Don't hurt me!",
		"I need to do my homework..."
	}
	self.MessageTimer = Timer.Create(15, function()
		Messenger:Add(self.RandomMessages[math.random(1, 3)])
	end)
	
	self.Name = "Eggbert"
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
end

function Eggbert:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.Object:Synchronize()
end

function Eggbert:OnHit(arg)
	self.Skills.HP.AdditionalXp = self.Skills.HP.AdditionalXp - self.Armor:CalculateDamage(arg.Attack, arg.Level, self.Skills.Defence:CurrentLevel())
	
	if self.Skills.HP:CurrentLevel() < 1 then
		self.IsDead = true
	else
		if math.random() < 0.5 then
			Messenger:Add("/me slaps you")
		end
	end
end

function Eggbert:Update(arg)
	if self.IsDead then
		Messenger:Add("I've been boooiiillleeeedddd!!")
		
		self.Object.Objector:Get("DeathParty"):OnDeathSpawn({ X = self.Location.X + 1, Y = self.Location.Y + 1 })
		self.Object.Objector:Get("DeathParty"):OnDeathSpawn({ X = self.Location.X + 1, Y = self.Location.Y + 2 })
		
		self.Object:Remove()
	end
	self.MessageTimer:Update()
end

function Eggbert:Draw(buffer, camera)
	GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(255, 255, 255), Graphics.MakeColor(210, 210, 210), "EggB")
end
