AMUEggbert = {}
-- Armored Mecha Ultra Eggbert

function AMUEggbert:Initialize(obj)
	self.Object = obj
	
	self.Width = 3
	self.Height = 4
	
	self.Skills =
	{
		HP = Skill.Create(),
		Attack = Skill.Create(),
		Magic = Skill.Create(),
		Defence = Skill.Create()
	}
	
	self.Skills.HP.Xp = self.Skills.HP:XpForLevel(20)
	self.Skills.Attack.Xp = self.Skills.Attack:XpForLevel(7)
	self.Skills.Magic.Xp = self.Skills.Magic:XpForLevel(9)
	self.Skills.Defence.Xp = self.Skills.Defence:XpForLevel(20)
	
	self.DrawOrder = DrawOrder.Normal
	
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = false
	self.IsDead = false
	self.IsSolid = true
	self.HasSpawned = false
	
	self.Armor = Armor.Create()
	self.Armor.Stab = 1.15
	self.Armor.Slash = 0.25
	self.Armor.Crush = 1.25
	self.Armor.Fire = 0.25
	
	self.Name = "Armored Mecha Ultra Eggbert"
	
	self.MagicAttack = { Power = 10, Type = "Magic" }
	
	self.MagicTimer = Timer.Create(5.0, function()
		local p = self.Object.Objector:Get("D132")
		
		if p and not self.Room:Collision(Rectangle.Create(p.Location.X, p.Location.Y, p.Width, p.Height)) and self.Room:Collision(self.Object.Stage.Camera) then
			Messenger:Add(p.Name .. "'s health fell slightly...")
			self.Skills.HP.AdditionalXp = math.min(self.Skills.HP.AdditionalXp + 1000, 0)
			
			p:OnHit({ Attack = self.MagicAttack, Level = self.Skills.Magic:CurrentLevel() })
		elseif p and self.Room:Collision(Rectangle.Create(p.Location.X, p.Location.Y, p.Width, p.Height)) then
			Messenger:Add("Eggbert tried to summon a Twornadoe...")
			
			local loc = Point.Create(self.Room.X + math.random(1, self.Room.Width - 1), self.Room.Y + math.random(1, self.Room.Height - 1))
			
			if GameObject.Collision.IsSpotFree(self.Object.Stage.Map, self.Object.Objector, loc.X, loc.Y) then
				GameObject.Spawning.Spawn(self.Object.Objector, "Twornadoe", loc.X, loc.Y).DropBook = false
				
				Messenger:Add("...and did it rightly!")
				
				self.Effect:Play(255, 128, 1000, false)
			else
				Messenger:Add("...but failed terribly!")
			end
		end
	end)
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Summon.lua")
	self.Effect = MusicBuilder.CreateFromTable(SummonFx)
end

function AMUEggbert:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.HasSpawned = true
	self.Object:Synchronize()
end

function AMUEggbert:OnSetRoom(arg)
	self.Room = arg.Room
end

function AMUEggbert:OnHit(arg)
	self.Skills.HP.AdditionalXp = self.Skills.HP.AdditionalXp - self.Armor:CalculateDamage(arg.Attack, arg.Level, self.Skills.Defence:CurrentLevel())
	
	if self.Skills.HP:CurrentLevel() < 1 then
		self.IsDead = true
	else
		if math.random() < 0.5 then
			Messenger:Add("Hey! Stop that!")
		end
	end
end

function AMUEggbert:Update()
	if self.IsDead then
		Messenger:Add("I've been boooiiillleeeedddd [once again]!!")
		
		self.Object.Objector:Get("DeathParty"):OnDeathSpawn({ X = self.Location.X + 1, Y = self.Location.Y + 1 })
		self.Object.Objector:Get("DeathParty"):OnDeathSpawn({ X = self.Location.X + 1, Y = self.Location.Y + 2 })
		
		self.Object:Remove()
	end
	
	self.MagicTimer:Update()
end

function AMUEggbert:Draw(buffer, camera)
	GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(100, 100, 100), Graphics.MakeColor(210, 210, 210), "AmuE")
end
