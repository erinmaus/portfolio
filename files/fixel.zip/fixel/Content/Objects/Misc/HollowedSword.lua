HollowedSword = {}

function HollowedSword:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.First
	
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	self.Owner = self
	self.IsOwned = false
	self.HasBeenUsed = false
	
	self.PlusPosition = Point.Create(0, 0)
	
	self.Name = "Hollowed Sword"
	
	self.RegularAttack = { Power = 5, Type = "Slash" }
	self.SpecialAttack = { Power = 10, Type = "Fire" }
	
	dofile(Game.AbsolutePath .. "Content/Particles/FireExplosion.lua")
	self.FirePack = Particle.Utilities.CreatePack(150, 0, 0, Particle.Particles.FireExplosion)
	self.Fire = {}
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Fire.lua")
	self.Effect = MusicBuilder.CreateFromTable(FireFx)
end

function HollowedSword:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.IsOwned = false
end

function HollowedSword:OnTake(arg)
	self.Owner = arg.Owner
	self.IsOwned = true
	
	self.Location = self.Owner.Location
end

function HollowedSword:OnDrop(arg)
	self.Owner = nil
	self.IsOwned = false
end

function HollowedSword:OnUse(arg)
	local loc = arg.Plus + self.Location
	local objs = self.Object.Objector:GetObjectsAtXY(loc)
	local o
	
	-- Hit only the first object on the block
	for key, value in pairs(objs) do
		if value.OnHit then
			o = value
			break
		end
	end
	
	if not o then
		o = self.Object.Objector:GetObjectAtXY(arg.Plus + self.Location)
	end
	
	if o and not o.IsDead then
		if o.OnHit then
			o:OnHit({ Attack = self.RegularAttack, Level = self.Owner.Skills.Attack:CurrentLevel() })
			o:OnHit({ Attack = self.SpecialAttack, Level = self.Owner.Skills.Attack:CurrentLevel() })
			
			Messenger:Add(self.Owner.Name .. " set aflame the " .. o.Name .. "!")
			
			if self.Owner.OnSetTarget then
				if o.Skills and o.Skills.HP and o.Skills.HP:CurrentLevel() < 1 then
					self.Owner:OnSetTarget({})
				elseif o.Skills and o.Skills.HP then
					self.Owner:OnSetTarget({ Target = o })
				end
			end
		else
			if self.Owner.OnHit then
				self.Owner:OnHit({ Attack = self.SpecialAttack, Level = self.Owner.Skills.Attack:CurrentLevel() })
				
				Messenger:Add(self.Owner.Name .. " tried to use the fiery blade against nothing...")
				Messenger:Add("...but hurt itself in the process!")
			else
				Messenger:add(self.Owner.Name .. " is, in short, an idiot.")
			end
			
			loc = self.Location
		end
	end
	
	local parg =
	{
		TileX = loc.X,
		TileY = loc.Y,
		TileWidth = self.Object.Stage.TileWidth,
		TileHeight = self.Object.Stage.TileHeight
	}
	
	for i=1, 50 do
		local free = Particle.Utilities.FreeSpot(self.Fire)
		
		if free == nil and #self.Fire < self.FirePack.Max then
			table.insert(self.Fire, Particle.Create(self.FirePack.Gravity, self.FirePack.VTable, nil, parg))
		else
			Particle.Create(self.FirePack.Gravity, self.FirePack.VTable, self.Fire[free], parg)
		end
	end
	
	self.Effect:Play(255, 128, 1000, false)
end

function HollowedSword:Update()
	if self.IsOwned then
		self.Location = self.Owner.Location
	end
	
	Particle.Utilities.Update(self.FirePack, self.Fire, nil, -1)
end

function HollowedSword:Draw(buffer, camera)
	if not self.IsOwned then
		GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(175, 175, 175), Graphics.MakeColor(230, 0, 0), "HS")
	end
	
	Particle.Utilities.Draw(self.Fire, buffer, { Camera = camera })
end
