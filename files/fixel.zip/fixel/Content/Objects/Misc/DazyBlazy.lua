DazyBlazy = {}

function DazyBlazy:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Normal
	self.AlwaysDraw = true
	
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	dofile(Game.AbsolutePath .. "Content/Particles/FireExplosion.lua")
	
	self.FirePack = Particle.Utilities.CreatePack(200, 0, 0, Particle.Particles.FireExplosion)
	self.Fire = {}
	
	self.Directions =
	{
		[Direction.Up] = Point.Create(0, -1),
		[Direction.Down] = Point.Create(0, 1),
		[Direction.Left] = Point.Create(-1, 0),
		[Direction.Right] = Point.Create(1, 0)
	}
	
	self.Name = "Dazy Blazy"
	
	self.Attack = { Power = 5, Type = "Fire" }
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Fire.lua")
	self.Effect = MusicBuilder.CreateFromTable(FireFx)
end

function DazyBlazy:OnSetOwner(arg)
	self.Owner = arg.Owner
	
	self.Location = self.Owner.Location
end

function DazyBlazy:OnCast(arg)
	Messenger:Add(self.Owner.Name .. " cast Dazy Blazy!")
	local hit = false
	
	for i = 1, 4 do
		local loc = self.Location + (self.Directions[arg.Direction] * Point.Create(i, i))
		
		for j = 0, 50 do
			local free = Particle.Utilities.FreeSpot(self.Fire)
			local parg =
			{
				TileX = loc.X,
				TileY = loc.Y,
				TileWidth = arg.TileWidth,
				TileHeight = arg.TileHeight
			}
			
			if free == nil and #self.Fire < self.FirePack.Max then
				table.insert(self.Fire, Particle.Create(self.FirePack.Gravity, self.FirePack.VTable, nil, parg))
			else
				Particle.Create(self.FirePack.Gravity, self.FirePack.VTable, self.Fire[free], parg)
			end
		end
		
		local objs = self.Object.Objector:GetObjectsAtXY(loc)
		local o
	
		for key, value in pairs(objs) do
			if value.OnHit then
				o = value
				break
			end
		end
		
		if not o then
			o = self.Object.Objector:GetObjectAtXY(Point.Create(arg.TileX, arg.TileY))
		end
		
		if o and o.OnHit then
			o:OnHit({ Attack = self.Attack, Level = self.Owner.Skills.Attack:CurrentLevel() / 2 + self.Owner.Skills.Magic:CurrentLevel() / 2 })
			Messenger:Add(o.Name .. " got burnt-slashed by the blazy!")
			
			hit = true
			
			if self.Owner.OnSetTarget then
				if o.Skills and o.Skills.HP and o.Skills.HP:CurrentLevel() < 1 then
					self.Owner:OnSetTarget({})
				elseif o.Skills and o.Skills.HP then
					self.Owner:OnSetTarget({ Target = o })
				end
			end
		end
	end
	
	if not hit then
		Messenger:Add(self.Owner.Name .. " is, to put it simply, an idiotic idiot.")
	end
	
	self.Effect:Play(255, 128, 1000, false)
end

function DazyBlazy:Update()
	if self.Owner then
		self.Location = self.Owner.Location
	end
	
	Particle.Utilities.Update(self.FirePack, self.Fire, nil, -1)
end

function DazyBlazy:Draw(buffer, camera)
	Particle.Utilities.Draw(self.Fire, buffer, { Camera = camera })
end
