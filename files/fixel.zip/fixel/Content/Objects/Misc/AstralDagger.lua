AstralDagger = {}

function AstralDagger:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.First
		
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	self.Owner = self
	self.IsOwned = false
	
	self.PlusPosition = Point.Create(0, 0)
	
	self.Name = "Astral Dagger"
	
	self.RegularAttack = { Power = 15, Type = "Stab" }
	self.SpecialAttack = { Power = 5, Type = "Astral" }
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/AstralSpell.lua")
	self.Effect = MusicBuilder.CreateFromTable(AstralSpellFx)
end

function AstralDagger:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.IsOwned = false
end

function AstralDagger:OnTake(arg)
	self.Owner = arg.Owner
	self.IsOwned = true
	
	self.Location = self.Owner.Location
end

function AstralDagger:OnDrop(arg)
	self.Owner = nil
	self.IsOwned = false
end

function AstralDagger:OnUse(arg)
	local objs = self.Object.Objector:GetObjectsAtXY(arg.Plus + self.Location)
	local o
	
	-- Hit only the first object on the block
	for key, value in pairs(objs) do
		if value.OnHit then
			o = value
			break
		end
	end
	
	if not o then
		o = self.Object.Objector:GetObjectAtXY(arg.Plus + self.Location)
	end
	
	if o and not o.IsDead then
		if o.OnHit then
			o:OnHit({ Attack = self.RegularAttack, Level = self.Owner.Skills.Attack:CurrentLevel() })
			o:OnHit({ Attack = self.SpecialAttack, Level = self.Owner.Skills.Attack:CurrentLevel() })
			
			Messenger:Add(self.Owner.Name .. " stabbed " .. o.Name .. ", using the forces of Astral-ness!")
			
			if self.Owner.OnSetTarget then
				if o.Skills and o.Skills.HP and o.Skills.HP:CurrentLevel() < 1 then
					self.Owner:OnSetTarget({})
				elseif o.Skills and o.Skills.HP then
					self.Owner:OnSetTarget({ Target = o })
				end
			elseif o.Name then
				Messenger:Add(self.Owner.Name .. " isn't too bright...")
			end
		end
	end
	
	self.Effect:Play(255, 128, 1000, false)
end

function AstralDagger:Update()
	if self.IsOwned then
		self.Location = self.Owner.Location
	end
end

function AstralDagger:Draw(buffer, camera)
	if not self.IsOwned then
		GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(175, 175, 175), Graphics.MakeColor(125, 30, 125), "A>")
	end
end
