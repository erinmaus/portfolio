Tornado = {}

function Tornado:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Normal
	self.AlwaysDraw = true
	
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	dofile(Game.AbsolutePath .. "Content/Particles/BlackExplosion.lua")
	
	self.WindPack = Particle.Utilities.CreatePack(250, 0, 0, Particle.Particles.BlackExplosion)
	self.Wind = {}
	
	self.Directions =
	{
		[Direction.Up] = Point.Create(0, -1),
		[Direction.Down] = Point.Create(0, 1),
		[Direction.Left] = Point.Create(-1, 0),
		[Direction.Right] = Point.Create(1, 0)
	}
	
	self.Name = "Tornado"
	
	self.RegularAttack = { Power = 5, Type = "Magic" }
	self.SpecialAttack = { Power = 5, Type = "Crush" }
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Wind.lua")
	self.Effect = MusicBuilder.CreateFromTable(WindFx)
end

function Tornado:OnSetOwner(arg)
	self.Owner = arg.Owner
	
	self.Location = self.Owner.Location
end

function Tornado:OnCast(arg)
	Messenger:Add(self.Owner.Name .. " used the power of wind to create a tornado!")
	
	for i = 1, 5 do
		local loc = self.Location + (self.Directions[arg.Direction] * Point.Create(i, i))
		
		for j = 0, 50 do
			local free = Particle.Utilities.FreeSpot(self.Wind)
			local parg =
			{
				TileX = loc.X,
				TileY = loc.Y,
				TileWidth = arg.TileWidth,
				TileHeight = arg.TileHeight
			}
			
			if free == nil and #self.Wind < self.WindPack.Max then
				table.insert(self.Wind, Particle.Create(self.WindPack.Gravity, self.WindPack.VTable, nil, parg))
			else
				Particle.Create(self.WindPack.Gravity, self.WindPack.VTable, self.Wind[free], parg)
			end
		end
		
		local objs = self.Object.Objector:GetObjectsAtXY(loc)
		local o
	
		for key, value in pairs(objs) do
			if value.OnHit then
				o = value
				break
			end
		end
		
		if not o then
			o = self.Object.Objector:GetObjectAtXY(Point.Create(arg.TileX, arg.TileY))
		end
		
		if o and o.OnHit then
			o:OnHit({ Attack = self.RegularAttack, Level = self.Owner.Skills.Attack:CurrentLevel() + self.Owner.Skills.Magic:CurrentLevel() / 2 })
			o:OnHit({ Attack = self.SpecialAttack, Level = self.Owner.Skills.Attack:CurrentLevel() + self.Owner.Skills.Magic:CurrentLevel() / 2 })
			Messenger:Add(o.Name .. " got crushed by the magical tornado!")
			
			hit = true
			
			if self.Owner.OnSetTarget then
				if o.Skills and o.Skills.HP and o.Skills.HP:CurrentLevel() < 1 then
					self.Owner:OnSetTarget({})
				elseif o.Skills and o.Skills.HP then
					self.Owner:OnSetTarget({ Target = o })
				end
			end
		end
	end
	
	if not hit then
		Messenger:Add(self.Owner.Name .. " has misused the powers of wind...")
	end
	
	self.Effect:Play(255, 128, 1000, false)
end

function Tornado:Update()
	if self.Owner then
		self.Location = self.Owner.Location
	end
	
	Particle.Utilities.Update(self.WindPack, self.Wind, nil, -1)
end

function Tornado:Draw(buffer, camera)
	Particle.Utilities.Draw(self.Wind, buffer, { Camera = camera })
end
