PunyDagger = {}

function PunyDagger:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.First
		
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	self.Owner = self
	self.IsOwned = false
	
	self.PlusPosition = Point.Create(0, 0)
	
	self.Name = "Puny Dagger"
	
	self.Attack = { Power = 10, Type = "Stab" }
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
end

function PunyDagger:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.IsOwned = false
end

function PunyDagger:OnTake(arg)
	self.Owner = arg.Owner
	self.IsOwned = true
	
	self.Location = self.Owner.Location
end

function PunyDagger:OnDrop(arg)
	self.Owner = nil
	self.IsOwned = false
end

function PunyDagger:OnUse(arg)	
	local objs = self.Object.Objector:GetObjectsAtXY(arg.Plus + self.Location)
	local o
	
	-- Hit only the first object on the block
	for key, value in pairs(objs) do
		if value.OnHit then
			o = value
			break
		end
	end
	
	if not o then
		o = self.Object.Objector:GetObjectAtXY(arg.Plus + self.Location)
	end
	
	if o and not o.IsDead then
		if o.OnHit then
			o:OnHit({ Attack = self.Attack, Level = self.Owner.Skills.Attack:CurrentLevel() })
			Messenger:Add(self.Owner.Name .. " used the " .. self.Name .. " against " .. o.Name .. "!")
			
			if self.Owner.OnSetTarget then
				if o.Skills and o.Skills.HP and o.Skills.HP:CurrentLevel() < 1 then
					self.Owner:OnSetTarget({})
				elseif o.Skills and o.Skills.HP then
					self.Owner:OnSetTarget({ Target = o })
				end
			end
		elseif o.Name then
			Messenger:Add(self.Owner.Name .. " should know attacking a " .. o.Name .. " does nothing...")
		else
			Messenger:Add(self.Owner.Name .. " used the " .. self.Name .. " against nothing!")
			
			if self.Owner.OnSetTarget then
				self.Owner:OnSetTarget({}) -- No target.
			end
		end
	end
end

function PunyDagger:Update()
	if self.IsOwned then
		self.Location = self.Owner.Location
	end
end

function PunyDagger:Draw(buffer, camera)
	if not self.IsOwned then
		GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(175, 175, 175), Graphics.MakeColor(125, 125, 125), "D>")
	end
end
