EvilMinion = {}

function EvilMinion:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Normal
	
	self.AlwaysDraw = true -- For the particles.
	self.CanMove = true
	self.IsInvincible = false
	self.IsDead = false
	self.IsSolid = true
	self.HasSpawned = false
	
	self.IgnoreDeathMessage = false
	self.CanSummon = false
	
	dofile(Game.AbsolutePath .. "Content/Particles/CircleZap.lua")
	self.ZapPack = Particle.Utilities.CreatePack(100, 0, 0, Particle.Particles.CircleZap)
	self.Zappers = {}
	
	self.Skills =
	{
		HP = Skill.Create(),
		Attack = Skill.Create(),
		Defence = Skill.Create()
	}
	
	self.Skills.HP.Xp = self.Skills.HP:XpForLevel(math.random(4, 5))
	self.Skills.Attack.Xp = self.Skills.Attack:XpForLevel(7)
	self.Skills.Defence.Xp = self.Skills.Attack:XpForLevel(5)
	
	self.Armor = Armor.Create()
	self.Armor.Stab = 1.5 -- Hits more
	self.Armor.Crush = 0.75 -- Hits less
	self.Armor.Slash = 1.25 -- Hits slightly better
	
	self.Positions =
	{
		[Direction.Up] = Point.Create(0, -1),
		[Direction.Down] = Point.Create(0, 1),
		[Direction.Left] = Point.Create(-1, 0),
		[Direction.Right] = Point.Create(1, 0)
	}
	
	self.Directions = Direction.Up
	
	self.Inventory = Inventory.Create()
	
	self.Inventory:Push(self.Object.Objector:Add("PunyDagger"))
	self.Inventory:CurrentItem():OnTake({ Owner = self })
	
	self.PathFinder = AStar.Create(self.Object.Stage.Map, self.Object.Objector, 10, 14)
	self.MoveTimer = Timer.Create(0.3, function()
		local p = self.Object.Objector:Get("D132")
		
		if p and self.Object.Stage.Camera:Collision(Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)) and Game.Input:KeyState(Key.Z) == ButtonState.Released then
			self.PathFinder:Update(self.Location.X, self.Location.Y, p.Location.X, p.Location.Y)
			self.Location = self.PathFinder.Target
		elseif not self.IsLeader then
			self.PathFinder:Update(self.Location.X, self.Location.Y, self.Leader.Location.X, self.Leader.Location.Y)
			self.Location = self.PathFinder.Target
		end
	end)
	
	self.AttackTimer = Timer.Create(1.0, function()
		local p = self.Object.Objector:Get("D132")
		
		for key, value in pairs(self.Positions) do
			if p.Location == self.Location + value then
				self.Inventory:CurrentItem():OnUse({ Plus = value })
			end
		end
	end)
	
	self.SummonTimer = Timer.Create(3, function()
		if #self.Minions < 2 then
			local pos =
			{
				Point.Create(0, 1),
				Point.Create(1, 0),
				Point.Create(0, -1),
				Point.Create(-1, 0)
			}
			local i = math.random(1, 4)
			local p = self.Location + pos[i] 
			
			if GameObject.Collision.IsSpotFree(self.Object.Stage.Map, self.Object.Objector, p.X , p.Y) then
				local m = GameObject.Spawning.Spawn(self.Object.Objector, "EvilMinion", p.X, p.Y)
				m:OnSetTeam({ Team = self.Team, TeamRank = 0, Leader = self })
				
				table.insert(self.Minions, m)
				
				Messenger:Add("Grraa'lac minion! Come from great beyond!")
				
				for i=1, 75 do
					local free = Particle.Utilities.FreeSpot(self.Zappers)
					local arg =
					{
						TileX = p.X,
						TileY = p.Y,
						TileWidth = self.Object.Stage.TileWidth,
						TileHeight = self.Object.Stage.TileHeight
					}
					
					if free == nil and #self.Zappers < self.ZapPack.Max then
						table.insert(self.Zappers, Particle.Create(self.ZapPack.Gravity, self.ZapPack.VTable, nil, arg))
					else
						Particle.Create(self.ZapPack.Gravity, self.ZapPack.VTable, self.Zappers[free], arg)
					end
				end
				
				self.Effect:Play(255, 128, 1000, false)
			end
		end
	end)
	
	self.Name = "Grraa'lac"
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Summon.lua")
	self.Effect = MusicBuilder.CreateFromTable(SummonFx)
end

function EvilMinion:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.HasSpawned = true
end

function EvilMinion:OnSetTeam(arg)
	self.Team = arg.Team
	self.TeamRank = arg.TeamRank
	self.Leader = arg.Leader or "none"
	
	if arg.Leader == nil then
		self.IsLeader = true
		self.Minions = {}
		
		self.Name = self.Name .. " Leader"
		
		self.CanSummon = true
		
		self.Inventory:Pop().Object:Remove()
		self.Inventory:Push(self.Object.Objector:Add("AstralDagger")):OnTake({ Owner = self })
	else
		self.IsLeader = false
	end
end

function EvilMinion:OnSetLeader(arg)
	self.Leader = arg.Leader
	self.IgnoreDeathMessage = true
end

function EvilMinion:OnDeath(arg)
	if self.IsLeader then
		local i = 1
		for key, value in pairs(self.Minions) do
			if rawequal(value, arg.Minion) then
				table.remove(self.Minions, i)
				break
			end
			
			i = i + 1
		end
	elseif not self.IgnoreDeathMessage and not arg.IsMinion then
		self.IsLeader = true
		self.Leader = "none"
		self.Minions = {}
		
		self.Name = self.Name .. " Leader"
		
		for key, value in pairs(arg.Minions) do
			self.Minions[key] = value
			value:OnSetLeader({ Leader = self })
		end
	end
end

function EvilMinion:OnHit(arg)
	self.Skills.HP.AdditionalXp = self.Skills.HP.AdditionalXp - self.Armor:CalculateDamage(arg.Attack, arg.Level, self.Skills.Defence:CurrentLevel())
	
	if self.Skills.HP:CurrentLevel() < 1 then
		self.IsDead = true
		
		if self.IsLeader then			
			self.Object.Objector:BroadcastToTeam("Death", { Minions = self.Minions, IsMinion = false }, self.Team, -1)
		else
			self.Object.Objector:BroadcastToTeam("Death", { Minion = self, IsMinion = true }, self.Team, -1)
		end
	end
end

function EvilMinion:Update()
	if self.Object.Stage.Camera:Collision(Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)) then
		local p = self.Object.Objector:Get("D132")
		
		if p then
			local ra = Rectangle.Create(p.Location.X - 1, p.Location.Y - 1, p.Width + 2, p.Height + 2)
			local rb = Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)
			local rc
			
			if self.IsLeader then
				rc = Rectangle.Create(self.Location.X, self.Location.Y, 0, 0)
			else
				rc = Rectangle.Create(self.Leader.Location.X - 1, self.Leader.Location.Y - 1, self.Leader.Width + 2, self.Leader.Height + 2)
			end
			
			if not ra:Collision(rb) and not (self.Object.Stage.Camera:Collision(rb) and rb:Collision(rc)) then
				self.MoveTimer:Update()
				
				-- Left
				if p.Location.X < self.Location.X and p.Location.Y == self.Location.Y then
					self.Direction = Direction.Left
				elseif p.Location.X > self.Location.X and p.Location.Y == self.Location.Y then
					self.Direction = Direction.Right
				elseif p.Location < self.Location then
					self.Direction = Direction.Up
				else
					self.Direction = Direction.Down
				end
			else
				self.MoveTimer:Restart()
				self.AttackTimer:Update()
			end
		end
		
		if self.IsLeader and self.CanSummon then
			self.SummonTimer:Update()
		end
	end
	
	if self.IsLeader and self.CanSummon then
		Particle.Utilities.Update(self.ZapPack, self.Zappers, nil, -1)
	end
	
	self.IgnoreDeathMessage = false
	
	if self.IsDead then
		if self.IsLeader then
			if #self.Minions > 0 then
				Messenger:Add("Grrrraaaaaaa! You shall take my place!")
			else
				Messenger:Add("Curse you! Grrrraaaaa!!")
			end
		else
			Messenger:Add("Nooo!! Grrraaaaaaaaaaaaaaaa!!")
		end
		
		for _, va in pairs(self.Inventory.Items) do
			for _, vb in pairs(va) do
				vb:OnDrop()
			end
		end
		
		self.Object.Objector:Get("DeathParty"):OnDeathSpawn({ X = self.Location.X, Y = self.Location.Y })
		
		self.Object:Remove()
	end
end

function EvilMinion:Draw(buffer, camera)
	local bb = Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)
	
	if bb:Collision(camera) then
		if self.IsLeader then
			GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(0, 0, 0), Graphics.MakeColor(75, 75, 75), "GL")
		else
			GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(50, 50, 50), Graphics.MakeColor(75, 75, 75), "G'l")
		end
	end
	
	if self.IsLeader then
		Particle.Utilities.Draw(self.Zappers, buffer, { Camera = camera })
	end
end
