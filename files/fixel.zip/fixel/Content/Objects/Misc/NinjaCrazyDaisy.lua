NinjaCrazyDaisy = {}

function NinjaCrazyDaisy:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Normal
	
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = false
	self.IsDead = false
	self.IsSolid = true
	self.HasSpawned = false
	
	self.Spells = Inventory.Create()
	
	self.Spells:Push(self.Object.Objector:Add("DazyBlazy"))
	self.Spells:BackItem():OnSetOwner({ Owner = self })
	
	self.Name = "Ninja Crazy Daisy"
	
	self.Armor = Armor.Create()
	self.Armor.Stab = 0.25
	self.Armor.Crush = 0.25
	self.Armor.Slash = 2.0
	self.Armor.Fire = 0.5
	
	self.Skills =
	{
		HP = Skill.Create(),
		Attack = Skill.Create(),
		Magic = Skill.Create(),
		Defence = Skill.Create()
	}
	
	self.Skills.HP.Xp = self.Skills.HP:XpForLevel(math.random(12, 13))
	self.Skills.Attack.Xp = self.Skills.Attack:XpForLevel(7)
	self.Skills.Magic.Xp = self.Skills.Magic:XpForLevel(3)
	self.Skills.Defence.Xp = self.Skills.Defence:XpForLevel(2)
	
	self.Positions =
	{
		[Direction.Up] = Point.Create(0, -1),
		[Direction.Down] = Point.Create(0, 1),
		[Direction.Left] = Point.Create(-1, 0),
		[Direction.Right] = Point.Create(1, 0)
	}
	
	self.Direction = Direction.Up
	
	self.PathFinder = AStar.Create(self.Object.Stage.Map, self.Object.Objector, 10, 16)
	self.MoveTimer = Timer.Create(0.5, function()
		local p = self.Object.Objector:Get("D132")
		
		if p and not Rectangle.Create(p.Location.X - 1, p.Location.Y - 1, p.Width + 2, p.Height + 2):Collision(Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)) then
			self.PathFinder:Update(self.Location.X, self.Location.Y, p.Location.X, p.Location.Y)
			self.Location = self.PathFinder.Target
		end
	end)
	
	self.AttackTimer = Timer.Create(1.0, function()
		local p = self.Object.Objector:Get("D132")
		
		if p then
			local dif = Point.Create(AStar.Utilities.ManhattanDistance(p.Location.X, p.Location.Y, self.Location.X, self.Location.Y))
			
			if dif <= Point.Create(1, 1) then
				for key, value in pairs(self.Positions) do
					if p.Location == self.Location + value then
						self:OnAttack({ Plus = value })
					end
				end
			else
				for key, value in pairs(self.Positions) do
					for i = 1, 4 do
						local loc = self.Location + (value * Point.Create(i, i))
						
						if p.Location == loc then
							self.Spells:CurrentItem():OnCast({ TileX = loc.X, TileY = loc.Y, TileWidth = self.Object.Stage.TileWidth,
								TileHeight = self.Object.Stage.TileHeight, Direction = key })
						end
					end
				end
			end
		end
	end)
	
	self.Attack = { Type = "Slash", Power = 15 }
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Slash.lua")
	self.Effect = MusicBuilder.CreateFromTable(SlashFx)
end

function NinjaCrazyDaisy:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.HasSpawned = true
end

function NinjaCrazyDaisy:OnAttack(arg)
	local objs = self.Object.Objector:GetObjectsAtXY(arg.Plus + self.Location)
	local o
	
	for key, value in pairs(objs) do
		if value.OnHit then
			o = value
			break
		end
	end
	
	if not o then
		o = self.Object.Objector:GetObjectAtXY(arg.Plus + self.Location)
	end
	
	if o and not o.IsDead then
		if o.OnHit then
			Messenger:Add("The " .. self.Name .. " slashed the " .. o.Name .. " with petals of metal!")
			
			o:OnHit({ Attack = self.Attack, Level = self.Skills.Attack:CurrentLevel() })
		else
			Messenger:Add("The " .. self.Name .. " is losing its mind!")
		end
	end
	
	self.Effect:Play(255, 128, 1000, false)
end

function NinjaCrazyDaisy:OnHit(arg)
	self.Skills.HP.AdditionalXp = self.Skills.HP.AdditionalXp - self.Armor:CalculateDamage(arg.Attack, arg.Level, self.Skills.Defence:CurrentLevel())
	
	if self.Skills.HP:CurrentLevel() < 1 then
		self.IsDead = true
	end
end

function NinjaCrazyDaisy:Update()
	self.MoveTimer:Update()
	self.AttackTimer:Update()
	
	if self.IsDead then
		self.Object.Objector:Get("DeathParty"):OnDeathSpawn({ X = self.Location.X, Y = self.Location.Y })
		Messenger:Add("Hiiiinooooo!!  *wilts*")
		
		for _, va in pairs(self.Spells.Items) do
			for _, vb in pairs(va) do
				vb.Object:Remove()
			end
		end
		
		self.Object:Remove()
	end
end

function NinjaCrazyDaisy:Draw(buffer, camera)
	GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(30, 200, 30), Graphics.MakeColor(255, 255, 96), "Nc")
end
