Tree = {}

function Tree:Initialize(obj)
	self.Location = Point.Create(13,2);
	
	self.Object = obj
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	self.Width = 1
	self.Height = 1
	
	self.CanMove = false
	self.IsSolid = true
	self.IsInvincible = true
	
	self.IsBurnt = false
	
	self.Name = "Tree"
end

function Tree:OnSpawn(arg)
	self.Location.X = arg.X
	self.Location.Y = arg.Y
end

function Tree:OnHit(arg)
	if arg.Attack.Type == "Fire" and not self.IsBurnt then
		self.IsBurnt = true
		Messenger:Add("\"Ouch!\" said the tree! Amazing!")
	end
end

function Tree:Draw(buffer, camera)
	if self.IsBurnt then
		GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(75, 75, 35), Graphics.MakeColor(50, 50, 15), "T")
	else
		GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(0, 76, 0), Graphics.MakeColor(0, 104, 0), "T")
	end
end
