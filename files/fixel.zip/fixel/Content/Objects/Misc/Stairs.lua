Stairs = {}

function Stairs:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.First
		
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	self.Name = "Boring Stairs"
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
end

function Stairs:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.HasSpawned = true
end

function Stairs:OnStep(arg)
	self.Object.Stage.State.CurrentFloor = self.Object.Stage.State.CurrentFloor + 1
	
	self.IsDead = true
end

function Stairs:Update()
	if self.IsDead then
		self.Object:Remove()
	end
end

function Stairs:Draw(buffer, camera)
	GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(155, 155, 155), Graphics.MakeColor(105, 105, 105), ">")
end
