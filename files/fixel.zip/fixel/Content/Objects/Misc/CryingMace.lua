CryingMace = {}

function CryingMace:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.First
	
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
	
	self.Owner = self
	self.IsOwned = false
	self.HasBeenUsed = false
	
	self.PlusPosition = Point.Create(0, 0)
	
	self.Name = "Crying Mace"
	
	self.RegularAttack = { Power = 20, Type = "Crush" }
	self.HolyAttack = { Power = 1, Type = "Holy" }
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Crush.lua")
	self.Effect = MusicBuilder.CreateFromTable(CrushFx)
end

function CryingMace:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.IsOwned = false
end

function CryingMace:OnTake(arg)
	self.Owner = arg.Owner
	self.IsOwned = true
	
	self.Location = self.Owner.Location
end

function CryingMace:OnDrop(arg)
	self.Owner = nil
	self.IsOwned = false
end

function CryingMace:OnUse(arg)
	local objs = self.Object.Objector:GetObjectsAtXY(arg.Plus + self.Location)
	local o
	
	-- Hit only the first object on the block
	for key, value in pairs(objs) do
		if value.OnHit then
			o = value
			break
		end
	end
	
	if not o then
		o = self.Object.Objector:GetObjectAtXY(arg.Plus + self.Location)
	end
	
	if o and not o.IsDead then
		if o.OnHit then
			o:OnHit({ Attack = self.RegularAttack, Level = self.Owner.Skills.Attack:CurrentLevel() })
			o:OnHit({ Attack = self.HolyAttack, Level = self.Owner.Skills.Magic:CurrentLevel() })
			
			Messenger:Add(self.Owner.Name .. " crushed " .. o.Name .. " wtih the power of Sadness!")
			
			if self.Owner.OnSetTarget then
				if o.Skills and o.Skills.HP and o.Skills.HP:CurrentLevel() < 1 then
					self.Owner:OnSetTarget({})
				elseif o.Skills and o.Skills.HP then
					self.Owner:OnSetTarget({ Target = o })
				end
			end
		else
			Messenger:Add(self.Owner.Name .. " should know better!")
		end
	end
	
	self.Effect:Play(255, 128, 1000, false)
end

function CryingMace:Update()
	if self.IsOwned then
		self.Location = self.Owner.Location
	end
end

function CryingMace:Draw(buffer, camera)
	if not self.IsOwned then
		GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(175, 175, 175), Graphics.MakeColor(255, 255, 255), "CM")
	end
end
