DeathParty = {}

function DeathParty:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.First
	
	self.AlwaysDraw = true
	self.CanMove = false
	self.IsInvincible = true
	self.IsDead = false
	self.IsSolid = false
	self.HasSpawned = false
		
	self.Name = "Mr. Death"
	
	dofile(Game.AbsolutePath .. "Content/Particles/BlackExplosion.lua")
	
	self.DeathPack = Particle.Utilities.CreatePack(250, 0, 0, Particle.Particles.BlackExplosion)
	self.Death = {}
end

function DeathParty:OnDeathSpawn(arg)
	local parg =
	{
		TileX = arg.X,
		TileY = arg.Y,
		TileWidth = self.Object.Stage.TileWidth,
		TileHeight = self.Object.Stage.TileHeight
	}
	
	for i=1, 50 do
		local free = Particle.Utilities.FreeSpot(self.Death)
		
		if free == nil and #self.Death < self.DeathPack.Max then
			table.insert(self.Death, Particle.Create(self.DeathPack.Gravity, self.DeathPack.VTable, nil, parg))
		else
			Particle.Create(self.DeathPack.Gravity, self.DeathPack.VTable, self.Death[free], parg)
		end
	end
end

function DeathParty:Update(arg)
	Particle.Utilities.Update(self.DeathPack, self.Death, nil, -1)
end

function DeathParty:Draw(buffer, camera)
	Particle.Utilities.Draw(self.Death, buffer, { Camera = camera })
end
