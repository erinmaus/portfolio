PixPac = {}

function PixPac:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Normal
	
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = false
	self.IsDead = false
	self.IsSolid = true
	self.HasSpawned = false
	
	self.Armor = Armor.Create()
	self.Armor.Stab = 1.3
	self.Armor.Crush = 0.75
	self.Armor.Slash = 1.2
	self.Armor.Fire = 0.5
	self.Armor.Astral = 0.001
	
	self.Skills =
	{
		HP = Skill.Create(),
		Attack = Skill.Create(),
		Defence = Skill.Create()
	}
	
	self.Skills.HP.Xp = self.Skills.HP:XpForLevel(math.random(21, 22))
	self.Skills.Attack.Xp = self.Skills.Attack:XpForLevel(4)
	self.Skills.Defence.Xp = self.Skills.Defence:XpForLevel(9)
	
	self.Positions =
	{
		[Direction.Up] = Point.Create(0, -1),
		[Direction.Down] = Point.Create(0, 1),
		[Direction.Left] = Point.Create(-1, 0),
		[Direction.Right] = Point.Create(1, 0)
	}
	
	self.Direction = Direction.Up
	
	self.HasSeenPlayer = false
	
	self.PathFinder = AStar.Create(self.Object.Stage.Map, self.Object.Objector, 10, 14)
	self.MoveTimer = Timer.Create(0.5, function()
		local p = self.Object.Objector:Get("D132")
		
		if p and not Rectangle.Create(p.Location.X - 1, p.Location.Y - 1, p.Width + 2, p.Height + 2):Collision(Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)) 
			and self.HasSeenPlayer then
			self.PathFinder:Update(self.Location.X, self.Location.Y, p.Location.X, p.Location.Y)
			self.Location = self.PathFinder.Target
		end
	end)
	
	self.AttackTimer = Timer.Create(1.0, function()
		local p = self.Object.Objector:Get("D132")
		
		if p then
			for key, value in pairs(self.Positions) do
				if p.Location == self.Location + value then
					self:OnAttack({ Plus = value })
				end
			end
		end
	end)
	
	self.Attack = { Type = "Crush", Power = 20 }
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	self.Name = "Pix Pac"
end

function PixPac:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.HasSpawned = true
end

function PixPac:OnAttack(arg)
	local objs = self.Object.Objector:GetObjectsAtXY(arg.Plus + self.Location)
	local o
	
	for key, value in pairs(objs) do
		if value.OnHit then
			o = value
			break
		end
	end
	
	if not o then
		o = self.Object.Objector:GetObjectAtXY(arg.Plus + self.Location)
	end
	
	if o and not o.IsDead then
		Messenger:Add(self.Name .. " munched on " .. o.Name .. "'s head! Ouch!")
		
		if o.OnHit then
			o:OnHit({ Attack = self.Attack, Level = self.Skills.Attack:CurrentLevel() })
		else
			Messenger:Add("...but that must be hard, because " .. o.Name .. " has no head.")
		end
	else
		Messenger:Add(self.Name .. " is hungry...")
	end
end

function PixPac:OnHit(arg)
	self.Skills.HP.AdditionalXp = self.Skills.HP.AdditionalXp - self.Armor:CalculateDamage(arg.Attack, arg.Level, self.Skills.Defence:CurrentLevel())
	
	if self.Skills.HP:CurrentLevel() < 1 then
		self.IsDead = true
	end
end

function PixPac:Update()
	if self.Object.Stage.Camera:Collision(Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)) then
		self.HasSeenPlayer = true
	end
	
	if self.HasSeenPlayer then
		self.MoveTimer:Update()
	end
	
	self.AttackTimer:Update()
	
	if self.IsDead then
		self.Object.Objector:Get("DeathParty"):OnDeathSpawn({ X = self.Location.X, Y = self.Location.Y })
		Messenger:Add("Piiiiiiixel paaaaaaac-maaaa...")
		
		GameObject.Spawning.Spawn(self.Object.Objector, "Stairs", self.Location.X, self.Location.Y)
		
		self.Object:Remove()
	end
end

function PixPac:Draw(buffer, camera)
	GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(150, 150, 0), Graphics.MakeColor(255, 255, 0), "Px")
end
