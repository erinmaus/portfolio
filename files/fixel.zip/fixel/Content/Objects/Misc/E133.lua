E133 = {}

function E133:Initialize(obj)
	self.Location = Point.Create(0, 0)
	
	self.IsSolid = true
	self.Name = "Eevee"
	
	self.Object = obj
	
	self.PathFinder = AStar.Create(self.Object.Stage.Map, self.Object.Objector, 10, 14)
	self.MoveTimer = Timer.Create(0.4, function()
		local p = self.Object.Objector:Get("D132")
		
		if p then
			self.PathFinder:Update(self.Location.X, self.Location.Y, p.Location.X, p.Location.Y)
			self.Location = self.PathFinder.Target
		end
	end)
	self.MessageTimer = Timer.Create(2.5, function()
		local player = self.Object.Objector:Get("D132")
		
		if player then			
			local rect = Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)
			
			if math.random() < .4 then
				if rect:Inside(self.Object.Stage.Camera) then
					local messages =
					{
						"I'm coming to get you!",
						"Fear for your life!",
						"Rrraaarrrggghhh!",
						"Meow."
					}
					
					Messenger:Add(messages[math.random(#messages)])
				else
					local messages =
					{
						"...I'm coming...",
						"*Puff, puff*...  Stop running!",
						"Darn you!",
						"Gaaaaah!"
					}
					
					Messenger:Add(messages[math.random(#messages)])
				end
			end
		end
	end)
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	self.Width = 1
	self.Height = 1
end

function E133:OnSpawn(arg)
	self.Location.X = arg.X
	self.Location.Y = arg.Y
end

function E133:Update()
	local p = self.Object.Objector:Get("D132")
	
	if p then
		local ra = Rectangle.Create(p.Location.X - 1, p.Location.Y - 1, p.Width + 2, p.Height + 2)
		local rb = Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)
		
		if not ra:Collision(rb) then
			self.MoveTimer:Update()
		else
			self.MoveTimer:Restart()
		end
	end
	
	self.MessageTimer:Update()
end

function E133:Draw(buffer, camera)
	buffer:DrawPrimitive(Rectangle.Create((self.Location.X - camera.X) * self.Object.Stage.TileWidth, 
		(self.Location.Y - camera.Y) * self.Object.Stage.TileHeight, 31, 31), PrimitiveMode.Filled, 
		Graphics.MakeColor(150, 75, 0))
	buffer:DrawPrimitive(Rectangle.Create((self.Location.X - camera.X) * self.Object.Stage.TileWidth, 
		(self.Location.Y - camera.Y) * self.Object.Stage.TileHeight, 31, 31), PrimitiveMode.Lined, 
		Graphics.MakeColor(175, 100, 0))
	self.Font:Draw(buffer, FontDrawType.Left, (self.Location.X - camera.X) * self.Object.Stage.TileWidth, 
		(self.Location.Y - camera.Y) * self.Object.Stage.TileHeight, Graphics.MakeColor(255, 255, 255),
		"E")
end

