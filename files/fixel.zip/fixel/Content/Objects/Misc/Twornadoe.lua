Twornadoe = {}

function Twornadoe:Initialize(obj)
	self.Object = obj
	
	self.Width = 1
	self.Height = 1
	
	self.DrawOrder = DrawOrder.Normal
	
	self.AlwaysDraw = false
	self.CanMove = false
	self.IsInvincible = false
	self.IsDead = false
	self.IsSolid = true
	self.HasSpawned = false
	
	self.Spells = Inventory.Create()
	
	self.Spells:Push(self.Object.Objector:Add("Tornado")):OnSetOwner({ Owner = self })
	
	self.Name = "Twornadoe"
	
	self.Armor = Armor.Create()
	self.Armor.Stab = 0.95
	self.Armor.Crush = 0.85
	self.Armor.Slash = 0.75
	self.Armor.Fire = 0.65
	self.Armor.Astral = 2.0
	
	self.Skills =
	{
		HP = Skill.Create(),
		Attack = Skill.Create(),
		Magic = Skill.Create(),
		Defence = Skill.Create()
	}
	
	self.Skills.HP.Xp = self.Skills.HP:XpForLevel(math.random(14, 15))
	self.Skills.Attack.Xp = self.Skills.Attack:XpForLevel(5)
	self.Skills.Magic.Xp = self.Skills.Magic:XpForLevel(4)
	self.Skills.Defence.Xp = self.Skills.Defence:XpForLevel(4)
	
	self.Positions =
	{
		[Direction.Up] = Point.Create(0, -1),
		[Direction.Down] = Point.Create(0, 1),
		[Direction.Left] = Point.Create(-1, 0),
		[Direction.Right] = Point.Create(1, 0)
	}
	
	self.Direction = Direction.Up
	
	self.PathFinder = AStar.Create(self.Object.Stage.Map, self.Object.Objector, 10, 16)
	self.MoveTimer = Timer.Create(0.2, function()
		local p = self.Object.Objector:Get("D132")
		
		if p and not Rectangle.Create(p.Location.X - 1, p.Location.Y - 1, p.Width + 2, p.Height + 2):Collision(Rectangle.Create(self.Location.X, self.Location.Y, self.Width, self.Height)) then
			self.PathFinder:Update(self.Location.X, self.Location.Y, p.Location.X, p.Location.Y)
			self.Location = self.PathFinder.Target
		end
	end)
	
	self.AttackTimer = Timer.Create(0.5, function()
		local p = self.Object.Objector:Get("D132")
		
		if p then
			local dif = Point.Create(AStar.Utilities.ManhattanDistance(p.Location.X, p.Location.Y, self.Location.X, self.Location.Y))
			
			if dif <= Point.Create(1, 1) then
				for key, value in pairs(self.Positions) do
					if p.Location == self.Location + value then
						self:OnAttack({ Plus = value })
					end
				end
			else
				for key, value in pairs(self.Positions) do
					for i = 1, 4 do
						local loc = self.Location + (value * Point.Create(i, i))
						
						if p.Location == loc then
							self.Spells:CurrentItem():OnCast({ TileX = loc.X, TileY = loc.Y, TileWidth = self.Object.Stage.TileWidth,
								TileHeight = self.Object.Stage.TileHeight, Direction = key })
						end
					end
				end
			end
		end
	end)
	
	self.Attack = { Type = "Slash", Power = 15 }
	
	self.Font = Font.Create(Game.AbsolutePath .. "Content/Fonts/Font-large.pcx")
	
	self.Furniture =
	{
		"Table",
		"Chair",
		"Cabinet",
		"Desk",
		"Sofa"
	}
	
	self.DropBook = true
	
	dofile(Game.AbsolutePath .. "Content/SoundEffects/Crush.lua")
	self.Effect = MusicBuilder.CreateFromTable(CrushFx)
end

function Twornadoe:OnSpawn(arg)
	self.Location = Point.Create(arg.X, arg.Y)
	self.HasSpawned = true
end

function Twornadoe:OnAttack(arg)
	local objs = self.Object.Objector:GetObjectsAtXY(arg.Plus + self.Location)
	local o
	
	for key, value in pairs(objs) do
		if value.OnHit then
			o = value
			break
		end
	end
	
	if not o then
		o = self.Object.Objector:GetObjectAtXY(arg.Plus + self.Location)
	end
	
	if o and not o.IsDead then
		if o.OnHit then
			Messenger:Add("The " .. self.Name .. " crushed " .. o.Name .. " with a " .. self.Furniture[math.random(#self.Furniture)] .. "!")
			
			o:OnHit({ Attack = self.Attack, Level = self.Skills.Attack:CurrentLevel() })
		else
			Messenger:Add("The " .. self.Name .. " has bad eyesight...")
		end
	end
	
	self.Effect:Play(255, 128, 1000, false)
end

function Twornadoe:OnHit(arg)
	self.Skills.HP.AdditionalXp = self.Skills.HP.AdditionalXp - self.Armor:CalculateDamage(arg.Attack, arg.Level, self.Skills.Defence:CurrentLevel())
	
	if self.Skills.HP:CurrentLevel() < 1 then
		self.IsDead = true
	end
end

function Twornadoe:Update()
	self.MoveTimer:Update()
	self.AttackTimer:Update()
	
	if self.IsDead then
		self.Object.Objector:Get("DeathParty"):OnDeathSpawn({ X = self.Location.X, Y = self.Location.Y })
		Messenger:Add("*wind blowing*")
		
		for _, va in pairs(self.Spells.Items) do
			for _, vb in pairs(va) do
				vb.Object:Remove()
			end
		end
		
		if self.DropBook then
			GameObject.Spawning.Spawn(self.Object.Objector, "TBook", self.Location.X, self.Location.Y)
			Messenger:Add("...on top of the windi-ness, the Twornadoe dropped a book!")
		end
		
		self.Object:Remove()
	end
end

function Twornadoe:Draw(buffer, camera)
	GameObject.Drawing.DrawRectangle(buffer, self, camera, Graphics.MakeColor(125, 125, 125), Graphics.MakeColor(25, 25, 25), "Tw")
end
