SummonFx = {}

SummonFx.Music =
{
	500, 200, 700, 400, 0, 0, 0, 0, 0, 0, 0, 0
}

SummonFx.Frequency = MusicBuilder.StandardFrequency
SummonFx.Time = 1
SummonFx.Length = SummonFx.Time * SummonFx.Frequency
SummonFx.Start = 148
SummonFx.Ending = 107
SummonFx.Frequencies = MusicBuilder.Frequencies[4]
SummonFx.Type = SampleWave.Triangle
