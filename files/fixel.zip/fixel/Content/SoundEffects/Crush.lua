CrushFx = {}

CrushFx.Music =
{
	200, 150, 230, 0, 0, 0, 0, 0, 0, 0, 0, 0
}

CrushFx.Frequency = MusicBuilder.StandardFrequency
CrushFx.Time = 1
CrushFx.Length = CrushFx.Time * CrushFx.Frequency
CrushFx.Start = 128
CrushFx.Ending = 127
CrushFx.Frequencies = MusicBuilder.Frequencies[4]
CrushFx.Type = SampleWave.Square
