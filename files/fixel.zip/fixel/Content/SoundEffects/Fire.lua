FireFx = {}

FireFx.Music =
{
	10, 30, 20, 40, 70, 10, 0, 0, 0, 0, 0, 0
}

FireFx.Frequency = MusicBuilder.StandardFrequency
FireFx.Time = 1
FireFx.Length = FireFx.Time * FireFx.Frequency
FireFx.Start = 148
FireFx.Ending = 107
FireFx.Frequencies = MusicBuilder.Frequencies[4]
FireFx.Type = SampleWave.Triangle
