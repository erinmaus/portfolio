WindFx = {}

WindFx.Music =
{
	50, 60, 70, 80, 90, 100, 110, 0, 0, 0, 0, 0
}

WindFx.Frequency = MusicBuilder.StandardFrequency
WindFx.Time = 1
WindFx.Length = WindFx.Time * WindFx.Frequency
WindFx.Start = 148
WindFx.Ending = 107
WindFx.Frequencies = MusicBuilder.Frequencies[4]
WindFx.Type = SampleWave.Triangle
