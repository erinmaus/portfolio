ClickFx = {}

ClickFx.Music =
{
	1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
}

ClickFx.Frequency = MusicBuilder.StandardFrequency
ClickFx.Time = 1
ClickFx.Length = ClickFx.Time * ClickFx.Frequency
ClickFx.Start = 128
ClickFx.Ending = 127
ClickFx.Frequencies = MusicBuilder.Frequencies[4]
ClickFx.Type = SampleWave.Sine
