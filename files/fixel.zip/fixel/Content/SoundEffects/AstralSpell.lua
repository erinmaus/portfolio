AstralSpellFx = {}

AstralSpellFx.Music =
{
	40, 50, 60, 70, 80, 90, 110, 130, 150, 170, 190, 210, 230,
	0, 0, 0, 0, 0, 0, 0
}

AstralSpellFx.Frequency = MusicBuilder.StandardFrequency
AstralSpellFx.Time = 1
AstralSpellFx.Length = AstralSpellFx.Time * AstralSpellFx.Frequency
AstralSpellFx.Start = 128
AstralSpellFx.Ending = 127
AstralSpellFx.Frequencies = MusicBuilder.Frequencies[4]
AstralSpellFx.Type = SampleWave.Sine
