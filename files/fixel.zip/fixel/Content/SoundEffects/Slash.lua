SlashFx = {}

SlashFx.Music =
{
	500, 250, 500, 0, 0, 0, 0, 0, 0, 0, 0, 0
}

SlashFx.Frequency = MusicBuilder.StandardFrequency
SlashFx.Time = 1
SlashFx.Length = SlashFx.Time * SlashFx.Frequency
SlashFx.Start = 128
SlashFx.Ending = 127
SlashFx.Frequencies = MusicBuilder.Frequencies[4]
SlashFx.Type = SampleWave.Square
