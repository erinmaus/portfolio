Particle.Particles.FireExplosion =
{
	Initialize = function(self, arg)
		self.X = 0
		self.Y = 0
		
		self.TileX = arg.TileX
		self.TileY = arg.TileY
		self.TileWidth = arg.TileWidth
		self.TileHeight = arg.TileHeight
		self.Color = math.random(150, 255)
		
		if math.random() < 0.5 then
			self.YSpeed = -10 + math.random() * -30
		else
			self.YSpeed = 10 + math.random() * 30
		end
		
		if math.random() < 0.5 then
			self.XSpeed = -10 + math.random() * -30
		else
			self.XSpeed = 10 + math.random() * 30
		end
		
		self.Life = 10 + math.random() * 10
		
		self.YSpeedDampening = 0.2
		self.XSpeedDampening = 0.2
	end,
	
	Update = function(self)
		if not self.Dead then
			self.Life = self.Life - 0.5
			
			if self.Life < 0 then
				self.Life = 0
				self.Dead = true
			end
		end
	end,
	
	Draw = function(self, buffer, arg)
		local ec = Rectangle.Create(arg.Camera.X * self.TileWidth, arg.Camera.Y * self.TileHeight, arg.Camera.Width * self.TileWidth, arg.Camera.Height * self.TileHeight)
		local sr = Rectangle.Create(self.X + (self.TileX * self.TileWidth + self.TileWidth / 2), self.Y + (self.TileY * self.TileHeight + self.TileHeight / 2), 4, 4)
		
		if not self.Dead and ec:Collision(sr) then
			Graphics.SetAdditiveBlender((self.Life * 500) / 255)
			
			buffer:DrawPrimitive(Rectangle.Create(self.X + (self.TileX * self.TileWidth + self.TileWidth / 2) - arg.Camera.X * self.TileWidth, 
				self.Y + (self.TileY * self.TileHeight + self.TileHeight / 2) - arg.Camera.Y * self.TileHeight, 4, 4), PrimitiveMode.Filled, 
				Graphics.MakeColor(self.Color, 0, 0))
			
			Graphics.SetAdditiveBlender(255)
			Graphics.SetSolidMode()
		end
	end
}
