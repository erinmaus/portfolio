Armor =
{
	Create = function()
		local a = {}
		
		a.None = 1
		a.Crush = 1
		a.Stab = 1
		a.Slash = 1
		a.Range = 1
		a.Magic = 1
		a.Astral = 1
		a.Holy = -1 -- For healing
		a.Electric = 1
		a.Fire = 1
		a.Ice = 1
		
		-- Expects the attack's power to be greater than zero and less than or equal to one
		a.CalculateDamage = function(self, attack, level, defence)
			return (((self[attack.Type] * (attack.Power + level * 0.25))*4)^2) / (defence * 0.3)
		end
		
		return a
	end
}
