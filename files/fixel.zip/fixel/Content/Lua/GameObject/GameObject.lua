GameObject = 
{
	Spawning =
	{
		Spawn = function(objector, name, x, y)
			local o = objector:Add(name)
			
			if o.OnSpawn then
				o:OnSpawn({ X = x, Y = y })
				o.Object:Synchronize() -- So Objector knows its position
			end
			
			return o
		end
	},
	
	Collision =
	{
		IsSpotFree = function(map, objector, x, y)
			local xy = Point.Create(x, y)
						
			if not map:GetTileAtXY(xy).Impassable then
				local objs = objector:GetObjectsAtXY(xy)
				
				for _, value in pairs(objs) do
					if value.IsSolid then
						return false
					end
				end
				
				return true
			end
			
			return false
		end
	},
	
	Input =
	{
		MoveIt = function(cont, map, obj, cur, move)
			if GameObject.Collision.IsSpotFree(map, obj, move[cont].X + cur.X, move[cont].Y + cur.Y) then
				return Game.Controls[cont]:State(Game.Input)
			end
			
			return ButtonState.Max
		end
	},
	
	Drawing =
	{
		DrawRectangle = function(buffer, obj, camera, fg, bg, text)
			buffer:DrawPrimitive(Rectangle.Create((obj.Location.X - camera.X) * obj.Object.Stage.TileWidth, 
				(obj.Location.Y - camera.Y) * obj.Object.Stage.TileHeight, obj.Object.Stage.TileWidth * obj.Width - 1, obj.Object.Stage.TileHeight * obj.Height - 1), 
				PrimitiveMode.Filled, bg)
			buffer:DrawPrimitive(Rectangle.Create((obj.Location.X - camera.X) * obj.Object.Stage.TileWidth, 
				(obj.Location.Y - camera.Y) * obj.Object.Stage.TileHeight, obj.Object.Stage.TileWidth * obj.Width - 1, obj.Object.Stage.TileHeight * obj.Height - 1),
				PrimitiveMode.Lined, fg)
			obj.Font:Draw(buffer, FontDrawType.Left, (obj.Location.X - camera.X) * obj.Object.Stage.TileWidth, 
				(obj.Location.Y - camera.Y) * obj.Object.Stage.TileHeight, fg, text)
		end
	}
}
