MapBuilder =
{
	Utilities =
	{
		Tile = function(loc, map, tile)
			local t = map:GetTileAtXY(loc)
			
			for key, value in pairs(tile) do
				t[key] = value
			end
		end,
		
		Rectangle = function(rect, map, tile)
			if rect.X + rect.Width >= map.Width or rect.Y + rect.Height >= map.Height then
				error("rect.X/rect.Y > map.Width/map.Height")
			end
			
			-- Top
			for i=0, rect.Width do
				local t = map:GetTileAtXY(Point.Create(i + rect.X, rect.Y))
				
				for key, value in pairs(tile) do
					t[key] = value
				end
			end
			
			-- Bottom
			for i=0, rect.Width do
				local t = map:GetTileAtXY(Point.Create(i + rect.X, rect.Y + rect.Height))
				
				for key, value in pairs(tile) do
					t[key] = value
				end
			end
			
			-- Left
			for i=0, rect.Height do
				local t = map:GetTileAtXY(Point.Create(rect.X, i + rect.Y))
				
				for key, value in pairs(tile) do
					t[key] = value
				end
			end
			
			-- Right
			for i=0, rect.Height do
				local t = map:GetTileAtXY(Point.Create(rect.X + rect.Width, i + rect.Y))
				
				for key, value in pairs(tile) do
					t[key] = value
				end
			end
		end,
		
		RectangleFill = function(rect, map, tile)
			if rect.X + rect.Width >= map.Width or rect.Y + rect.Height >= map.Height then
				error("rect.X/rect.Y > map.Width/map.Height")
			end
			
			for x=0, rect.Width do
				for y=0, rect.Height do
					local t = map:GetTileAtXY(Point.Create(x + rect.X, y + rect.Y))
					
					for key, value in pairs(tile) do
						t[key] = value
					end
				end
			end
		end
	}
}
