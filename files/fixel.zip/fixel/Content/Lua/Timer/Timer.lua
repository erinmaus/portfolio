Timer =
{
	Create = function(interval, callback)
		local t = {}
		
		t.Interval = interval
		t.Current = 0		
		t.Callback = callback
		t.Stopped = false
		
		t.Update = function(self, upd)			
			if not self.Stopped then
				self.Current = self.Current + (upd or Game.ElapsedTime)
				
				if self.Current >= self.Interval then
					self.Callback()
					self.Current = 0
				end
			end
		end
		
		t.Stop = function(self)
			self.Stopped = true
		end
		
		t.Start = function(self)
			self.Stopped = false
		end
		
		t.Restart = function(self)
			self.Current = 0
		end
		
		return t
	end
}
