-- This contains utilities.  It should be called *after* `Initialize.lua'.

Utilities =
{
	-- This copies the table.  `e' should contain exceptions, stored in this format:
	--	e[table to be skipped] = true
	-- This function is required.
	CopyTable = function(t, e)
		local c = {}
		
		for key, value in pairs(t) do
			if type(value) == "table" and e[value] ~= true then
				e[value] = true
				
				c[key] = Utilities.CopyTable(value, e)
			else
				c[key] = value
			end
		end
		
		return c
	end,
	
	-- Since utilities is in the global environment--that is, it is not sandboxed--we can just use `_G' directly.
	-- This function is required.
	DuplicateGlobalTable = function()
		local g = Utilities.CopyTable(_G, { [_G] = true, [Fixel] = true, [Core] = true, [Messenger] = true, [Concerto] = true })
		
		g._G = g
		
		return g
	end
}
