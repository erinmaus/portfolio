-- This handy-dandy Lua script is for initializing everything needed, script-wise.
Fixel = {}

Core =
{
	RegisterScreens = function()
		Game.Screeny:Register("Title", Game.AbsolutePath .. "Content/Screens/Title.lua")
		Game.Screeny:Register("MainMenu", Game.AbsolutePath .. "Content/Screens/MainMenu.lua")
		Game.Screeny:Register("Options", Game.AbsolutePath .. "Content/Screens/Options.lua")
		Game.Screeny:Register("Demo", Game.AbsolutePath .. "Content/Screens/Demo.lua")
		Game.Screeny:Register("EditMenu", Game.AbsolutePath .. "Content/Screens/EditMenu.lua")
	end,
	
	RegisterObjects = function()
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/D132.lua", "D132")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/E133.lua", "E133")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/Tree.lua", "Tree")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/EvilMinion.lua", "EvilMinion")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/PunyDagger.lua", "PunyDagger")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/AstralMaelstrom.lua", "AstralMaelstrom")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/PolarBear.lua", "PolarBear")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/SuperPotion.lua", "SuperPotion")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/Eggbert.lua", "Eggbert")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/CryingMace.lua", "CryingMace")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/DeathParty.lua", "DeathParty")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/HollowedSword.lua", "HollowedSword")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/QuadPotion.lua", "QuadPotion")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/DazyBlazy.lua", "DazyBlazy")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/NinjaCrazyDaisy.lua", "NinjaCrazyDaisy")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/PixPac.lua", "PixPac")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/Stairs.lua", "Stairs")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/Tornado.lua", "Tornado")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/TBook.lua", "TBook")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/AstralDagger.lua", "AstralDagger")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/Twornadoe.lua", "Twornadoe")
		Game:RegisterObject(Game.AbsolutePath .. "Content/Objects/Misc/AMUEggbert.lua", "AMUEggbert")
	end
}

function Core:Initialize()
	-- Anything important in initialization scripts *should* be done here.
	dofile(Game.AbsolutePath .. "Content/Lua/Game/Utilities.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/Game/Debug.lua")
	
	-- Anything required in the global namespace should be done here
	dofile(Game.AbsolutePath .. "Content/Lua/Particle/Particle.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/Timer/Timer.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/MapBuilder/MapBuilder.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/GameObject/GameObject.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/AStar/AStar.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/MessageLog/MessageLog.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/Types/Types.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/Armor/Armor.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/Skills/Skills.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/Inventory/Inventory.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/MusicBuilder/MusicBuilder.lua")
	dofile(Game.AbsolutePath .. "Content/Lua/MusicManager/MusicManager.lua")
	
	dofile = function(filename)
		chunk = loadfile(filename)
		
		assert(chunk, "chunk is invalid")
		
		setfenv(chunk, getfenv(2))
		
		return chunk()
	end
	
	self:RegisterScreens() -- Register all the screens
	self:RegisterObjects() -- Register all the objects
	
	-- Various global, scripted managers
	Messenger = MessageLog.Create(10, 60, 255, Game.Font, Graphics.MakeColor(255, 255, 255), 2, Game.ScreenHeight - Game.Font.Height, 2)
	Concerto = MusicManager.Create()
	
	self.Cursor = Bitmap.Create(Game.AbsolutePath .. "Content/Graphics/Cursor.bmp")
	
	Game.Screeny:Add("Title")
	
	local db = DialogBuilder.Create()
	
	-- The console window
	local window = Dialog.Create(DialogType.Box)
	window.X = 0
	window.Y = 0
	window.Width = 320
	window.Height = 240
	
	-- The label
	local title = Dialog.Create(DialogType.CenterLabel)
	title.X = 160
	title.Y = 2
	title.Text = "Fixel Console"
	
	-- The close button
	local close = Dialog.Create(DialogType.Button)
	close.X = 0
	close.Y = 0
	close.Width = 32
	close.Height = 32
	close.Text = "&X"
	close.Key = Key.X
	close.OnClick = function(dialog)
		return DialogReturn.Close
	end
	
	-- The grant-wish button
	local doIt = Dialog.Create(DialogType.Button)
	doIt.X = 289
	doIt.Y = 0
	doIt.Width = 32
	doIt.Height = 32
	doIt.Text = ">"
	doIt.Key = Key.Enter
	doIt.OnClick = function(dialog)
		self.ConsoleDialog[4].Text = self.ConsoleDialog[4].Text .. "> " .. self.ConsoleDialog[5].Text .. "\n"
		
		local oldPrint = print
		
		print = function(...)
			for key, value in ipairs(arg) do
				self.ConsoleDialog[4].Text = self.ConsoleDialog[4].Text .. "[" .. tostring(key) .. "]: " .. tostring(value) .. "\n"
			end
		end
		
		clear = function()
			self.ConsoleDialog[4].Text = tostring(Game) .. "\n"
		end
		
		local chunk = loadstring(self.ConsoleDialog[5].Text, "Console")
		
		if chunk == nil then
			print("invalid chunk data")		
		else
			local ret, error = pcall(chunk)
		
			if type(ret) == "boolean" and ret == false then
				print(ret, error)
			end
		end
		
		print = oldPrint
		clear = nil
		
		return DialogReturn.Ok
	end
	
	-- The textbox
	local textbox = Dialog.Create(DialogType.Textbox)
	textbox.X = 2
	textbox.Y = 34
	textbox.Width = 316
	textbox.Height = 202 - Game.Font.Height
	textbox.Text = tostring(Game) .. "\n"
	
	-- The enter-your-stinkin'-script-command box
	local input = Dialog.Create(DialogType.EditBox)
	input.X = 2
	input.Y = 238 - Game.Font.Height
	input.Width = 316
	input.Height = Game.Font.Height
	input.TextLength = 1320 -- A magic number
	
	db:Add(window)
	db:Add(title)
	db:Add(close)
	db:Add(doIt)
	db:Add(textbox)
	db:Add(input)
	
	self.ConsoleDialog = db:Compile()
	
	self.ConsoleDialog:SetColors(Graphics.MakeColor(255, 255, 255), Graphics.MakeColor(0, 0, 0))
	self.ConsoleDialog:SetFont(Game.Font, false)
	self.ConsoleDialog:Center()
	self.ConsoleOpen = false
	
	collectgarbage("setpause", 0)
end

function Core:Update()
	if self.ConsoleOpen and not self.ConsoleDialog:Update() then
		self.ConsoleOpen = false
		Game:Continue()
	end
	
	if Game.Input:KeyState(Key.Tilde) == ButtonState.JustPressed then	
		self.ConsoleOpen = true
		Game:Pause()
	end
	
	if not Game.IsPaused then
		Messenger:Update(Game.ElapsedTime)
	end
end

function Core:Draw(bitmap)
	if self.ConsoleOpen then
		self.ConsoleDialog.Buffer = bitmap
		self.ConsoleDialog:Redraw()
	end
	
	if Game.ShowMouse then
		self.Cursor:Draw(bitmap, Game.Input.MouseXY)
	end
	
	Messenger:Draw(bitmap)
end
