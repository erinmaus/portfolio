-- Debugging stuff
Debug =
{
	LogTableToFile = function(t, i, e)
		for key, value in pairs(t) do
			Game.Loggy:Write("Debug", string.rep("\t", i) .. tostring(key) .. ": " .. tostring(value) .. "\n")
			
			if type(value) == "table" and e[value] ~= true then
				e[value] = true
				
				Debug.LogTableToFile(value, i + 1, e)
			end
		end
	end,
	
	FindReferencedTable = function(t, n)
		for _, value in ipairs(t) do
			if value[n] ~= nil then
				return value[n]
			end
		end
		
		return nil
	end
}
