Inventory =
{
	Create = function()
		local i = {}
		
		i.Items = {}
		
		i.Push = function(self, item)
			for _, value in pairs(self.Items) do
				if value[1].Object.Name == item.Object.Name then
					table.insert(value, item)
					
					return item
				end
			end
			
			table.insert(self.Items, { item })
			
			return item
		end
		
		i.Pop = function(self)
			local r = table.remove(self.Items[1], 1)
			
			if #self.Items[1] == 0 then
				table.remove(self.Items, 1)
			end
			
			return r
		end
		
		i.PopStack = function(self)
			return table.remove(self.Items, 1)
		end
		
		i.CycleDown = function(self)
			table.insert(self.Items, self:PopStack())
		end
		
		i.CycleUp = function(self)
			table.insert(self.Items, 1, table.remove(self.Items, table.maxn(self.Items)))
		end
		
		i.Current = function(self)
			return self.Items[1]
		end
		
		i.CurrentItem = function(self)
			return self.Items[1][1]
		end
		
		i.BackItem = function(self)
			return self.Items[table.maxn(self.Items)][1]
		end
		
		i.Back = function(self)
			return self.Items[table.maxn(self.Items)]
		end
		
		return i
	end
}
