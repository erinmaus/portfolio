-- Particle add-on

Particle =
{
	Particles = {},
	
	Utilities =
	{
		FreeSpot = function(t)
			local i = 1
			
			for _, value in pairs(t) do
				if value.Dead then
					return i
				end
				
				i = i + 1
			end
			
			return nil
		end,
		
		AliveTotal = function(t)
			local alive = 0
			
			for _, value in pairs(t) do
				if not value.Dead then
					alive = alive + 1
				end
			end
			
			return alive
		end,
		
		CreatePack = function(max, add, gravity, vtable)
			local p = {}
			
			p.Max = max
			p.AdditionMax = add
			p.Gravity = gravity
			p.VTable = vtable
			
			return p
		end,
		
		Update = function(pack, t, arg, add)
			if Particle.Utilities.AliveTotal(t) < pack.Max and math.random() < (add or 132) then
				for i=1, math.random(1 + pack.AdditionMax) do
					local free = Particle.Utilities.FreeSpot(t)
					
					if free == nil then
						table.insert(t, Particle.Create(pack.Gravity, pack.VTable,  nil, arg))
					else
						Particle.Create(pack.Gravity, pack.VTable, t[free], arg)
					end
				end
			end
			
			for i=1, table.maxn(t) do
				t[i]:Update()
			end
		end,
		
		Draw = function(t, bitmap, arg)
			for i=1, table.maxn(t) do
				t[i]:Draw(bitmap, arg)
			end
		end
	},
	
	Create = function(gravity, vtable, entry, arg)
		local p = entry or {}
		
		p.Gravity = gravity
		p.Floor = floor
		p.YSpeed = 0
		p.XSpeed = 0
		p.Dead = false
		p.VTable = vtable
		
		p.VTable.Initialize(p, arg)
		
		p.Update = Particle.Update
		p.Draw = Particle.Draw
		
		return p
	end,
	
	Update = function(self)
		if not self.Dead then
			self.YSpeed = self.YSpeed + self.Gravity
			
			self.Y = self.Y + self.YSpeed * (self.YSpeedDampening or 1)
			self.X = self.X + self.XSpeed * (self.XSpeedDampening or 1)
			
			self.VTable.Update(self)
		end
	end,
	
	Draw = function(self, bitmap, arg)
		if not self.Dead then
			self.VTable.Draw(self, bitmap, arg)
		end
	end
}
