AStar =
{
	Utilities =
	{
		ManhattanDistance = function(tx, ty, cx, cy)
			return math.abs(tx - cx), math.abs(ty - cy)
		end
	},
	
	Create = function(map, objector, straight, diagonal)
		local t = {}
		local md = AStar.Utilities.ManhattanDistance
		
		t.Map = map
		t.Objector = objector
		t.StraightCost = straight
		t.DiagonalCost = diagonal
		t.PathNames =
		{
			TopLeft = 0, TopMid = 1, TopRight = 2,
			MidLeft = 3, Middle = 4, MidRight = 5,
			BotLeft = 6, BotMid = 7, BotRight = 8
		}
		t.Target = Point.Create(0, 0)
		
		t.Update = function(self, cx, cy, tx, ty)
			local paths = {}
			local x, y = 0, 0
			
			-- Top left
			if GameObject.Collision.IsSpotFree(self.Map, self.Objector, cx - 1, cy - 1) then
				x, y = md(tx, ty, cx - 1, cy - 1)
				
				paths[self.PathNames.TopLeft] = {}
				paths[self.PathNames.TopLeft].Cost = self.DiagonalCost + ((x + y) * 10)
				paths[self.PathNames.TopLeft].XY = Point.Create(cx - 1, cy - 1)
			end
			
			-- Top middle
			if GameObject.Collision.IsSpotFree(self.Map, self.Objector, cx, cy - 1) then
				x, y = md(tx, ty, cx, cy - 1)
				
				paths[self.PathNames.TopMid] = {}
				paths[self.PathNames.TopMid].Cost = self.StraightCost + ((x + y) * 10)
				paths[self.PathNames.TopMid].XY = Point.Create(cx, cy - 1)
			end
			
			-- Top right
			if GameObject.Collision.IsSpotFree(self.Map, self.Objector, cx + 1, cy - 1) then
				x, y = md(tx, ty, cx + 1, cy - 1)
				
				paths[self.PathNames.TopRight] = {}
				paths[self.PathNames.TopRight].Cost = self.DiagonalCost + ((x + y) * 10)
				paths[self.PathNames.TopRight].XY = Point.Create(cx + 1, cy - 1)
			end
			
			-- Middle left
			if GameObject.Collision.IsSpotFree(self.Map, self.Objector, cx - 1, cy) then
				x, y = md(tx, ty, cx - 1, cy)
				
				paths[self.PathNames.MidLeft] = {}
				paths[self.PathNames.MidLeft].Cost = self.StraightCost + ((x + y) * 10)
				paths[self.PathNames.MidLeft].XY = Point.Create(cx - 1, cy)
			end
			
			-- Middle right
			if GameObject.Collision.IsSpotFree(self.Map, self.Objector, cx + 1, cy) then
				x, y = md(tx, ty, cx + 1, cy)
				
				paths[self.PathNames.MidRight] = {}
				paths[self.PathNames.MidRight].Cost = self.StraightCost + ((x + y) * 10)
				paths[self.PathNames.MidRight].XY = Point.Create(cx + 1, cy)
			end
			
			-- Bottom left
			if GameObject.Collision.IsSpotFree(self.Map, self.Objector, cx - 1, cy + 1) then
				x, y = md(tx, ty, cx - 1, cy + 1)
				
				paths[self.PathNames.BotLeft] = {}
				paths[self.PathNames.BotLeft].Cost = self.DiagonalCost + ((x + y) * 10)
				paths[self.PathNames.BotLeft].XY = Point.Create(cx - 1, cy + 1)
			end
						
			-- Bottom middle
			if GameObject.Collision.IsSpotFree(self.Map, self.Objector, cx, cy + 1) then
				x, y = md(tx, ty, cx, cy + 1)
				
				paths[self.PathNames.BotMid] = {}
				paths[self.PathNames.BotMid].Cost = self.StraightCost + ((x + y) * 10)
				paths[self.PathNames.BotMid].XY = Point.Create(cx, cy + 1)
			end
			
			-- Bottom right
			if GameObject.Collision.IsSpotFree(self.Map, self.Objector, cx + 1, cy + 1) then
				x, y = md(tx, ty, cx + 1, cy + 1)
				
				paths[self.PathNames.BotRight] = {}
				paths[self.PathNames.BotRight].Cost = self.DiagonalCost + ((x + y) * 10)
				paths[self.PathNames.BotRight].XY = Point.Create(cx + 1, cy + 1)
			end
			
			local cheapest = -1
			
			for key, value in pairs(paths) do
				if cheapest < 0 then
					cheapest = key
				end
				
				if value.Cost < paths[cheapest].Cost then
					cheapest = key
				end
			end
			
			if cheapest < 0 then
				self.Target = Point.Create(cx, cy)
			else
				self.Target = paths[cheapest].XY
			end
		end
		
		return t
	end
}
