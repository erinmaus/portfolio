MusicManager =
{
	Create = function()
		local c = {}
		
		c.Music = {}
		
		c.Add = function(self, name, song)
			if self.Music[name] ~= nil then
				error("Song is already in the database.")
			end
			
			self.Music[name] = { Song = song, IsPlaying = false }
			
			return song, name
		end
		
		c.Remove = function(self, name)
			if self.Music[name] == nil then
				error("Song doesn't exist.")
			end
			
			self.Music[name].Song:Stop()
			
			local s = self.Music[name]
			
			self.Music[name] = nil
			
			return s.Song
		end
		
		c.Exists = function(self, name)
			return self.Music[name] ~= ni
		end
		
		c.Play = function(self, name, volume, panning, freq)
			if self.Music[name] == nil then
				error("Song doesn't exist.")
			end
			
			--self.Music[name].IsPlaying = true
			--return self.Music[name].Song:Play(volume, panning, freq, true)
			return true
		end
		
		c.Stop = function(self, name)
			--self.Music[name].Song:Stop()
			--self.Music[name].IsPlaying = false
		end
		
		c.Adjust = function(self, name, volume, panning, freq)
			self.Music[name].Song:Adjust(volume, panning, freq, true)
		end
		
		c.IsPlaying = function(self, name)
			if self.Music[name] == nil then
				error("Song doesn't exist.")
			end
			
			return self.Music[name].IsPlaying
		end
		
		c.StopAllExcept = function(self, name)
			for key, value in pairs(self.Music) do
				if key ~= name then
					value.IsPlaying = false
					value.Song:Stop()
				end
			end
		end
		
		c.StopAll = function(self)
			for _, value in pairs(self.Music) do
				value.IsPlaying = false
				value.Song:Stop()
			end
		end
		
		return c
	end
}
