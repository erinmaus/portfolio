MusicBuilder =
{
	Frequencies =
	{
		[4] =
		{
			c = 261.63,
			C = 277.18,
			d = 293.66,
			D = 311.13,
			e = 329.63,
			f = 349.23,
			F = 369.99,
			g = 392.00,
			G = 415.30,
			a = 440.00,
			A = 466.16,
			b = 493.88
		}
	},
	
	StandardFrequency = 11025,
	
	Create = function(music, freq, length, time, ty, s, e, fqs)
		local freqs = fqs or MusicBuilder.Frequencies[4]
		local t = {}
		
		for _, value in ipairs(music) do
			if type(value) == "string" then
				table.insert(t, freqs[value])
			else
				table.insert(t, value)
			end
		end
		
		return Sample.Create(freq, length, time, ty, s or 128, e or 127, t)
	end,
	
	CreateFromTable = function(music)
		return MusicBuilder.Create(music.Music, music.Frequency, music.Length, music.Time, music.Type, music.Start, music.Ending, music.Frequencies)
	end
}
