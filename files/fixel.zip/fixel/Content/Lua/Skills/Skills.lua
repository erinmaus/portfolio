Skill =
{
	Utilities =
	{
		XpForLevel = function(self, level)
			return (level * 1.75)^3
		end,
		
		LevelForXp = function(self, xp)
			return math.ceil((xp^(1/3)) / 1.75)
		end
	},
	
	Create = function(fxp, flvl)
		local s = {}
		
		s.Xp = 0
		s.AdditionalXp = 0
		s.Cap = 99
		
		s.XpForLevel = fxp or Skill.Utilities.XpForLevel
		s.LevelForXp = flvl or Skill.Utilities.LevelForXp
		
		s.Level = function(self)
			return self:LevelForXp(self.Xp)
		end
		
		s.CurrentLevel = function(self)
			if self.Xp + self.AdditionalXp < 0 then
				return self:LevelForXp(0)
			else
				return self:LevelForXp(self.Xp + self.AdditionalXp)
			end
		end
		
		return s
	end
}
