Types =
{
	None = 1,
	Crush = 2,
	Stab = 3,
	Slash = 4,
	Range = 5,
	Magic = 6,
	Astral = 7,
	Holy = 8,
	Electric = 9,
	Fire = 10,
	Ice = 11
}
