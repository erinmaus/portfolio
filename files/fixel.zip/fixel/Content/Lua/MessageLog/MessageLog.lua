MessageLog =
{
	Create = function(max, speed, life, font, color, x, y, padding, sw)
		local c = {} -- Was console at first (to explain why it is shortened to `c')
		
		c.MaxLines = max
		c.Speed = speed or 4
		c.LifePerLine = life
		c.Font = font
		c.Color = color
		c.X = x or 2
		c.Y = y or Game.ScreenHeight
		c.Padding = padding or 2
		c.Lines = {}
		c.Buffer = Bitmap.Create(sw or Game.ScreenWidth, c.Font.Height)
		
		c.Update = function(self, time)
			local toRemove = {}
			
			for _, value in ipairs(self.Lines) do
				value.Alpha = value.Alpha - (time * self.Speed)
				
				if value.Alpha < 0 then
					table.insert(toRemove, value)
				end
			end
			
			for _, va in ipairs(toRemove) do
				for key, vb in ipairs(self.Lines) do
					if rawequal(va, vb) then
						table.remove(self.Lines, key)
					end
				end
			end
		end
		
		c.Draw = function(self, buffer)
			local y = self.Y
			
			for _, value in ipairs(self.Lines) do
				self.Buffer:Clear(Graphics.MakeColor(255, 0, 255))
				
				self.Font:Draw(self.Buffer, FontDrawType.Left, self.X, 0, self.Color, value.Text)
				
				Graphics.SetTranslucentBlender(value.Alpha)
				
				self.Buffer:DrawTrans(buffer, 0, y)
				
				Graphics.SetSolidMode()
				
				y = y - self.Font.Height - self.Padding
			end
		end
		
		c.Add = function(self, string)
			if #self.Lines < self.MaxLines then
				table.insert(self.Lines, 1, { Text = string, Alpha = self.LifePerLine })
			end
		end
		
		return c
	end
}
