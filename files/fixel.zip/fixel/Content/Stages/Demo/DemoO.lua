Demo = {}

function Demo:Initialize(stage)
	local grass =
	{
		Index = 2,
		Floor = true,
		Impassable = false
	}
	
	local stoneWall =
	{
		Index = 1,
		Wall = true,
		Impassable = true
	}
	
	self.Map = Map.Create(25, 25)
	
	MapBuilder.Utilities.Rectangle(Rectangle.Create(0, 0, 24, 24), self.Map, stoneWall)
	MapBuilder.Utilities.RectangleFill(Rectangle.Create(1, 1, 22, 22), self.Map, grass)
	
	self.TileSheet = TileSheet.Create()
	
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(50, 50, 50), Graphics.MakeColor(0, 0, 0)))
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(100, 100, 100), Graphics.MakeColor(120, 120, 120), 1))
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(20, 100, 20), Graphics.MakeColor(20, 120, 20), 2))
	
	self.TileWidth = 32
	self.TileHeight = 32
	
	self.CameraWidth = 640 / self.TileWidth
	self.CameraHeight = 480 / self.TileHeight
	
	self.Stage = stage
	
	self.Stage:Synchronize()
	
	GameObject.Spawning.Spawn(self.Stage.Objector, "D132", 12, 12)
	GameObject.Spawning.Spawn(self.Stage.Objector, "E133", 1, 1)
	
	local leader = GameObject.Spawning.Spawn(self.Stage.Objector, "EvilMinion", 23, 23)
	leader:OnSetTeam({ Team = 1, TeamRank = 2 })
	
	GameObject.Spawning.Spawn(self.Stage.Objector, "DeathParty", 0, 0)
	GameObject.Spawning.Spawn(self.Stage.Objector, "Eggbert", 1, 20)
	GameObject.Spawning.Spawn(self.Stage.Objector, "EvilMinion", 3, 20):OnSetTeam({ Team = 2, TeamRank = 2 })
	
	GameObject.Spawning.Spawn(self.Stage.Objector, "PolarBear", 7, 3)
	GameObject.Spawning.Spawn(self.Stage.Objector, "PolarBear", 23, 2)
	
	for i=0, 50 do
		local p = Point.Create(math.random(0, 24), math.random(0, 24))
		
		if GameObject.Collision.IsSpotFree(self.Map, self.Stage.Objector, p.X, p.Y) then
			GameObject.Spawning.Spawn(self.Stage.Objector, "Tree", p.X, p.Y)
		end
	end
end
