Demo = {}

function Demo:IsValidRoom(x, y, w, h)
	if x < 1 or y < 1 or x + w + 1 >= self.Map.Width or y + h + 1 >= self.Map.Height then
		return false
	end
	
	for i = x - 1, x + w + 1 do -- So there's some space between rooms
		for j = y - 1, y + h + 1 do
			local t = self.Map:GetTileAtXY(Point.Create(i, j))
			
			if t.Wall or t.Floor then
				return false
			end
		end
	end
	
	return true
end

function Demo:WhichRoom(x, y)
	local r = Rectangle.Create(x, y, 1, 1)
	
	-- Each value in `self.Rooms' is really a rectangle, so do a simple collision test
	for _, value in pairs(self.Rooms) do
		if x >= value.X and x <= value.X + value.Width and y >= value.Y and y <= value.Y + value.Height then
			return value
		end
	end
	
	return nil
end

function Demo:WhichDirection(room, x, y)
	if y == room.Y and x > room.X and x < room.X + room.Width then
		return Direction.Up
	elseif y == room.Y + room.Height and x > room.X and x < room.X + room.Width then
		return Direction.Down
	elseif x == room.X + room.Width and y > room.Y and y < room.Y + room.Height then
		return Direction.Right
	elseif x == room.X and y > room.Y and y < room.Y + room.Height then
		return Direction.Left
	else
		return Direction.Max
	end
end

function Demo:AddRoom(loc)
	MapBuilder.Utilities.RectangleFill(loc, self.Map, self.Tiles.Grass)
	MapBuilder.Utilities.Rectangle(loc, self.Map, self.Tiles.Wall)
	
	table.insert(self.Rooms, loc)
end

function Demo:Generate(features, maxrw, maxrh, minrw, minrh)
	local tx, ty -- Temporary x, y
	
	self.Rooms = {}
	
	tx = math.random(0, self.Map.Width)
	ty = math.random(0, self.Map.Height)
	
	if tx < 3 then -- Three is a pretty number
		tx = 3
	elseif tx + maxrw > self.Map.Width - 3 then
		tx = self.Map.Width - maxrw - 3
	end
	
	if ty < 3 then
		ty = 3
	elseif ty + maxrh > self.Map.Height - 3 then
		ty = self.Map.Height - maxrh - 3
	end
	
	self:AddRoom(Rectangle.Create(tx, ty, maxrw, maxrh))
	
	for i = 1, features do
		local hallway = Point.Create(math.random(0, self.Map.Width - 1), math.random(0, self.Map.Height - 1))
		
		if self.Map:GetTileAtXY(hallway).Wall == true then
			local wr = self:WhichRoom(hallway.X, hallway.Y)
			
			if wr then
				local dir = self:WhichDirection(wr, hallway.X, hallway.Y)
				
				if dir == Direction.Up then
					local room = Rectangle.Create()
					
					room.Width = math.random(minrw, maxrw)
					room.Height = math.random(minrh, maxrh)
					
					room.X = hallway.X - (room.Width / 2)
					room.Y = hallway.Y - room.Height - 2
					
					if self:IsValidRoom(room.X, room.Y, room.Width, room.Height) then
						local l = hallway + Point.Create(-1, -1)
						local r = hallway + Point.Create(1, -1)
						
						self:AddRoom(room)
						
						-- Left wall
						MapBuilder.Utilities.Tile(l, self.Map, self.Tiles.Wall)
						
						-- Right wall
						MapBuilder.Utilities.Tile(r, self.Map, self.Tiles.Wall)
						
						-- Middle of the `hallway'
						MapBuilder.Utilities.Tile(hallway, self.Map, self.Tiles.Grass)
						MapBuilder.Utilities.Tile(hallway + Point.Create(0, -1), self.Map, self.Tiles.Grass)
						MapBuilder.Utilities.Tile(hallway + Point.Create(0, -2), self.Map, self.Tiles.Grass)
					end
				elseif dir == Direction.Down then
					local room = Rectangle.Create()
					
					room.Width = math.random(minrw, maxrw)
					room.Height = math.random(minrh, maxrh)
					
					room.X = hallway.X - (room.Width / 2)
					room.Y = hallway.Y + 2
					
					if self:IsValidRoom(room.X, room.Y, room.Width, room.Height) then
						local l = hallway + Point.Create(-1, 1)
						local r = hallway + Point.Create(1, 1)
						
						self:AddRoom(room)
						
						-- Left wall
						MapBuilder.Utilities.Tile(l, self.Map, self.Tiles.Wall)
						
						-- Right wall
						MapBuilder.Utilities.Tile(r, self.Map, self.Tiles.Wall)
						
						-- Middle
						MapBuilder.Utilities.Tile(hallway, self.Map, self.Tiles.Grass)
						MapBuilder.Utilities.Tile(hallway + Point.Create(0, 1), self.Map, self.Tiles.Grass)
						MapBuilder.Utilities.Tile(hallway + Point.Create(0, 2), self.Map, self.Tiles.Grass)
					end
				elseif dir == Direction.Right then
					local room = Rectangle.Create()
					
					room.Width = math.random(minrw, maxrw)
					room.Height = math.random(minrh, maxrh)
					
					room.X = hallway.X + 2
					room.Y = hallway.Y - (room.Height / 2)
					
					if self:IsValidRoom(room.X, room.Y, room.Width, room.Height) then
						local u = hallway + Point.Create(1, -1)
						local d = hallway + Point.Create(1, 1)
						
						self:AddRoom(room)
						
						-- Up wall
						MapBuilder.Utilities.Tile(u, self.Map, self.Tiles.Wall)
						
						-- Down wall
						MapBuilder.Utilities.Tile(d, self.Map, self.Tiles.Wall)
						
						-- Middle
						MapBuilder.Utilities.Tile(hallway, self.Map, self.Tiles.Grass)
						MapBuilder.Utilities.Tile(hallway - Point.Create(-1, 0), self.Map, self.Tiles.Grass)
						MapBuilder.Utilities.Tile(hallway - Point.Create(-2, 0), self.Map, self.Tiles.Grass)
					end
				elseif dir == Direction.Left then
					local room = Rectangle.Create()
					
					room.Width = math.random(minrw, maxrw)
					room.Height = math.random(minrh, maxrh)
					
					room.X = hallway.X - room.Width - 2
					room.Y = hallway.Y - (room.Height / 2)
					
					if self:IsValidRoom(room.X, room.Y, room.Width, room.Height) then
						local u = hallway + Point.Create(-1, -1)
						local d = hallway + Point.Create(-1, 1)
						
						self:AddRoom(room)
						
						-- Up wall
						MapBuilder.Utilities.Tile(u, self.Map, self.Tiles.Wall)
						
						-- Down wall
						MapBuilder.Utilities.Tile(d, self.Map, self.Tiles.Wall)
						
						-- Middle
						MapBuilder.Utilities.Tile(hallway, self.Map, self.Tiles.Grass)
						MapBuilder.Utilities.Tile(hallway + Point.Create(-1, 0), self.Map, self.Tiles.Grass)
						MapBuilder.Utilities.Tile(hallway + Point.Create(-2, 0), self.Map, self.Tiles.Grass)
					end
				end
			end
		end
	end
end

function Demo:Populate(features)
	self.Stage.Objector:Add("DeathParty")
	
	if self.Stage.State.HasSerializedPlayer then
		local p = self.Stage.Objector:Add("D132")
		
		p:OnSpawn({ X = self.Rooms[1].X + self.Rooms[1].Width / 2, Y = self.Rooms[1].Y + self.Rooms[1].Height / 2, SerializedData = self.Stage.State.Player })
	else
		GameObject.Spawning.Spawn(self.Stage.Objector, "D132", self.Rooms[1].X + self.Rooms[1].Width / 2, self.Rooms[1].Y + self.Rooms[1].Height / 2)
	end
	
	if self.Stage.State.CurrentFloor == 1 then
		GameObject.Spawning.Spawn(self.Stage.Objector, "Eggbert", self.Rooms[1].X + 1, self.Rooms[1].Y + 1)
	end
	
	local glTeams = 1
	for i = 1, #self.Rooms - 1 do -- Last room is the monster boss-room
		for j = 1, features do
			local r = math.random(0, 30)
			local loc = Point.Create(math.random(2, self.Rooms[i].Width - 2), math.random(2, self.Rooms[i].Height - 2))
			
			if GameObject.Collision.IsSpotFree(self.Stage.Map, self.Stage.Objector, loc.X + self.Rooms[i].X, loc.Y + self.Rooms[i].Y) then
				if r < 5 then -- Trees
					GameObject.Spawning.Spawn(self.Stage.Objector, "Tree", loc.X + self.Rooms[i].X, loc.Y + self.Rooms[i].Y)
				elseif r < 10 then -- Water
					MapBuilder.Utilities.Tile(loc + self.Rooms[i].XY, self.Map, self.Tiles.Water)
				elseif r < 12 then
					GameObject.Spawning.Spawn(self.Stage.Objector, "PolarBear", loc.X + self.Rooms[i].X, loc.Y + self.Rooms[i].Y)
				elseif r < 13 then
					GameObject.Spawning.Spawn(self.Stage.Objector, "EvilMinion", loc.X + self.Rooms[i].X, loc.Y + self.Rooms[i].Y):OnSetTeam(
						{ Team = glTeams, TeamRank = 2 })
					glTeams = glTeams + 1
				elseif r < 14 then
					GameObject.Spawning.Spawn(self.Stage.Objector, "QuadPotion", loc.X + self.Rooms[i].X, loc.Y + self.Rooms[i].Y)
				elseif r < 15 then
					GameObject.Spawning.Spawn(self.Stage.Objector, "NinjaCrazyDaisy", loc.X + self.Rooms[i].X, loc.Y + self.Rooms[i].Y)
				elseif r < 16 and self.Stage.State.CurrentFloor > 2 then
					GameObject.Spawning.Spawn(self.Stage.Objector, "Twornadoe", loc.X + self.Rooms[i].X, loc.Y + self.Rooms[i].Y)
				end
			end
		end
	end
	
	if self.Stage.State.CurrentFloor == 1 then
		GameObject.Spawning.Spawn(self.Stage.Objector, "PixPac", self.Rooms[#self.Rooms].X + self.Rooms[#self.Rooms].Width / 2, self.Rooms[#self.Rooms].Y + self.Rooms[#self.Rooms].Height / 2)
	else
		if self.Stage.State.CurrentFloor == 2 then
			GameObject.Spawning.Spawn(self.Stage.Objector, "TBook", self.Rooms[#self.Rooms].X + 1, self.Rooms[#self.Rooms].Y + 1)
		end
		
		if self.Stage.State.CurrentFloor ~= 5 then
			GameObject.Spawning.Spawn(self.Stage.Objector, "Stairs", self.Rooms[#self.Rooms].X + self.Rooms[#self.Rooms].Width / 2, self.Rooms[#self.Rooms].Y + self.Rooms[#self.Rooms].Height / 2)
		else
			GameObject.Spawning.Spawn(self.Stage.Objector, "AMUEggbert", self.Rooms[#self.Rooms].X + self.Rooms[#self.Rooms].Width / 2 - 1, self.Rooms[#self.Rooms].Y + self.Rooms[#self.Rooms].Height / 2 - 2):OnSetRoom({ Room = self.Rooms[#self.Rooms] })
		end
	end
	
	Game.Loggy:Write("\n")
end

function Demo:Initialize(stage)
	self.Stage = stage
	self.Stage.State.StageName = "Pixly Courtyard"
	
	self.Tiles = {}
	
	self.Tiles.Grass =
	{
		Index = 1,
		Impassable = false,
		Water = false,
		Special = false,
		Floor = true,
		Wall = false
	}
	
	self.Tiles.Wall =
	{
		Index = 2,
		Impassable = true,
		Water = false,
		Special = false,
		Floor = false,
		Wall = true
	}
	
	self.Tiles.Water =
	{
		Index = 3,
		Impassable = false,
		Water = true,
		Special = false,
		Floor = true,
		Wall = true
	}
	
	self.TileSheet = TileSheet.Create()
	
	local animSpeed = 1.0
	
	-- Nothingness
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(25, 25, 25), Graphics.MakeColor(0, 0, 0), 0))
	
	-- Grass
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(20, 100, 20), Graphics.MakeColor(40, 120, 40), 1))
	
	-- Stone wall
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(100, 100, 100), Graphics.MakeColor(120, 120, 120), 2))
	
	-- Water
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(95, 185, 210), Graphics.MakeColor(55, 170, 200), 4, animSpeed))
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(55, 170, 200), Graphics.MakeColor(45, 135, 160), 5, animSpeed))
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(45, 135, 160), Graphics.MakeColor(35, 105, 120), 6, animSpeed))
	self.TileSheet:Add(TileSheetTile.Create(Graphics.MakeColor(55, 170, 200), Graphics.MakeColor(45, 135, 160), 3, animSpeed))
	
	self.TileWidth = 32
	self.TileHeight = 32
	
	self.CameraWidth = Game.ScreenWidth / self.TileWidth
	self.CameraHeight = Game.ScreenHeight / self.TileHeight
	
	self.Map = Map.Create(50, 50)
	
	self:Generate(15000, 12, 12, 8, 8)
	
	self.Stage:Synchronize()
	
	self:Populate(10)
	
	dofile(Game.AbsolutePath .. "Content/Music/PixvilleSong.lua")
	
	if not Concerto:Exists("Pixville") then
		Concerto:Add("Pixville", MusicBuilder.CreateFromTable(PixvilleSong))
	end
	
	if not Concerto:IsPlaying("Pixville") then
		Concerto:StopAll()
		Concerto:Play("Pixville", 100, 128, 1000, true)
	end
end
